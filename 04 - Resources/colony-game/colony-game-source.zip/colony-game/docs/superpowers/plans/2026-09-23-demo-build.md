# Undermoot Free Demo Build Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add a third build, `dist/undermoot-demo.html`, that contains only zones 1 to 4 of the sale game, ends with a screen that hands the player a save code to carry on in the full game, and cannot leak the paid content.

**Architecture:** A pure function `makeDemoContent(sale)` (in `src/demo.js`) cuts the sale content down at build time; `vite.config.js` serves its output as the `@content` module when `GAME_PACK=demo`. The engine shows the demo end screen at the one point where there is no next zone (`advanceZone()`), and a second pure function `clampToContent(state, content)` (in `src/saveguard.js`) trims any loaded or imported save to what the current build contains.

**Tech Stack:** Vanilla JS (ES modules), three.js, Vite 5 + vite-plugin-singlefile, Node 24 (`node --test` for unit tests; `require()` of ES modules works in Node 24).

**Spec:** `docs/superpowers/specs/2026-09-23-demo-build-design.md`

**Addition beyond the spec (Task 2, the save guard):** found while planning. The colony
screen looks companions up by name and crashes on an unknown one, so a full-game save code
pasted into the demo (for example a player who owns both) would break the demo. The spec
said the full game needs no change; the guard does touch the shared engine (`load()` and
`importSave()`), which is harmless for the full and fan builds (their saves already fit)
and needed for the demo. Everything else follows the spec as approved.

## Global Constraints

- Work in `C:\Users\Fredy 2\Documents\colony-game` (git repo). Never inside the Obsidian vault.
- The demo keeps zones 0 to 3 (Hollow Roots, Sunken Warrens, The Deep Nest, Bramble Sinks), companions with `unlockTier <= 3`, tiers 0 to 3, and events whose `when.zone` is absent or `< 4` and whose `when.tier` is absent or `<= 3`.
- Demo title: `"Undermoot: Rise of the Swarm (Demo)"`. Demo save slot: `"undermoot_demo"`. Demo file name: `undermoot-demo.html`.
- `meta.demo.storeUrl` is `""`; the "Get the full game" button is hidden while it is empty.
- The sale build and the personal (fan) build must build and behave exactly as before.
- No names from the *Chrysalis* books in the demo (same rule as the sale build).
- On this Windows machine, build with Git Bash: `GAME_PACK=<pack> npx vite build --outDir dist/<pack> && node scripts/name-output.mjs <pack>` (`npm run build` fails under cmd.exe). `test/smoke.cjs` cannot run here (Linux Playwright path); do not try to fix it in this plan.
- Writing rules for any player-facing or doc text: no em dashes; no hype or corporate words.
- Heredocs piped into `python -` in Git Bash here lose backslashes; write scripts to files instead.

## Review Focus

1. **A full-game (or edited) save imported into the demo**, e.g. at zone 9 with Vex as a companion: expected, no crash; the demo clamps to Bramble Sinks and drops unknown companions. Pinned by Task 2's unit tests and Task 5 browser check 5.
2. **Copy button where the clipboard API is missing** (the file opened over plain `http://` on a LAN, or an old browser): expected, the code is selected and copied with the fallback, and it stays visible to copy by hand. Pinned by Task 5 browser check 4.
3. **Beating the last demo boss from the 3D world** (touching it again): expected, the 3D world closes and the end screen shows; the game is not left behind an open 3D view. Pinned by Task 5 browser check 3.
4. **"Keep playing", then trying to move on again, later**: expected, the screen comes back with a fresh code reflecting current progress (level changed since). Pinned by Task 5 browser check 2.
5. **A demo player grinding far past level 18** (no tier above Twinmind in the demo): expected, no crash; tier stays Twinmind Ant; importing that save into the full game gives the right higher tier on the next level-up. Pinned by Task 2 (tier clamp) and Task 5 browser check 5.

---

### Task 1: Demo content cutter

**Files:**
- Create: `src/demo.js`
- Test: `test/demo.test.mjs`

**Interfaces:**
- Produces: `export function makeDemoContent(sale)` returning a new content object (sale shape plus `meta.demo`); `export const DEMO_LAST_ZONE = 3`, `export const DEMO_LAST_TIER = 3`.

- [ ] **Step 1: Write the failing tests**

```js
/* Unit tests for the demo content cutter (src/demo.js).
   Run with: node --test test/demo.test.mjs */
import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { makeDemoContent } from "../src/demo.js";

const load = () => JSON.parse(readFileSync(new URL("../src/content.sale.json", import.meta.url), "utf8"));

test("keeps only the first four zones", () => {
  const d = makeDemoContent(load());
  assert.deepEqual(d.zones.map(z => z.name), ["Hollow Roots", "Sunken Warrens", "The Deep Nest", "Bramble Sinks"]);
});

test("keeps only companions a demo player can reach (tiers 1 to 3)", () => {
  const d = makeDemoContent(load());
  assert.deepEqual(d.companions.map(c => c.name), ["Grum", "Lumen", "Husk"]);
});

test("keeps tiers up to Twinmind Ant", () => {
  const d = makeDemoContent(load());
  assert.deepEqual(d.tiers.map(t => t.name), ["Larval Digger", "Bonded Worker", "Cognizant Ant", "Twinmind Ant"]);
});

test("keeps story beats for zones 1 to 4 and tiers up to 3, drops the rest", () => {
  const d = makeDemoContent(load());
  assert.deepEqual(d.events.map(e => e.id), ["wake", "wardens", "colony", "grum", "brood"]);
});

test("renames the build and gives it its own save slot", () => {
  const d = makeDemoContent(load());
  assert.equal(d.meta.title, "Undermoot: Rise of the Swarm (Demo)");
  assert.equal(d.meta.saveSlug, "undermoot_demo");
});

test("adds the demo settings with an empty store link and the end-screen text", () => {
  const d = makeDemoContent(load());
  assert.equal(d.meta.demo.storeUrl, "");
  for (const k of ["title", "text", "codeLabel", "codeHelp", "buyLabel", "keepPlayingLabel", "copyLabel", "copiedLabel"]) {
    assert.equal(typeof d.meta.demo.end[k], "string", k);
    assert.ok(d.meta.demo.end[k].length > 0, k);
  }
});

test("copies everything else unchanged", () => {
  const sale = load();
  const d = makeDemoContent(sale);
  assert.deepEqual(d.progression, sale.progression);
  assert.deepEqual(d.eggChoice, sale.eggChoice);
  assert.deepEqual(d.strings, sale.strings);
  assert.equal(d.meta.heroName, sale.meta.heroName);
});

test("does not modify the sale content it is given", () => {
  const sale = load();
  const before = JSON.stringify(sale);
  makeDemoContent(sale);
  assert.equal(JSON.stringify(sale), before);
});
```

- [ ] **Step 2: Run the tests to verify they fail**

Run: `node --test test/demo.test.mjs`
Expected: FAIL, `Cannot find module ... src/demo.js`

- [ ] **Step 3: Write the implementation**

```js
/* The free demo: the sale content cut down at build time.

   The demo ends after zone 4 (index 3), straight after "The Choosing of the
   Brood". Everything past that point is removed here, before bundling, so the
   paid part of the game is not inside the demo file at all. Pure function, no
   browser or build-tool dependencies, so it can be unit tested in Node. */

export const DEMO_LAST_ZONE = 3;   // Bramble Sinks
export const DEMO_LAST_TIER = 3;   // Twinmind Ant

const END_SCREEN = {
  title: "The Undermoot goes deeper",
  text: "You've reached the end of the demo. Your colony has made its choice, and there are eight more zones below: new creatures, new companions, and whatever is waiting at the root of the world.",
  codeLabel: "Your save code, to carry on in the full game:",
  codeHelp: "In the full game, paste it into the Save box and click Import. You'll pick up exactly where you stopped.",
  buyLabel: "Get the full game",
  keepPlayingLabel: "Keep playing the demo",
  copyLabel: "Copy",
  copiedLabel: "Copied"
};

function keepEvent(ev){
  const w = ev.when || {};
  if(w.zone !== undefined && w.zone > DEMO_LAST_ZONE) return false;
  if(w.tier !== undefined && w.tier > DEMO_LAST_TIER) return false;
  return true;
}

export function makeDemoContent(sale){
  const c = structuredClone(sale);
  c.zones = c.zones.slice(0, DEMO_LAST_ZONE + 1);
  c.companions = c.companions.filter(x => x.unlockTier <= DEMO_LAST_TIER);
  c.tiers = c.tiers.slice(0, DEMO_LAST_TIER + 1);
  c.events = (c.events || []).filter(keepEvent);
  c.meta.title = sale.meta.title + " (Demo)";
  c.meta.saveSlug = "undermoot_demo";
  c.meta.demo = { storeUrl: "", end: { ...END_SCREEN } };
  return c;
}
```

- [ ] **Step 4: Run the tests to verify they pass**

Run: `node --test test/demo.test.mjs`
Expected: `pass 8`, `fail 0`

- [ ] **Step 5: Commit**

```bash
git add src/demo.js test/demo.test.mjs
git commit -m "Add makeDemoContent: cut the sale content to the free demo"
```

---

### Task 2: Save guard (loaded and imported saves fit the current build)

**Files:**
- Create: `src/saveguard.js`
- Test: `test/saveguard.test.mjs`
- Modify: `src/engine.js` (the `load()` function and `importSave()`)

**Interfaces:**
- Produces: `export function clampToContent(state, content)` returning a new state object; used by `engine.js`.

- [ ] **Step 1: Write the failing tests**

```js
/* Unit tests for src/saveguard.js. Run with: node --test test/saveguard.test.mjs */
import { test } from "node:test";
import assert from "node:assert/strict";
import { clampToContent } from "../src/saveguard.js";

const content = {
  zones: [{ name: "A" }, { name: "B" }, { name: "C" }, { name: "D" }],
  tiers: [{ name: "t0" }, { name: "t1" }, { name: "t2" }, { name: "t3" }],
  companions: [{ name: "Grum" }, { name: "Lumen" }, { name: "Husk" }]
};

test("a save from further in the full game is pulled back to the last zone and tier", () => {
  const s = clampToContent({ zoneIndex: 8, tierIndex: 5, companions: [] }, content);
  assert.equal(s.zoneIndex, 3);
  assert.equal(s.tierIndex, 3);
});

test("companions this build doesn't have are dropped, known ones kept in order", () => {
  const s = clampToContent({ zoneIndex: 0, tierIndex: 0, companions: ["Grum", "Vex", "Husk", "Nyx"] }, content);
  assert.deepEqual(s.companions, ["Grum", "Husk"]);
});

test("a save that already fits is returned unchanged", () => {
  const input = { zoneIndex: 2, tierIndex: 1, companions: ["Lumen"], level: 9 };
  assert.deepEqual(clampToContent(input, content), input);
});

test("negative or missing indexes become 0", () => {
  const s = clampToContent({ zoneIndex: -2, companions: [] }, content);
  assert.equal(s.zoneIndex, 0);
  assert.equal(s.tierIndex, 0);
});

test("the input object is not modified", () => {
  const input = { zoneIndex: 9, tierIndex: 6, companions: ["Vex"] };
  clampToContent(input, content);
  assert.deepEqual(input, { zoneIndex: 9, tierIndex: 6, companions: ["Vex"] });
});
```

- [ ] **Step 2: Run the tests to verify they fail**

Run: `node --test test/saveguard.test.mjs`
Expected: FAIL, `Cannot find module ... src/saveguard.js`

- [ ] **Step 3: Write the implementation**

```js
/* Make a save fit the build that loads it.

   A save code can come from a different build: most often a full-game save
   pasted into the demo, which points at zones, tiers and companions the demo
   doesn't contain, and the colony screen would crash looking them up. Clamp the
   indexes and drop unknown companions. Pure, so it can be unit tested. */

export function clampToContent(state, content){
  const clamp = (v, max) => Math.min(Math.max(0, Number.isInteger(v) ? v : 0), max);
  const known = new Set(content.companions.map(c => c.name));
  return {
    ...state,
    zoneIndex: clamp(state.zoneIndex, content.zones.length - 1),
    tierIndex: clamp(state.tierIndex, content.tiers.length - 1),
    companions: (state.companions || []).filter(n => known.has(n))
  };
}
```

- [ ] **Step 4: Run the tests to verify they pass**

Run: `node --test test/saveguard.test.mjs`
Expected: `pass 5`, `fail 0`

- [ ] **Step 5: Use it in the engine**

In `src/engine.js`, add the import under the existing imports (after `import { WORLD3D } from "./world3d.js";`):

```js
import { clampToContent } from "./saveguard.js";
```

In `load()`, change

```js
    return Object.assign(defaultState(), JSON.parse(raw));
```

to

```js
    return clampToContent(Object.assign(defaultState(), JSON.parse(raw)), C);
```

In `importSave()`, change

```js
    state = Object.assign(defaultState(), parsed);
```

to

```js
    state = clampToContent(Object.assign(defaultState(), parsed), C);
```

- [ ] **Step 6: Check nothing else broke**

Run: `node --test test/demo.test.mjs test/saveguard.test.mjs test/gpu.test.mjs && node test/progression.cjs`
Expected: all unit tests pass; `All progression checks passed.`

Build the sale game to confirm the engine still bundles:
`GAME_PACK=sale npx vite build --outDir dist/sale && node scripts/name-output.mjs sale`
Expected: `✓ built`, `-> dist/undermoot-rise-of-the-swarm.html`

- [ ] **Step 7: Commit**

```bash
git add src/saveguard.js test/saveguard.test.mjs src/engine.js
git commit -m "Clamp loaded and imported saves to the current build's content"
```

---

### Task 3: The demo build

**Files:**
- Modify: `vite.config.js`, `scripts/name-output.mjs`, `package.json`, `test/progression.cjs`

**Interfaces:**
- Consumes: `makeDemoContent` from Task 1.
- Produces: `GAME_PACK=demo` builds `dist/demo/index.html` and `dist/undermoot-demo.html`.

- [ ] **Step 1: Add the demo pack to the progression test first (it must fail)**

In `test/progression.cjs`, change

```js
const PACKS = ["sale", "personal"];
```

to

```js
const PACKS = ["sale", "personal", "demo"];
// The demo has no JSON file of its own: it is cut from the sale content.
// Node 24 can require() an ES module.
const { makeDemoContent } = require("../src/demo.js");
const loadPack = pack => pack === "demo"
  ? makeDemoContent(JSON.parse(fs.readFileSync(path.join(__dirname, "..", "src", "content.sale.json"), "utf8")))
  : JSON.parse(fs.readFileSync(path.join(__dirname, "..", "src", `content.${pack}.json`), "utf8"));
```

and inside the loop change

```js
  const C = JSON.parse(fs.readFileSync(path.join(__dirname, "..", "src", `content.${pack}.json`), "utf8"));
```

to

```js
  const C = loadPack(pack);
```

Run: `node test/progression.cjs`
Expected: a `=== demo pack` section with 4 PASS lines (zones 0 to 3, the same fight counts as the sale pack: 24, 18, 10, 30) and `All progression checks passed.` (This step is green immediately because Task 1 already exists; it pins the demo's zones as beatable.)

- [ ] **Step 2: Try the demo build before changing Vite (it must fail or build the wrong thing)**

Run: `GAME_PACK=demo npx vite build --outDir dist/demo`
Expected: it builds the **sale** game (title "Undermoot: Rise of the Swarm" without "(Demo)"), because `vite.config.js` treats any unknown pack as sale. Confirm with `grep -c "(Demo)" dist/demo/index.html` → `0`.

- [ ] **Step 3: Teach Vite the demo pack**

Replace the top of `vite.config.js` (from `// Which content pack to build` through the `packTitle` constant) with:

```js
// Which content pack to build: "personal" (book-flavoured, private use),
// "sale" (fully original world) or "demo" (the sale game cut to zones 1 to 4
// by src/demo.js). Set with GAME_PACK=... npm run build:*
const PACKS = ["personal", "sale", "demo"];
const pack = PACKS.includes(process.env.GAME_PACK) ? process.env.GAME_PACK : "sale";

// Drops the chosen pack's title into <title> at build time, so the tab is
// right before any JavaScript runs.
import { readFileSync } from "node:fs";
import { makeDemoContent } from "./src/demo.js";
const readPack = name => JSON.parse(
  readFileSync(new URL(`./src/content.${name}.json`, import.meta.url), "utf8")
);
const content = pack === "demo" ? makeDemoContent(readPack("sale")) : readPack(pack);
const packTitle = content.meta.title;

// The demo has no JSON file: serve the cut content as the "@content" module,
// so only the demo's own zones end up in the bundle.
const DEMO_ID = "\0demo-content";
const demoContentPlugin = {
  name: "demo-content",
  enforce: "pre",
  resolveId(id){ return pack === "demo" && id === "@content" ? DEMO_ID : null; },
  load(id){ return id === DEMO_ID ? `export default ${JSON.stringify(content)};` : null; }
};
```

and in `defineConfig`, change

```js
  plugins: [titlePlugin, viteSingleFile()],
  resolve: {
    alias: {
      // main.js imports "@content" — this points it at the chosen pack
      "@content": fileURLToPath(new URL(`./src/content.${pack}.json`, import.meta.url))
    }
  },
```

to

```js
  plugins: [demoContentPlugin, titlePlugin, viteSingleFile()],
  resolve: {
    // main.js imports "@content": this points it at the chosen pack's JSON
    // (the demo is served by demoContentPlugin instead)
    alias: pack === "demo" ? {} : {
      "@content": fileURLToPath(new URL(`./src/content.${pack}.json`, import.meta.url))
    }
  },
```

- [ ] **Step 4: Name the demo output**

In `scripts/name-output.mjs`, replace the body below the imports with:

```js
import { makeDemoContent } from "../src/demo.js";

const pack = process.argv[2];
const root = fileURLToPath(new URL("../", import.meta.url));
const NAMES = {
  personal: "chrysalis-fan-game-personal-use.html",
  sale: "undermoot-rise-of-the-swarm.html",
  demo: "undermoot-demo.html"
};
const readPack = name => JSON.parse(readFileSync(`${root}src/content.${name}.json`, "utf8"));
const title = (pack === "demo" ? makeDemoContent(readPack("sale")) : readPack(pack)).meta.title;
copyFileSync(`${root}dist/${pack}/index.html`, `${root}dist/${NAMES[pack]}`);
console.log(`  -> dist/${NAMES[pack]}  (${title})`);
```

(keep the existing comment and the `import { copyFileSync, readFileSync } from "node:fs";` and `import { fileURLToPath } from "node:url";` lines at the top).

- [ ] **Step 5: Add the npm scripts**

In `package.json` `scripts`, add after `build:sale`:

```json
    "build:demo": "GAME_PACK=demo vite build --outDir dist/demo && node scripts/name-output.mjs demo",
```

and change `build` to:

```json
    "build": "npm run build:personal && npm run build:sale && npm run build:demo",
```

- [ ] **Step 6: Build all three and check the demo**

Run:
```bash
for p in personal sale demo; do GAME_PACK=$p npx vite build --outDir dist/$p 2>&1 | tail -1 && node scripts/name-output.mjs $p; done
grep -c "Rise of the Swarm (Demo)" dist/undermoot-demo.html
grep -c "Moonlit Surface" dist/undermoot-demo.html
grep -c "Moonlit Surface" dist/undermoot-rise-of-the-swarm.html
```
Expected: three `✓ built` lines and the three named files; demo title count `>= 1`; "Moonlit Surface" (zone 6, a paid zone) count `0` in the demo and `>= 1` in the sale file.

- [ ] **Step 7: Commit**

```bash
git add vite.config.js scripts/name-output.mjs package.json test/progression.cjs
git commit -m "Add the demo build (GAME_PACK=demo), cut from the sale content"
```

---

### Task 4: Leak check and name scan for the demo

**Files:**
- Create: `scripts/scan-demo-build.mjs`
- Modify: `scripts/scan-sale-build.mjs`, `package.json`

**Interfaces:**
- Consumes: `makeDemoContent` (Task 1); `dist/undermoot-demo.html` (Task 3).

- [ ] **Step 1: Write the leak check**

```js
/* Check the demo build contains none of the paid game.

   Collects every name the sale content has and the demo content doesn't
   (zones 5 to 12, their bosses and creatures, the dropped companions and tiers,
   and the titles of the dropped story beats), then fails if any of them
   appears in the built demo file. Run after a build:
     node scripts/scan-demo-build.mjs [file]   (default dist/undermoot-demo.html) */
import { readFileSync } from "node:fs";
import { makeDemoContent } from "../src/demo.js";

const sale = JSON.parse(readFileSync("src/content.sale.json", "utf8"));
const demo = makeDemoContent(sale);
const file = process.argv[2] || "dist/undermoot-demo.html";
const built = readFileSync(file, "utf8");

const names = (c) => new Set([
  ...c.zones.flatMap((z) => [z.name, z.bossName, ...(z.enemies || []).map((e) => e.name)]),
  ...c.companions.map((x) => x.name),
  ...c.tiers.map((t) => t.name),
  ...(c.events || []).map((e) => e.title)
].filter(Boolean));

const kept = names(demo);
const paidOnly = [...names(sale)].filter((n) => !kept.has(n));
const escape = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
const hits = paidOnly.filter((n) => new RegExp("\\b" + escape(n) + "\\b").test(built));

console.log(`checked ${paidOnly.length} names that only the full game has`);
if (hits.length) {
  console.log("FOUND in " + file + ": " + hits.join(", "));
  process.exit(1);
}
console.log(file + " is clean: none of them appear");
```

- [ ] **Step 2: Sanity check: it must FAIL against the full sale build**

Run: `node scripts/scan-demo-build.mjs dist/undermoot-rise-of-the-swarm.html`
Expected: exit code 1 and a `FOUND in ...` line listing names such as Moonlit Surface and Nyx.

- [ ] **Step 3: Run it against the demo**

Run: `node scripts/scan-demo-build.mjs`
Expected: `dist/undermoot-demo.html is clean: none of them appear`, exit code 0.
If a name is reported, open the demo file and find the match. A genuine leak means the cut in `src/demo.js` missed something: fix `makeDemoContent` and add a unit test for it in `test/demo.test.mjs` first. A short common word colliding with ordinary text is not a leak: list it in a commented `GENERIC` set in this script, the same way `scan-sale-build.mjs` handles "Mana", after confirming the word is in kept content.

- [ ] **Step 4: Run the book-name scan on the demo too**

In `scripts/scan-sale-build.mjs`, replace

```js
const built = readFileSync("dist/undermoot-rise-of-the-swarm.html", "utf8");
```

with

```js
const file = process.argv[2] || "dist/undermoot-rise-of-the-swarm.html";
const built = readFileSync(file, "utf8");
```

and change the two messages that name the sale build to use `file`:

```js
  console.log("FOUND in " + file + ": " + hits.join(", "));
```

```js
console.log(file + " is clean: none of them appear");
```

Run: `node scripts/scan-sale-build.mjs dist/undermoot-demo.html`
Expected: `dist/undermoot-demo.html is clean: none of them appear`

- [ ] **Step 5: Make `npm run scan` check everything**

In `package.json`, change the `scan` script to:

```json
    "scan": "node scripts/scan-sale-build.mjs && node scripts/scan-sale-build.mjs dist/undermoot-demo.html && node scripts/scan-demo-build.mjs",
```

Run: `npm run scan`
Expected: three clean lines, exit code 0.

- [ ] **Step 6: Commit**

```bash
git add scripts/scan-demo-build.mjs scripts/scan-sale-build.mjs package.json
git commit -m "Scan the demo: no paid-game content and no book names"
```

---

### Task 5: The demo end screen

**Files:**
- Modify: `index.html`, `src/style.css`, `src/engine.js`

**Interfaces:**
- Consumes: `C.meta.demo` from Task 1 (`storeUrl`, `end.{title,text,codeLabel,codeHelp,buyLabel,keepPlayingLabel,copyLabel,copiedLabel}`).
- Produces: `showDemoEnd()` in `engine.js`; element ids `demoEndModal`, `demoEndTitle`, `demoEndText`, `demoEndCodeLabel`, `demoEndCode`, `demoEndCopyBtn`, `demoEndCodeHelp`, `demoEndBuyBtn`, `demoEndKeepBtn`.

This task's behaviour lives in browser code with no Node test harness on this machine, so its test cycle is the browser checks in Step 5, run against the built demo **before** (to see them fail) and after the change.

- [ ] **Step 1: See the current behaviour fail the check**

Build the demo (Task 3 Step 6 command for `demo` only), serve `dist/` (`cd dist && python -m http.server 8643 --bind 127.0.0.1`, in the background), open `http://127.0.0.1:8643/undermoot-demo.html` in the Claude browser pane, and run browser check 1 below. Expected now: it fails, because there is no `demoEndModal` and moving on just logs "all zones cleared".

- [ ] **Step 2: Add the markup**

In `index.html`, directly after the `storyModal` block (the `<div class="modalWrap" id="storyModal">` ... `</div>` pair), add:

```html
  <div class="modalWrap" id="demoEndModal">
    <div class="modal">
      <h3 id="demoEndTitle"></h3>
      <p id="demoEndText"></p>
      <p class="demoEndLabel" id="demoEndCodeLabel"></p>
      <div class="demoEndCodeRow">
        <textarea id="demoEndCode" readonly></textarea>
        <button id="demoEndCopyBtn"></button>
      </div>
      <p class="muted" id="demoEndCodeHelp"></p>
      <button id="demoEndBuyBtn" hidden></button>
      <button id="demoEndKeepBtn"></button>
    </div>
  </div>
```

- [ ] **Step 3: Add the styles**

In `src/style.css`, after the `.modal h3{...}` line, add:

```css
/* demo end screen (engine.js showDemoEnd) */
.demoEndLabel{font-weight:bold; margin-bottom:6px;}
.demoEndCodeRow{display:flex; gap:8px; align-items:stretch;}
.demoEndCodeRow textarea{flex:1; height:56px;}
.demoEndCodeRow button{width:auto; margin:0; flex:none;}
#demoEndBuyBtn[hidden]{display:none;}
#demoEndBuyBtn{border-color:var(--accent); color:var(--accent);}
```

- [ ] **Step 4: Add the engine code**

In `src/engine.js`:

(a) Replace `exportSave()` with a shared encoder plus the export:

```js
function saveCode(){ return btoa(unescape(encodeURIComponent(JSON.stringify(state)))); }

function exportSave(){
  const ta = document.getElementById("saveText");
  ta.value = saveCode();
  ta.select();
}
```

(b) In `advanceZone()`, change

```js
  if(!next){ logMsg(C.strings.allZonesCleared); render(); return; }
```

to

```js
  if(!next){
    // The demo has no zone past Bramble Sinks: show its end screen instead.
    if(C.meta.demo){ showDemoEnd(); return; }
    logMsg(C.strings.allZonesCleared); render(); return;
  }
```

(c) Add, after `closeWorld()`:

```js
/* ---------- Demo end screen ---------- */

function showDemoEnd(){
  const d = C.meta.demo;
  if(document.getElementById("worldModal").classList.contains("open")) closeWorld();
  document.getElementById("demoEndTitle").textContent = d.end.title;
  document.getElementById("demoEndText").textContent = d.end.text;
  document.getElementById("demoEndCodeLabel").textContent = d.end.codeLabel;
  document.getElementById("demoEndCodeHelp").textContent = d.end.codeHelp;
  document.getElementById("demoEndCode").value = saveCode();   // fresh every time
  document.getElementById("demoEndCopyBtn").textContent = d.end.copyLabel;
  const buy = document.getElementById("demoEndBuyBtn");
  buy.textContent = d.end.buyLabel;
  buy.hidden = !d.storeUrl;
  document.getElementById("demoEndKeepBtn").textContent = d.end.keepPlayingLabel;
  openModal("demoEndModal");
}

function copyDemoCode(){
  const d = C.meta.demo;
  const ta = document.getElementById("demoEndCode");
  const btn = document.getElementById("demoEndCopyBtn");
  const done = () => { btn.textContent = d.end.copiedLabel; };
  ta.select();
  // The clipboard API only exists on secure pages (https, localhost, file).
  // Elsewhere, fall back to the old copy command; the code stays selected
  // and visible either way, so it can be copied by hand.
  if(navigator.clipboard && window.isSecureContext){
    navigator.clipboard.writeText(ta.value).then(done, () => { if(document.execCommand("copy")) done(); });
  } else if(document.execCommand("copy")){
    done();
  }
}
```

(d) In `init()`, after `document.getElementById("storyContinueBtn").addEventListener("click", showNextStory);`, add:

```js
  if(C.meta.demo){
    document.getElementById("demoEndCopyBtn").addEventListener("click", copyDemoCode);
    document.getElementById("demoEndBuyBtn").addEventListener("click", () => window.open(C.meta.demo.storeUrl, "_blank", "noopener"));
    document.getElementById("demoEndKeepBtn").addEventListener("click", () => closeModal("demoEndModal"));
  }
```

- [ ] **Step 5: Rebuild the demo and sale, then run the browser checks**

Rebuild with the Task 3 Step 6 loop. Serve `dist/` as in Step 1 and open the demo in the Claude browser pane (this pane caps WebGL at 30 fps; that doesn't matter here).

Setup for checks 1 to 4: load a save sitting at Bramble Sinks with its boss beaten. Paste into the page's JS console via the browser tool:

```js
localStorage.clear(); location.reload();
```

then (after reload):

```js
const st = { level: 18, xp: 0, biomass: 50, mana: 100, cores: { normal: 0, special: 0, rare: 0 },
  tierIndex: 3, zoneIndex: 3, workers: 5, queenUnlocked: true, eggChoice: "might",
  companions: ["Grum", "Lumen", "Husk"], flags: { seenEvents: ["wake", "wardens", "colony", "grum", "brood"] },
  bossesDown: ["Hollow Roots", "Sunken Warrens", "The Deep Nest", "Bramble Sinks"], log: [], battle: null };
document.getElementById("saveText").value = btoa(unescape(encodeURIComponent(JSON.stringify(st))));
document.getElementById("importBtn").click();
document.getElementById("zoneName").textContent   // expect "Bramble Sinks"
```

1. **End screen from the colony button.** `document.getElementById("bossBtn").click()` then read `demoEndModal`'s `classList.contains("open")` → `true`; `demoEndTitle` text → `"The Undermoot goes deeper"`; `demoEndBuyBtn.hidden` → `true`; `demoEndCode.value` decodes (`JSON.parse(decodeURIComponent(escape(atob(v))))`) to an object with `zoneIndex: 3` and `level: 18`. No errors in the console (`read_console_messages`, errors only).
2. **Keep playing, then again with changed progress.** Click `demoEndKeepBtn` → modal closed, `zoneName` still "Bramble Sinks". Import the same save with `level: 21`, click `bossBtn` again → modal open, and the new code decodes to `level: 21`.
3. **From the 3D world.** Close the modal, click `worldBtn`, wait 2 s, then call the world's boss-touch path: `window.WORLD3D` has no direct hook, so click `bossBtn` while the world is open (same `attemptBoss()` path the 3D touch uses) → `worldModal` no longer has `open`, `demoEndModal` has `open`.
4. **Copy without the clipboard API.** Run `Object.defineProperty(navigator, "clipboard", { value: undefined, configurable: true })`, open the end screen, click `demoEndCopyBtn` → button text becomes `"Copied"` (from `execCommand`), or if the pane refuses `execCommand`, the textarea is selected (`document.activeElement.id === "demoEndCode"`) and no error is thrown. Either is a pass; an exception is a fail.
5. **A full-game save in the demo.** Import a code with `zoneIndex: 8, tierIndex: 5, companions: ["Grum", "Vex", "Sable"], level: 40` → no console error; `zoneName` → "Bramble Sinks"; `tierName` → "Twinmind Ant"; the companions list shows only Grum.
6. **Carry-over into the full game.** Copy the code from check 1. Open `http://127.0.0.1:8643/undermoot-rise-of-the-swarm.html`, clear its storage, paste the code into `saveText`, click `importBtn`, then click `bossBtn` → `zoneName` becomes `"The Long Dig"` (zone 5).
7. **The sale build has no demo screen.** In the sale page, `C.meta.demo` is absent: `window.GAME_CONTENT.meta.demo` → `undefined`.

Also rerun: `node --test test/demo.test.mjs test/saveguard.test.mjs test/gpu.test.mjs`, `node test/progression.cjs`, `npm run scan` → all pass.

Stop the server when done.

- [ ] **Step 6: Commit**

```bash
git add index.html src/style.css src/engine.js
git commit -m "Demo end screen with save code carry-over"
```

---

### Task 6: Docs and delivery

**Files:**
- Modify: `README.md`
- Vault: `C:\Users\Fredy 2\The Beasts Brain\04 - Resources\colony-game\` (add `undermoot-demo.html`, replace the other two HTML files and `colony-game-source.zip`), plus the notes named below.

- [ ] **Step 1: README**

In `README.md`, under `## Build`, after the `npm run build:sale` line, add:

```
npm run build:demo       # -> dist/demo/index.html, the free demo (zones 1 to 4)
```

and add a new section after `## Build`'s code block:

```markdown
### The demo

`GAME_PACK=demo` builds the free demo: the sale game cut to its first four zones by
`src/demo.js` (`makeDemoContent`). The cut happens before bundling, so the later zones,
their creatures and bosses, the companions and tiers past Twinmind Ant, and the story
beats after zone 4 are not in the demo file at all. `npm run scan` checks this.

Beating the Bramble Sinks boss and moving on shows the demo's end screen: the player's
save code with a Copy button and a line explaining how to import it into the full game,
which carries on at zone 5. The end-screen wording and the store link
(`meta.demo.storeUrl`, empty until the store page exists; the "Get the full game" button
is hidden while it's empty) are set in `src/demo.js`.

Saves are clamped to the build that loads them (`src/saveguard.js`), so a full-game code
pasted into the demo lands at Bramble Sinks instead of crashing.
```

In the `## Test` section's code block, add:

```
npm run scan             # book names in sale and demo, paid content in the demo
```

(replacing the existing `npm run scan` line) and change `npm run test:unit` in `package.json` to:

```json
    "test:unit": "node --test test/gpu.test.mjs test/demo.test.mjs test/saveguard.test.mjs",
```

Run: `npm run test:unit` → all pass.

- [ ] **Step 2: Commit**

```bash
git add README.md package.json
git commit -m "README: the demo build, its scan and the save guard"
```

- [ ] **Step 3: Deliver to the vault**

```bash
V="/c/Users/Fredy 2/The Beasts Brain/04 - Resources/colony-game"
cp dist/undermoot-demo.html dist/undermoot-rise-of-the-swarm.html dist/chrysalis-fan-game-personal-use.html "$V/"
git archive --format=zip --prefix=colony-game/ -o "$V/colony-game-source.zip" HEAD
```

Update `colony-game.md` (files list: the demo file; how it's built) and `Selling Undermoot.md` (Step 1 done), add today's daily-note entry, then commit and push the vault.
