# Undermoot free demo build: design

Date: 2026-09-23. Status: approved in conversation with Nathan (both parts); awaiting review
of this written spec before implementation.

## Purpose

A free demo of *Undermoot: Rise of the Swarm* to put on itch.io as a browser-playable page
next to the paid full game, and to hand to outside playtesters now. The demo has to show
enough of the game to make people want the rest, must not contain the paid part of the game,
and must let a player who buys carry their progress over.

## Decisions (made with Nathan, 2026-09-22/23)

1. **The demo ends after zone 4** (Bramble Sinks), straight after "The Choosing of the Brood".
   That is 82 of 290 fights (28%), reaching about level 18 (Twinmind Ant) in the progression
   simulation. Chosen over ending after zone 3 (52 fights, 18%) because the demo then closes
   right after the game's one permanent decision.
2. **Demo progress carries into the full game through the existing save code** (Export /
   Import). Rejected: a shared save slot (fails silently between a browser demo and a
   downloaded full game) and no carry-over (asks buyers to replay 82 fights).
3. **The demo is cut from the sale content at build time**, so the paid content is not in
   the demo file. Rejected: shipping the full content behind a runtime flag (anyone editing
   the save or the file gets the full game) and a hand-copied demo content file (drifts).

## What the player sees

- File `undermoot-demo.html`, title **"Undermoot: Rise of the Swarm (Demo)"**. Plays exactly
  like the full game through zones 1 to 4: Hollow Roots, Sunken Warrens, The Deep Nest,
  Bramble Sinks.
- Its own save slot (`undermoot_demo`), so demo and full game never overwrite each other in
  one browser.
- **End of the demo.** When the player has beaten the Bramble Sinks boss and tries to move on
  (the colony screen's boss button, or touching the defeated boss in the 3D world), the 3D
  world closes if it is open and an end screen appears instead of zone 5:

  > **The Undermoot goes deeper**
  > You've reached the end of the demo. Your colony has made its choice, and there are eight
  > more zones below: new creatures, new companions, and whatever is waiting at the root of
  > the world.
  >
  > **Your save code**, to carry on in the full game: *[code] [Copy]*
  > In the full game, paste it into the Save box and click Import. You'll pick up exactly
  > where you stopped.
  >
  > *[Get the full game]*  *[Keep playing the demo]*

- **"Get the full game"** appears only when a store link is set (one setting in the demo
  content, empty for now). With no link it is hidden, so the demo is usable for playtesters
  before the store page exists.
- **"Keep playing the demo"** closes the screen; the player can keep hunting in zone 4, and the
  screen returns whenever they try to move on again.
- The wording lives in the demo content (not in code), so it can be edited without touching
  the engine. It follows the sale build's rule: no names from the *Chrysalis* books.

## How it is built

### `src/demo.js`: `makeDemoContent(sale)`

A pure function (no browser or build-tool dependencies, so it can be unit tested in Node).
Takes the sale content object and returns a new object; the input is not modified.

| Part | Rule |
|---|---|
| `zones` | keep the first 4 (indexes 0 to 3) |
| `companions` | keep those with `unlockTier <= 3` (Grum, Lumen, Husk) |
| `tiers` | keep indexes 0 to 3 (through Twinmind Ant) |
| `events` | keep an event only if `when.zone` is absent or `< 4`, **and** `when.tier` is absent or `<= 3` |
| `meta.title` | sale title plus `" (Demo)"` |
| `meta.saveSlug` | `"undermoot_demo"` |
| `meta.demo` | added: `{ storeUrl: "", end: { title, text, codeLabel, codeHelp, buyLabel, keepPlayingLabel, copyLabel, copiedLabel } }` holding the end-screen text above |
| everything else | copied unchanged (`progression`, `eggChoice`, `strings`, the rest of `meta`) |

The constants (last zone index 3, last tier 3) are named at the top of the file.

### Build

- `vite.config.js`: `GAME_PACK=demo` reads `src/content.sale.json`, runs `makeDemoContent`,
  and serves the result as the `@content` module (a small plugin providing a virtual module),
  so only the cut content is bundled. The `<title>` injection uses the demo title. The
  `personal` and `sale` builds are unchanged.
- `package.json`: `build:demo`, and `build` runs all three.
- `scripts/name-output.mjs`: `demo` -> `dist/undermoot-demo.html`.

### Engine (`src/engine.js`)

- One hook in `advanceZone()`: where there is no next zone, if `C.meta.demo` exists, show the
  demo end screen; otherwise keep the current "all zones cleared" message. Both the colony
  button and the 3D boss touch already reach `advanceZone()` (through `attemptBoss()`), so
  there is no second path.
- `showDemoEnd()`: closes the 3D world if open, fills the end screen from `C.meta.demo.end`,
  puts the save code (same encoding as `exportSave()`) in a read-only box, wires Copy, shows
  "Get the full game" only if `storeUrl` is non-empty (opens it in a new tab), and "Keep
  playing" closes the screen.
- The full game needs no change: `importSave()` already merges into `defaultState()`, and the
  demo's zone names and state shape are the sale build's.

### Markup and style

- `index.html`: a hidden end-screen modal in the style of the existing modals, with an id for
  each text slot and button.
- `src/style.css`: only what the modal needs beyond the existing `.modal` styles.

## Testing

Test-first (red, then green) for the new code.

- `test/demo.test.mjs` (Node's built-in runner) for `makeDemoContent`: 4 zones kept and their
  names; companions Grum, Lumen, Husk only; tiers 0 to 3 only; events kept and dropped by
  zone and by tier (including `brood` at tier 3 kept and `nyx` at tier 6 dropped); demo title
  and save slot; `meta.demo` present with an empty `storeUrl`; the input object unchanged.
- **Leak check** (added to `scripts/scan-sale-build.mjs`, or a sibling script run by
  `npm run scan`): the built `dist/undermoot-demo.html` must contain none of: zone names 5 to
  12, their boss names, the names of dropped companions and tiers, and the titles of dropped
  story beats. Checked to fail against the sale build as a sanity test.
- The book-name scan also runs on the demo file.
- `test/progression.cjs` also simulates the demo pack; all 4 zones must be beatable.
- **In the browser, end to end** (the Claude app's browser pane is fine for this; it is not a
  frame-rate test): import a save at Bramble Sinks with the boss beaten, try to move on, check
  the end screen and its code; check "Keep playing" returns to the colony and the screen comes
  back; then import that code into the full sale build and confirm it continues at zone 5,
  The Long Dig.
- Existing checks still pass: unit tests, progression, the sale build's name scan, and the
  sale and personal builds still build.

## Out of scope

- The itch.io page, pricing and the store link itself (the setting exists; it stays empty).
- Any change to gameplay, balance or the sale build.
- Protection beyond not shipping the content: the save code is plain base64 and can be
  edited, but in the demo there is nothing past zone 4 to unlock.

## Files

New: `src/demo.js`, `test/demo.test.mjs`. Changed: `vite.config.js`, `package.json`,
`scripts/name-output.mjs`, `scripts/scan-sale-build.mjs` (or a new scan script),
`test/progression.cjs`, `src/engine.js`, `index.html`, `src/style.css`, `README.md`.
