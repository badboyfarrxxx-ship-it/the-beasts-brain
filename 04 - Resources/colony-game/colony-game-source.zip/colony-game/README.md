# Colony game — source project

One game engine, two content packs.

- **personal** — flavoured with names and events from RinoZ's *Chrysalis* (Books 1–5).
  Private use only: don't sell, publish or redistribute this build.
- **sale** — *Undermoot: Rise of the Swarm*. Entirely original world, species, names
  and story. Nothing from the books is in this build. This is the one you can sell.

## Setup

```bash
npm install
```

Installs three.js and Vite from npm, the way the three.js docs recommend
(https://threejs.org/docs/manual/en/introduction/Installation.html).

## Develop

```bash
npm run dev          # dev server with hot reload, builds the "sale" pack
GAME_PACK=personal npm run dev
```

## Build

```bash
npm run build            # builds all three packs
npm run build:personal   # -> dist/personal/index.html
npm run build:sale       # -> dist/sale/index.html
npm run build:demo       # -> dist/demo/index.html, the free demo (zones 1 to 4)
```

Each build is one self-contained HTML file — three.js, the engine, the art and the
content pack are all inlined, so it runs offline by double-clicking it, and there's
nothing to host. Vite tree-shakes three.js, so only the parts the game actually uses
get bundled — about 634 KB per build, against 670 KB for the full library alone.

### The demo

`GAME_PACK=demo` builds the free demo: the sale game cut to its first four zones by
`src/demo.js` (`makeDemoContent`). The cut happens before bundling, so the later zones,
their creatures and bosses, the companions and tiers past Twinmind Ant, and the story
beats after zone 4 are not in the demo file at all. `npm run scan` checks this.

Beating the Bramble Sinks boss and moving on shows the demo's end screen: the player's
save code with a Copy button and a line explaining how to import it into the full game,
which carries on at zone 5. The end-screen wording and the store link
(`meta.demo.storeUrl`, empty until the store page exists; the "Get the full game" button
is hidden while it's empty) are set in `src/demo.js`.

Saves are clamped to the build that loads them (`src/saveguard.js`), so a full-game code
pasted into the demo lands at Bramble Sinks instead of crashing.

## Controls

Keyboard: W/S or Up/Down to walk, A/D or Left/Right to turn.

Touch: drag anywhere on the view for a thumbstick — up/down walks, left/right turns.
It appears wherever your finger lands, so there's no fixed pad to hunt for. The
controls default on for touch devices and can be toggled from the world HUD; the
choice is remembered per browser. On a portrait screen the camera automatically
widens and pulls back so you can still see what's ahead.

Both input paths feed the same two axes in `world3d.js`, so a gamepad or any other
source only needs to set `move` and `turn`.

## Content

Each zone has two or three creature types plus a boss. Companions join as you climb
the tiers, and story beats fire once each as you hit levels, tiers and zones (tracked
in the save, so they never repeat). All of it lives in `content.*.json`; the code has
no names in it at all.

| Pack | Zones | Creature types | Bosses | Companions | Story beats |
|------|-------|----------------|--------|------------|-------------|
| sale (Undermoot) | 12 | 34 | 12 | 6 | 13 |
| personal | 10 | 28 | 10 | 5 | 10 |

Undermoot runs to a finished ending: the last two zones follow the Sleeper cult down
to the world's core, and beating the final boss replaces the "you've gone as deep as
this build goes" message with a closing scene.

## Progression

Enemy power rises about 3.3x per zone (8 at the start, 4.2 million by Undermoot's
final zone), and each boss is about 4.5x its zone's toughest creature. A zone's
toughest creature is about 0.75x the previous boss, so you arrive able to hunt.

Hero power and XP-per-level both grow geometrically, XP slightly faster, so every zone
takes a steady 10–50 fights: about 290 fights to finish Undermoot, ending near level
51 (the top tier is 48). The curve is set per pack under `progression` in the content
file:

```json
"progression": { "xpBase": 20, "xpGrowth": 1.34, "powerBase": 8, "powerGrowth": 1.25 }
```

Before this was tuned, power grew linearly with level while XP grew geometrically,
and both packs stalled around zone 6 (tens of thousands of fights, then effectively
never). `test/progression.cjs` now simulates a full playthrough of each pack and
fails if any zone stops being finishable, so a content edit can't quietly reintroduce
that. It models hunts as attack-only (mana refills slowly) with win odds measured
from the battle code: about 0.8x the enemy's power wins reliably, 0.65x is a coin-flip.
Bosses are modelled with a full mana bar, where 0.5x wins ~97% of the time.

## Looks

The world is rendered with physically-based materials lit by an image-based
environment (three.js `RoomEnvironment`, generated at runtime — no HDR files), ACES
filmic tone mapping, and shadow mapping. Ground, rock and carapace textures are
generated from value noise onto a canvas at load: colour, roughness and normal maps,
so surfaces have real relief instead of flat colour. The terrain is a displaced mesh,
not a plane, and creatures are placed on its surface.

### Adaptive quality

Per-pixel shading is what kills weak GPUs, so the world samples its own frame rate
after mounting and steps features down until it runs smoothly — render scale, then
shadows, then the environment map, then clearcoat and normal maps on every material.
Four tiers, and it only ever steps down, so it can't oscillate. Two slow samples are
required before a step, so one compile hitch doesn't cost you shadows.

On the headless software rasteriser used by the tests, this took the scene from
1.9 fps to 17 fps. `WORLD3D.setQuality(0..3)` pins a tier by hand.

**No graphics driver.** When the browser has no real GPU to draw with (the renderer is
Windows' "Microsoft Basic Render Driver", Chrome's SwiftShader or Mesa's llvmpipe), the
3D world is slow at any tier. `src/gpu.js` detects this on mount; the world then starts
at tier 3 straight away and shows a dismissible notice under the top bar explaining that
a graphics driver is missing. `WORLD3D.debug().softwareRendering` reports it. A computer
with a real GPU sees no change. Found on real hardware (an HP all-in-one with no NVIDIA
driver ran at 3 to 11 fps), 2026-09-22.

## Creature reference page

```bash
npm run preview          # opens /preview.html
```

Lines all fourteen creature shapes up in a row, lit, rotating, with the walk cycle
running. Use it when tweaking the procedural models, or to match a .glb you're building to
the scale and facing the game expects.

## Real 3D models

Creatures are procedural by default — no asset files needed. To use modelled
characters instead:

```bash
npm run models           # writes src/models/<kind>.glb for all fourteen creatures
```

Those are the game's own shapes exported as .glb: correct scale, facing and
feet-on-floor, so they're usable starting points to open in Blender. Replace one,
export it back, then register it in `src/models.js`:

```js
import antUrl from "./models/ant.glb?url";
export const MODELS = { ...blank, ant: antUrl };
```

Vite inlines the .glb into the single-file build, so it still runs offline. Anything
left `null` keeps using the procedural shape, and a model that fails to load falls
back to it too with a console warning. A loaded model keeps its own materials, so it
ignores the content pack's colour palette.

## Test

```bash
npm test                 # progression check, then the browser smoke test
npm run test:unit        # unit tests (Node's built-in runner, no browser needed)
npm run scan             # book names in sale and demo, paid content in the demo
```

`test/gpu.test.mjs` covers the software-renderer detection in `src/gpu.js`, using the real
renderer strings seen on test machines.

`scripts/scan-sale-build.mjs` collects every capitalised name the personal content uses
and the sale content doesn't, and fails if any of them appears in the built sale file.
Generic game words shared by both builds' UI (currently only "Mana") are listed as
exceptions in the script.

**On Windows:** the `build:*` scripts set `GAME_PACK=...` the Unix way, which `npm run`
under cmd.exe doesn't understand. Run the steps in Git Bash instead:
`GAME_PACK=sale npx vite build --outDir dist/sale && node scripts/name-output.mjs sale`
(and the same with `personal`). `test/smoke.cjs` loads Playwright from a Linux path
(`/home/claude/...`), so it only runs where that exists.

`test/progression.cjs` runs first and needs no build: it simulates a playthrough of
each content pack (see Progression above).

`test/smoke.cjs` drives both built files in a headless browser: hunts, digs, fuses cores, loads a
mid-game save, dismisses story beats, opens the 3D world, checks the zone roster and
content shape, walks and turns with the keyboard, drags the thumbstick to walk and turn
and checks the player stops on release, toggles the touch controls, collides with a
creature and with the boss, checks the battle hands back to the world, and asserts
there are no console errors. 24 checks per build.

## Layout

```
index.html              markup shell; <title> is injected at build time
vite.config.js          picks the content pack via the "@content" alias
src/
  main.js               entry point
  engine.js             game state, economy, levelling, turn-based battle
  world3d.js            three.js scene, camera, movement, collisions, glb loading,
                        terrain, lighting and the adaptive-quality watchdog
  creatures.js          the fourteen procedural creature models + walk-cycle animation
  textures.js           noise-generated colour/roughness/normal maps and terrain height
  models.js             optional .glb registry (all null = fully procedural)
  models/               exported .glb starting points (npm run models)
  touch.js              on-screen thumbstick (Pointer Events: touch, pen, mouse)
  avatars.js            2D SVG portraits (procedural, no image files)
  preview.js            dev-only creature reference page
  style.css
  content.personal.json  ─┐ all names, flavour text, zones, enemies, bosses,
  content.sale.json      ─┘ tiers and numbers live here — the code has none
test/progression.cjs    playthrough simulation of every content pack
test/smoke.cjs          headless-browser test of both built files
scripts/export-models.mjs
scripts/name-output.mjs
preview.html
```

The engine, world and avatar code contain no world-specific names at all. To make
another version of the game, add a `content.*.json` and point `GAME_PACK` at it.

## Content pack shape

```jsonc
{
  "meta":    { "title", "tagline", "heroName", "heroAvatar", "saveSlug", "colors" },
  "progression": { "xpBase", "xpGrowth", "powerBase", "powerGrowth" },  // optional
  "tiers":   [ { "name", "reqLevel", "powerMult", "unlocksQueen", "unlocksEggChoice", "flavor" } ],
  "zones":   [ { "name", "desc", "flavor",
                 "enemies": [ { "name", "avatar", "power", "xpReward",
                                "biomassReward", "coreChance" } ],
                 "bossName", "bossAvatar", "bossPower", "bossXp", "bossFlavor" } ],
  "companions": [ { "name", "desc", "avatar", "unlockTier", "powerMult" } ],
  "eggChoice":  { "title", "desc", "optionA", "optionB" },
  "events":     [ { "id", "when": { "level", "zone", "tier" }, "title", "text", "logLine" } ],
  "strings":    { /* every line of UI and log text */ }
}
```

`avatar` / `heroAvatar` / `bossAvatar` and each entry in a zone's `enemies` array pick
a creature shape, used for both the 2D portrait and the 3D model. Available shapes:
`ant`, `crawler`, `beast`, `tendril`, `vine`, `croc`, `marauder`, `golem`, `beetle`,
`worm`, `spider`, `wisp`, `serpent`, `demon`.

A zone's `enemies` array is the roster: hunting picks from it at random, and the 3D
world spawns a mix. Each entry carries its own power and rewards. Story beats live in
`events`, each with an `id`, a `when` ({level, zone, tier, bossesDown} — all optional),
a `title`, `text` and a one-line `logLine`.

## Licence note

three.js is MIT licensed. The personal pack's content is derived from a copyrighted
novel series and is for private use only; the sale pack is original work.
