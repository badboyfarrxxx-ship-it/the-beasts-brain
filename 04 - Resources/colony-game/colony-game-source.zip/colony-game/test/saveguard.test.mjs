/* Unit tests for src/saveguard.js. Run with: node --test test/saveguard.test.mjs */
import { test } from "node:test";
import assert from "node:assert/strict";
import { clampToContent } from "../src/saveguard.js";

const content = {
  zones: [{ name: "A" }, { name: "B" }, { name: "C" }, { name: "D" }],
  tiers: [{ name: "t0" }, { name: "t1" }, { name: "t2" }, { name: "t3" }],
  companions: [{ name: "Grum" }, { name: "Lumen" }, { name: "Husk" }]
};

test("a save from further in the full game is pulled back to the last zone and tier", () => {
  const s = clampToContent({ zoneIndex: 8, tierIndex: 5, companions: [] }, content);
  assert.equal(s.zoneIndex, 3);
  assert.equal(s.tierIndex, 3);
});

test("companions this build doesn't have are dropped, known ones kept in order", () => {
  const s = clampToContent({ zoneIndex: 0, tierIndex: 0, companions: ["Grum", "Vex", "Husk", "Nyx"] }, content);
  assert.deepEqual(s.companions, ["Grum", "Husk"]);
});

test("a save that already fits is returned unchanged", () => {
  const input = { zoneIndex: 2, tierIndex: 1, companions: ["Lumen"], level: 9 };
  assert.deepEqual(clampToContent(input, content), input);
});

test("negative or missing indexes become 0", () => {
  const s = clampToContent({ zoneIndex: -2, companions: [] }, content);
  assert.equal(s.zoneIndex, 0);
  assert.equal(s.tierIndex, 0);
});

test("the input object is not modified", () => {
  const input = { zoneIndex: 9, tierIndex: 6, companions: ["Vex"] };
  clampToContent(input, content);
  assert.deepEqual(input, { zoneIndex: 9, tierIndex: 6, companions: ["Vex"] });
});
