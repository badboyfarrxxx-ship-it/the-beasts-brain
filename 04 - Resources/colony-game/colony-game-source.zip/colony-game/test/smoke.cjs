/* Smoke test for both built single-file games: 2D flow, 3D world, battles.
   Run with:  node test/smoke.cjs                                            */
const { chromium } = require("/home/claude/.npm-global/lib/node_modules/playwright");
const path = require("path");

/* Each build's expected content shape. The packs don't have to match: Undermoot
   runs two zones and one companion further than the fan build. */
const FILES = {
  "dist/chrysalis-fan-game-personal-use.html": { zones: 10, companions: 5 },
  "dist/undermoot-rise-of-the-swarm.html":     { zones: 12, companions: 6 }
};

const measureFps = page => page.evaluate(() => new Promise(res => {
  let f = 0; const s = performance.now();
  const tick = () => { f++; performance.now() - s < 900 ? requestAnimationFrame(tick) : res(f/((performance.now()-s)/1000)); };
  requestAnimationFrame(tick);
}));

/* Story beats interrupt with a modal; a player clicks Continue, so does the test. */
async function dismissStories(page, max = 6){
  for(let i = 0; i < max; i++){
    const open = await page.evaluate(() =>
      document.getElementById("storyModal").classList.contains("open"));
    if(!open) return i;
    await page.click("#storyContinueBtn");
    await page.waitForTimeout(120);
  }
  return max;
}

const isBattleOpen = page =>
  page.evaluate(() => document.getElementById("battleModal").classList.contains("open"));

async function fightToEnd(page, max = 16){
  for(let r = 0; r < max; r++){
    if(!(await isBattleOpen(page))) return true;
    await page.click("#battleAttackBtn");
    await page.waitForTimeout(50);
  }
  return !(await isBattleOpen(page));
}

(async () => {
  const browser = await chromium.launch({
    executablePath: "/opt/pw-browsers/chromium",
    args: ["--use-gl=angle", "--use-angle=swiftshader", "--enable-unsafe-swiftshader"]
  });
  let failures = 0;
  const check = (label, cond) => {
    console.log(`  ${cond ? "PASS" : "FAIL"}  ${label}`);
    if(!cond) failures++;
  };

  for(const [file, expect] of Object.entries(FILES)){
    const page = await browser.newPage({ viewport: { width: 900, height: 700 } });
    const errors = [];
    page.on("pageerror", e => errors.push("PAGEERROR: " + e.message));
    page.on("console", m => { if(m.type() === "error") errors.push("CONSOLE: " + m.text()); });

    await page.goto("file://" + path.resolve(file));
    await page.waitForTimeout(300);
    console.log("\n=== " + file);
    const openingBeats = await dismissStories(page);
    check("opening story beat shown", openingBeats > 0);
    check("title set at build time", (await page.title()).length > 5);
    check("hero avatar rendered",
      (await page.evaluate(() => document.getElementById("heroAvatarBox").innerHTML.length)) > 100);

    // --- 2D flow ---
    for(let i = 0; i < 3; i++){
      await page.click("#huntBtn");
      await page.waitForTimeout(70);
      await fightToEnd(page);
    }
    await dismissStories(page);
    check("levelled up from hunting", Number(await page.textContent("#levelVal")) >= 1);
    await page.click("#digBtn");
    await page.click("#fuseBtn");
    await page.waitForTimeout(80);

    // --- load a mid-game save so companions/tier exist ---
    const save = {
      level: 18, xp: 0, biomass: 900, mana: 100,
      cores: { normal: 9, special: 3, rare: 2 },
      tierIndex: 3, zoneIndex: 1, workers: 5, queenUnlocked: true,
      eggChoice: "might", companions: [], flags: {}, bossesDown: ["x"], log: ["t"]
    };
    // companion names differ per pack — pull them from the page's own content
    save.companions = await page.evaluate(() => window.GAME_CONTENT.companions.map(c => c.name));
    const code = await page.evaluate(o => btoa(unescape(encodeURIComponent(JSON.stringify(o)))), save);
    await page.fill("#saveText", code);
    await page.click("#importBtn");
    await page.waitForTimeout(150);
    await dismissStories(page);

    // --- 3D world ---
    await page.click("#worldBtn");
    await page.waitForTimeout(900);
    /* Pin the lightest quality tier. These checks are about game logic, and the
       headless software renderer is far slower than any real GPU — at full
       quality it can't produce enough frames to measure movement reliably. */
    await page.evaluate(() => window.WORLD3D.setQuality(3));
    await page.waitForTimeout(600);
    // two samples, take the better: a single one can land inside a GC pause
    const steady = Math.max(await measureFps(page), await measureFps(page));
    const d = await page.evaluate(() => window.WORLD3D.debug());
    check("3D world mounted", !!d);
    /* Bar is deliberately low: this runs on a CPU rasteriser, which is orders of
       magnitude slower than any real GPU. It exists to catch a collapse (before
       the quality tiers existed this scene ran at 1.9 fps here), not to measure
       real-world performance. */
    check("lowest quality tier doesn't collapse", steady > 4);
    check("enemies spawned", d.enemies.length === 6);
    check("zone lists several creature types",
      (await page.textContent("#enemyName")).split(",").length >= 2);
    check(`content pack has ${expect.zones} zones`,
      await page.evaluate(n => window.GAME_CONTENT.zones.length === n, expect.zones));
    check(`content pack has ${expect.companions} companions`,
      await page.evaluate(n => window.GAME_CONTENT.companions.length === n, expect.companions));
    check("boss spawned ahead of player", d.boss && d.boss.z > 0);
    check("companions follow you in 3D", d.companions === expect.companions);

    check("quality watchdog picked a level", typeof d.quality === "number" && d.quality >= 0);

    /* Hold forward and see if we covered ground. Walking into a creature also
       counts: it proves movement happened and the collision fired. Under the
       software renderer a single sample can land inside a stall, so allow one
       retry before calling it a failure. */
    const walkTest = async () => {
      const from = await page.evaluate(() => window.WORLD3D.debug());
      await page.keyboard.down("ArrowUp");
      await page.waitForTimeout(800);
      await page.keyboard.up("ArrowUp");
      if(await isBattleOpen(page)) return true;
      const to = await page.evaluate(() => window.WORLD3D.debug());
      return Math.hypot(to.player.x - from.player.x, to.player.z - from.player.z) > 0.5;
    };
    let walked = await walkTest();
    if(!walked) walked = await walkTest();
    check("player walks with keyboard", walked);
    const d2 = await page.evaluate(() => window.WORLD3D.debug());

    /* Walking may have bumped into a creature or tripped a story beat; both pause
       the world, so clear them before measuring, and allow one retry. */
    const turnTest = async () => {
      if(await isBattleOpen(page)){ await fightToEnd(page); await page.waitForTimeout(500); }
      await dismissStories(page);
      const from = await page.evaluate(() => window.WORLD3D.debug());
      await page.keyboard.down("ArrowLeft");
      await page.waitForTimeout(600);
      await page.keyboard.up("ArrowLeft");
      const to = await page.evaluate(() => window.WORLD3D.debug());
      return Math.abs(to.player.rot - from.player.rot) > 0.1;
    };
    let turned = await turnTest();
    if(!turned) turned = await turnTest();
    check("player turns with keyboard", turned);

    await page.evaluate(() => {
      const dd = window.WORLD3D.debug();
      window.WORLD3D.teleport(dd.enemies[0].x + 0.4, dd.enemies[0].z);
    });
    await page.waitForTimeout(400);
    check("walking into a creature starts a battle", await isBattleOpen(page));
    await fightToEnd(page);
    await page.waitForTimeout(800);
    await dismissStories(page);
    check("world resumes after the battle",
      (await page.evaluate(() => window.WORLD3D.debug())).paused === false);

    await page.evaluate(() => {
      const dd = window.WORLD3D.debug();
      window.WORLD3D.teleport(dd.boss.x + 1.5, dd.boss.z);
    });
    await page.waitForTimeout(400);
    check("walking into the boss starts the boss fight", await isBattleOpen(page));
    await page.click("#battleFleeBtn");
    await page.waitForTimeout(150);
    await dismissStories(page);
    await page.click("#worldCloseBtn");
    await page.waitForTimeout(150);
    // --- touch controls (driven with pointer events, same path a finger takes) ---
    await page.click("#worldBtn");
    await page.waitForTimeout(500);
    await page.evaluate(() => window.WORLD3D.setTouchControls(true));
    const box = await page.locator("#world3dCanvas").boundingBox();
    const cx = box.x + box.width/2, cy = box.y + box.height/2;

    const before = await page.evaluate(() => window.WORLD3D.debug());
    await page.mouse.move(cx, cy);
    await page.mouse.down();
    await page.mouse.move(cx, cy - 70, { steps: 4 });   // push the stick up = forward
    await page.waitForTimeout(500);
    const during = await page.evaluate(() => window.WORLD3D.debug());
    check("thumbstick up walks the player forward",
      Math.hypot(during.player.x - before.player.x, during.player.z - before.player.z) > 0.5);

    await page.mouse.move(cx + 70, cy, { steps: 4 });   // push it right = turn right
    await page.waitForTimeout(400);
    const stickTurned = await page.evaluate(() => window.WORLD3D.debug());
    check("thumbstick sideways turns the player",
      Math.abs(stickTurned.player.rot - during.player.rot) > 0.1);

    await page.mouse.up();
    await page.waitForTimeout(400);
    const released = await page.evaluate(() => window.WORLD3D.debug());
    await page.waitForTimeout(400);
    const settled = await page.evaluate(() => window.WORLD3D.debug());
    check("player stops when the stick is released",
      Math.hypot(settled.player.x - released.player.x, settled.player.z - released.player.z) < 0.05);

    check("touch toggle flips and restores state",
      await page.evaluate(() => {
        const b = document.getElementById("touchToggleBtn");
        const start = b.classList.contains("on");
        b.click();
        const flipped = b.classList.contains("on") !== start;
        b.click();
        const restored = b.classList.contains("on") === start;
        const labelled = /Touch controls: (on|off)/.test(b.textContent);
        return flipped && restored && labelled;
      }));

    await page.click("#worldCloseBtn");
    await page.waitForTimeout(150);
    check("back to colony view",
      await page.evaluate(() => !document.getElementById("worldModal").classList.contains("open")));
    check("no console or page errors", errors.length === 0);
    if(errors.length) console.log("   ", errors.slice(0, 3));
    await page.close();
  }

  await browser.close();
  console.log(failures === 0 ? "\nAll checks passed." : `\n${failures} check(s) FAILED.`);
  process.exit(failures === 0 ? 0 : 1);
})();
