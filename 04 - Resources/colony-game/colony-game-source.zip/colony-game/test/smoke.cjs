/* Smoke test for both built single-file games: 2D flow, 3D world, battles.
   Run with:  node test/smoke.cjs                                            */
const fs = require("fs");
const path = require("path");
const { pathToFileURL } = require("url");

/* Playwright: the project's own devDependency (npm install, then
   npx playwright install chromium), or the cloud session's global copy. */
const CLOUD_PLAYWRIGHT = "/home/claude/.npm-global/lib/node_modules/playwright";
const CLOUD_CHROMIUM = "/opt/pw-browsers/chromium";
let chromium;
try { ({ chromium } = require("playwright")); }
catch(e){ ({ chromium } = require(CLOUD_PLAYWRIGHT)); }

/* Each build's expected content shape. The packs don't have to match: Undermoot
   runs two zones and one companion further than the fan build, and the demo
   stops after zone 4 with its own end screen (see demoChecks). */
const SALE_FILE = "dist/undermoot-rise-of-the-swarm.html";
const FILES = {
  "dist/chrysalis-fan-game-personal-use.html": { zones: 10, companions: 5 },
  [SALE_FILE]:                                 { zones: 12, companions: 6 },
  "dist/undermoot-demo.html":                  { zones: 4, companions: 3, demo: true }
};

const pageUrl = file => pathToFileURL(path.resolve(file)).href;
const importCode = async (page, code) => {
  await page.fill("#saveText", code);
  await page.click("#importBtn");
  await page.waitForTimeout(150);
};
const isOpen = (page, id) =>
  page.evaluate(id => document.getElementById(id).classList.contains("open"), id);

const measureFps = page => page.evaluate(() => new Promise(res => {
  let f = 0; const s = performance.now();
  const tick = () => { f++; performance.now() - s < 900 ? requestAnimationFrame(tick) : res(f/((performance.now()-s)/1000)); };
  requestAnimationFrame(tick);
}));

/* Story beats interrupt with a modal; a player clicks Continue, so does the test. */
async function dismissStories(page, max = 6){
  for(let i = 0; i < max; i++){
    const open = await page.evaluate(() =>
      document.getElementById("storyModal").classList.contains("open"));
    if(!open) return i;
    await page.click("#storyContinueBtn");
    await page.waitForTimeout(120);
  }
  return max;
}

const isBattleOpen = page =>
  page.evaluate(() => document.getElementById("battleModal").classList.contains("open"));

async function fightToEnd(page, max = 16){
  for(let r = 0; r < max; r++){
    if(!(await isBattleOpen(page))) return true;
    await page.click("#battleAttackBtn");
    await page.waitForTimeout(50);
  }
  return !(await isBattleOpen(page));
}

/* The demo's ending: beat the zone 4 boss, get the end screen and its save
   code, and carry that code into the full game. */
async function demoChecks(browser, page, check, errors){
  // start at the last demo zone with the first three bosses down
  const save = await page.evaluate(() => {
    const C = window.GAME_CONTENT;
    return {
      level: 60, xp: 0, biomass: 900, mana: 100,
      cores: { normal: 9, special: 3, rare: 2 },
      tierIndex: C.tiers.length - 1, zoneIndex: C.zones.length - 1, workers: 5,
      queenUnlocked: true, eggChoice: "might",
      companions: C.companions.map(c => c.name), flags: {},
      bossesDown: C.zones.slice(0, -1).map(z => z.name), log: ["t"]
    };
  });
  await importCode(page, await page.evaluate(o => btoa(unescape(encodeURIComponent(JSON.stringify(o)))), save));
  await dismissStories(page);

  await page.click("#bossBtn");
  await page.waitForTimeout(80);
  check("demo: last boss fight starts from the colony", await isBattleOpen(page));
  await fightToEnd(page, 40);
  await page.waitForTimeout(150);
  await dismissStories(page);
  check("demo: last boss beaten", !(await isBattleOpen(page)));

  await page.click("#bossBtn");
  await page.waitForTimeout(150);
  check("demo: end screen opens after the last boss", await isOpen(page, "demoEndModal"));
  const end = await page.evaluate(() => ({
    title: document.getElementById("demoEndTitle").textContent,
    want: window.GAME_CONTENT.meta.demo.end.title,
    buyHidden: document.getElementById("demoEndBuyBtn").hidden,
    code: document.getElementById("demoEndCode").value
  }));
  check("demo: end screen text comes from the content", end.title.length > 5 && end.title === end.want);
  check("demo: buy button hidden while there is no store link", end.buyHidden === true);
  let carried = null;
  try{ carried = JSON.parse(Buffer.from(end.code, "base64").toString("utf8")); }catch(e){}
  check("demo: save code holds the finished demo",
    !!carried && carried.zoneIndex === save.zoneIndex && carried.bossesDown.length === save.bossesDown.length + 1);

  await page.click("#demoEndKeepBtn");
  await page.waitForTimeout(100);
  check("demo: keep playing closes the end screen", !(await isOpen(page, "demoEndModal")));

  // the old bug: a colony hunt woke the hidden world, which touched the boss
  // and reopened the end screen
  await page.click("#huntBtn");
  await page.waitForTimeout(70);
  await page.click("#battleFleeBtn");
  await page.waitForTimeout(600);
  await dismissStories(page);
  check("demo: a colony hunt doesn't reopen the end screen", !(await isOpen(page, "demoEndModal")));

  // reaching the boss in the 3D world closes the world and shows the end screen.
  // Wait on state, not a fixed time: frames on the software renderer can be
  // far apart.
  await page.click("#worldBtn");
  await page.waitForFunction(() => window.WORLD3D.debug().open === true, null, { timeout: 5000 });
  await page.evaluate(() => {
    const dd = window.WORLD3D.debug();
    window.WORLD3D.teleport(dd.boss.x + 1.5, dd.boss.z);
  });
  await page.waitForFunction(() => document.getElementById("demoEndModal").classList.contains("open"),
    null, { timeout: 5000 }).catch(() => {});
  const fromWorld = await page.evaluate(() => ({
    end: document.getElementById("demoEndModal").classList.contains("open"),
    world: document.getElementById("worldModal").classList.contains("open"),
    paused: window.WORLD3D.debug().paused,
    open: [...document.querySelectorAll(".modalWrap.open")].map(m => m.id)
  }));
  check("demo: touching the last boss in 3D shows the end screen",
    fromWorld.end && !fromWorld.world && fromWorld.paused);
  if(!fromWorld.end) console.log("    open modals:", fromWorld.open.join(", ") || "none");
  if(fromWorld.end){ await page.click("#demoEndKeepBtn"); await page.waitForTimeout(100); }

  // the code carries into the full game
  const full = await browser.newPage({ viewport: { width: 900, height: 700 } });
  full.on("pageerror", e => errors.push("FULL GAME PAGEERROR: " + e.message));
  full.on("console", m => { if(m.type() === "error") errors.push("FULL GAME CONSOLE: " + m.text()); });
  await full.goto(pageUrl(SALE_FILE));
  await full.waitForTimeout(300);
  await dismissStories(full);
  await importCode(full, end.code);
  await dismissStories(full);
  const lastZone = await page.evaluate(() => window.GAME_CONTENT.zones.at(-1).name);
  const got = { zone: await full.textContent("#zoneName"), level: Number(await full.textContent("#levelVal")) };
  check("demo: save code loads in the full game at the same place",
    !!carried && got.zone === lastZone && got.level === carried.level);
  await full.close();
}

(async () => {
  const browser = await chromium.launch({
    ...(fs.existsSync(CLOUD_CHROMIUM) ? { executablePath: CLOUD_CHROMIUM } : {}),
    args: ["--use-gl=angle", "--use-angle=swiftshader", "--enable-unsafe-swiftshader"]
  });
  let failures = 0;
  const check = (label, cond) => {
    console.log(`  ${cond ? "PASS" : "FAIL"}  ${label}`);
    if(!cond) failures++;
  };

  for(const [file, expect] of Object.entries(FILES)){
    const page = await browser.newPage({ viewport: { width: 900, height: 700 } });
    const errors = [];
    page.on("pageerror", e => errors.push("PAGEERROR: " + e.message));
    page.on("console", m => { if(m.type() === "error") errors.push("CONSOLE: " + m.text()); });

    await page.goto(pageUrl(file));
    await page.waitForTimeout(300);
    console.log("\n=== " + file);
    const openingBeats = await dismissStories(page);
    check("opening story beat shown", openingBeats > 0);
    check("title set at build time", (await page.title()).length > 5);
    check("hero avatar rendered",
      (await page.evaluate(() => document.getElementById("heroAvatarBox").innerHTML.length)) > 100);

    // --- 2D flow ---
    for(let i = 0; i < 3; i++){
      await page.click("#huntBtn");
      await page.waitForTimeout(70);
      await fightToEnd(page);
    }
    await dismissStories(page);
    check("levelled up from hunting", Number(await page.textContent("#levelVal")) >= 1);
    await page.click("#digBtn");
    await page.click("#fuseBtn");
    await page.waitForTimeout(80);

    // --- load a mid-game save so companions/tier exist ---
    const save = {
      level: 18, xp: 0, biomass: 900, mana: 100,
      cores: { normal: 9, special: 3, rare: 2 },
      tierIndex: 3, zoneIndex: 1, workers: 5, queenUnlocked: true,
      eggChoice: "might", companions: [], flags: {}, bossesDown: ["x"], log: ["t"]
    };
    // companion names differ per pack — pull them from the page's own content
    save.companions = await page.evaluate(() => window.GAME_CONTENT.companions.map(c => c.name));
    const code = await page.evaluate(o => btoa(unescape(encodeURIComponent(JSON.stringify(o)))), save);
    await page.fill("#saveText", code);
    await page.click("#importBtn");
    await page.waitForTimeout(150);
    await dismissStories(page);

    // --- 3D world ---
    await page.click("#worldBtn");
    await page.waitForTimeout(900);
    /* Pin the lightest quality tier. These checks are about game logic, and the
       headless software renderer is far slower than any real GPU — at full
       quality it can't produce enough frames to measure movement reliably. */
    await page.evaluate(() => window.WORLD3D.setQuality(3));
    await page.waitForTimeout(600);
    // two samples, take the better: a single one can land inside a GC pause
    const steady = Math.max(await measureFps(page), await measureFps(page));
    const d = await page.evaluate(() => window.WORLD3D.debug());
    check("3D world mounted", !!d);
    /* Bar is deliberately low: this runs on a CPU rasteriser, which is orders of
       magnitude slower than any real GPU. It exists to catch a collapse (before
       the quality tiers existed this scene ran at 1.9 fps here), not to measure
       real-world performance. */
    check("lowest quality tier doesn't collapse", steady > 4);
    if(!(steady > 4)) console.log("    measured", steady.toFixed(1), "fps");
    check("enemies spawned", d.enemies.length === 6);
    check("zone lists several creature types",
      (await page.textContent("#enemyName")).split(",").length >= 2);
    check(`content pack has ${expect.zones} zones`,
      await page.evaluate(n => window.GAME_CONTENT.zones.length === n, expect.zones));
    check(`content pack has ${expect.companions} companions`,
      await page.evaluate(n => window.GAME_CONTENT.companions.length === n, expect.companions));
    check("boss spawned ahead of player", d.boss && d.boss.z > 0);
    check("companions follow you in 3D", d.companions === expect.companions);

    check("quality watchdog picked a level", typeof d.quality === "number" && d.quality >= 0);

    /* Hold forward and see if we covered ground. Walking into a creature also
       counts: it proves movement happened and the collision fired. Under the
       software renderer a single sample can land inside a stall, so allow one
       retry before calling it a failure. */
    const walkTest = async () => {
      const from = await page.evaluate(() => window.WORLD3D.debug());
      await page.keyboard.down("ArrowUp");
      await page.waitForTimeout(800);
      await page.keyboard.up("ArrowUp");
      if(await isBattleOpen(page)) return true;
      const to = await page.evaluate(() => window.WORLD3D.debug());
      return Math.hypot(to.player.x - from.player.x, to.player.z - from.player.z) > 0.5;
    };
    let walked = await walkTest();
    if(!walked) walked = await walkTest();
    check("player walks with keyboard", walked);
    const d2 = await page.evaluate(() => window.WORLD3D.debug());

    /* Walking may have bumped into a creature or tripped a story beat; both pause
       the world, so clear them before measuring, and allow one retry. */
    const turnTest = async () => {
      if(await isBattleOpen(page)){ await fightToEnd(page); await page.waitForTimeout(500); }
      await dismissStories(page);
      const from = await page.evaluate(() => window.WORLD3D.debug());
      await page.keyboard.down("ArrowLeft");
      await page.waitForTimeout(600);
      await page.keyboard.up("ArrowLeft");
      const to = await page.evaluate(() => window.WORLD3D.debug());
      return Math.abs(to.player.rot - from.player.rot) > 0.1;
    };
    let turned = await turnTest();
    if(!turned) turned = await turnTest();
    check("player turns with keyboard", turned);

    await page.evaluate(() => {
      const dd = window.WORLD3D.debug();
      window.WORLD3D.teleport(dd.enemies[0].x + 0.4, dd.enemies[0].z);
    });
    await page.waitForTimeout(400);
    check("walking into a creature starts a battle", await isBattleOpen(page));
    const fightEnded = await fightToEnd(page, 40);
    /* Check inside the world's 700ms post-battle cooldown. Waiting longer let a
       second creature standing next to the player start a new battle, which
       paused the world again and failed this check about once in ten runs. */
    await page.waitForTimeout(100);
    await dismissStories(page);
    const resumed = await page.evaluate(() => ({
      paused: window.WORLD3D.debug().paused,
      open: [...document.querySelectorAll(".modalWrap.open")].map(m => m.id)
    }));
    check("world resumes after the battle", fightEnded && resumed.paused === false);
    if(resumed.paused || !fightEnded)
      console.log("    fight ended:", fightEnded, "; open modals:", resumed.open.join(", ") || "none");

    await page.evaluate(() => {
      const dd = window.WORLD3D.debug();
      window.WORLD3D.teleport(dd.boss.x + 1.5, dd.boss.z);
    });
    // the touch only fires once the post-battle cooldown ends, so wait on it
    await page.waitForFunction(() => document.getElementById("battleModal").classList.contains("open"),
      null, { timeout: 5000 }).catch(() => {});
    check("walking into the boss starts the boss fight", await isBattleOpen(page));
    await page.click("#battleFleeBtn");
    // step off the boss inside the cooldown, or it starts the fight again and
    // the battle window blocks the close button
    await page.evaluate(() => window.WORLD3D.teleport(0, 0));
    for(let i = 0; i < 3 && await isBattleOpen(page); i++){
      await page.click("#battleFleeBtn");
      await page.evaluate(() => window.WORLD3D.teleport(0, 0));
    }
    await page.waitForTimeout(150);
    await dismissStories(page);
    await page.click("#worldCloseBtn");
    await page.waitForTimeout(150);

    // a battle from the colony screen must not wake the closed 3D world
    await page.click("#huntBtn");
    await page.waitForTimeout(70);
    await page.click("#battleFleeBtn");
    await page.waitForTimeout(150);
    await dismissStories(page);
    check("closed world stays paused after a colony battle",
      (await page.evaluate(() => window.WORLD3D.debug())).paused === true);

    // --- touch controls (driven with pointer events, same path a finger takes) ---
    await page.click("#worldBtn");
    await page.waitForTimeout(500);
    await page.evaluate(() => window.WORLD3D.setTouchControls(true));
    const box = await page.locator("#world3dCanvas").boundingBox();
    const cx = box.x + box.width/2, cy = box.y + box.height/2;

    const before = await page.evaluate(() => window.WORLD3D.debug());
    await page.mouse.move(cx, cy);
    await page.mouse.down();
    await page.mouse.move(cx, cy - 70, { steps: 4 });   // push the stick up = forward
    await page.waitForTimeout(500);
    const during = await page.evaluate(() => window.WORLD3D.debug());
    check("thumbstick up walks the player forward",
      Math.hypot(during.player.x - before.player.x, during.player.z - before.player.z) > 0.5);

    await page.mouse.move(cx + 70, cy, { steps: 4 });   // push it right = turn right
    await page.waitForTimeout(400);
    const stickTurned = await page.evaluate(() => window.WORLD3D.debug());
    check("thumbstick sideways turns the player",
      Math.abs(stickTurned.player.rot - during.player.rot) > 0.1);

    await page.mouse.up();
    await page.waitForTimeout(400);
    const released = await page.evaluate(() => window.WORLD3D.debug());
    await page.waitForTimeout(400);
    const settled = await page.evaluate(() => window.WORLD3D.debug());
    check("player stops when the stick is released",
      Math.hypot(settled.player.x - released.player.x, settled.player.z - released.player.z) < 0.05);

    check("touch toggle flips and restores state",
      await page.evaluate(() => {
        const b = document.getElementById("touchToggleBtn");
        const start = b.classList.contains("on");
        b.click();
        const flipped = b.classList.contains("on") !== start;
        b.click();
        const restored = b.classList.contains("on") === start;
        const labelled = /Touch controls: (on|off)/.test(b.textContent);
        return flipped && restored && labelled;
      }));

    // the thumbstick walk can run into a creature; finish that fight before leaving
    if(await isBattleOpen(page)) await fightToEnd(page, 40);
    await dismissStories(page);
    await page.click("#worldCloseBtn");
    await page.waitForTimeout(150);
    check("back to colony view",
      await page.evaluate(() => !document.getElementById("worldModal").classList.contains("open")));
    if(expect.demo) await demoChecks(browser, page, check, errors);

    check("no console or page errors", errors.length === 0);
    if(errors.length) console.log("   ", errors.slice(0, 3));
    await page.close();
  }

  await browser.close();
  console.log(failures === 0 ? "\nAll checks passed." : `\n${failures} check(s) FAILED.`);
  process.exit(failures === 0 ? 0 : 1);
})();
