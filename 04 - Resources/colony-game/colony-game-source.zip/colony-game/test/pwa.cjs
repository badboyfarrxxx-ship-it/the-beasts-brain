/* Browser check for the installable web app: does a real browser register the
   service worker, cache the game, and still play it with the network gone?

   Run with:  node test/pwa.cjs [pack]        (default: demo)
   Needs:     node scripts/make-pwa.mjs <pack>   first

   It serves dist/pwa-<pack> over http://127.0.0.1 because service workers are
   refused on file:// pages, then drives Chromium over it. Note the Claude app's
   browser pane cannot run this: it blocks service worker script fetches, so a
   registration there fails with "an unknown error occurred when fetching the
   script" even though the same file fetches fine. */
const http = require("http");
const fs = require("fs");
const path = require("path");

const CLOUD_PLAYWRIGHT = "/home/claude/.npm-global/lib/node_modules/playwright";
const CLOUD_CHROMIUM = "/opt/pw-browsers/chromium";
let chromium;
try { ({ chromium } = require("playwright")); }
catch(e){ ({ chromium } = require(CLOUD_PLAYWRIGHT)); }

const pack = process.argv[2] || "demo";
const dir = path.resolve(__dirname, "..", "dist", `pwa-${pack}`);
const TYPES = {
  ".html": "text/html", ".js": "text/javascript",
  ".webmanifest": "application/manifest+json", ".png": "image/png"
};

function serve(){
  const server = http.createServer((req, res) => {
    const rel = decodeURIComponent(req.url.split("?")[0]).replace(/^\/+/, "") || "index.html";
    const file = path.join(dir, rel);
    if(!file.startsWith(dir)){ res.writeHead(403).end(); return; }
    fs.readFile(file, (err, body) => {
      if(err){ res.writeHead(404).end(); return; }
      res.writeHead(200, { "Content-Type": TYPES[path.extname(file)] || "application/octet-stream" });
      res.end(body);
    });
  });
  return new Promise(r => server.listen(0, "127.0.0.1", () => r(server)));
}

(async () => {
  if(!fs.existsSync(path.join(dir, "index.html"))){
    console.error(`no dist/pwa-${pack}/index.html - run: node scripts/make-pwa.mjs ${pack}`);
    process.exit(1);
  }
  const server = await serve();
  const base = `http://127.0.0.1:${server.address().port}/`;
  const browser = await chromium.launch({
    ...(fs.existsSync(CLOUD_CHROMIUM) ? { executablePath: CLOUD_CHROMIUM } : {}),
    args: ["--use-gl=angle", "--use-angle=swiftshader", "--enable-unsafe-swiftshader"]
  });
  const context = await browser.newContext({ viewport: { width: 900, height: 700 } });
  const page = await context.newPage();
  const errors = [];
  page.on("pageerror", e => errors.push("PAGEERROR: " + e.message));

  let failures = 0;
  const check = (label, cond) => {
    console.log(`  ${cond ? "PASS" : "FAIL"}  ${label}`);
    if(!cond) failures++;
  };

  console.log(`\n=== dist/pwa-${pack} served at ${base}`);
  await page.goto(base, { waitUntil: "load" });
  const registered = await page.evaluate(() =>
    navigator.serviceWorker.ready.then(r => !!r.active, () => false));
  check("service worker registers and activates", registered);

  const manifest = await page.evaluate(async () => {
    const link = document.querySelector('link[rel="manifest"]');
    if(!link) return null;
    return (await fetch(link.href)).json();
  });
  check("page links a manifest the browser can read", !!manifest);
  check("manifest names the game and has both icon sizes",
    !!manifest && manifest.name.includes("Undermoot") &&
    ["192x192", "512x512"].every(s => manifest.icons.some(i => i.sizes === s)));
  check("icons are really there",
    (await Promise.all(((manifest && manifest.icons) || []).map(i =>
      page.evaluate(u => fetch(u).then(r => r.ok), new URL(i.src, base).href)))).every(Boolean));

  const cached = await page.evaluate(async () => {
    const keys = await caches.keys();
    if(!keys.length) return [];
    const c = await caches.open(keys[0]);
    return (await c.keys()).map(r => new URL(r.url).pathname);
  });
  check("the game file is precached", cached.includes("/index.html"));

  // the real test: kill the network, reload, and see if it still plays
  await page.reload({ waitUntil: "load" });
  await context.setOffline(true);
  await page.reload({ waitUntil: "load" });
  const offline = await page.evaluate(() => ({
    content: !!window.GAME_CONTENT && window.GAME_CONTENT.zones.length,
    hunt: !!document.getElementById("huntBtn")
  }));
  check("the game loads with the network off", offline.content > 0 && offline.hunt);
  check(`offline build still has its ${offline.content} zones`, offline.content === (pack === "demo" ? 4 : offline.content));
  check("no page errors", errors.length === 0);
  if(errors.length) console.log("   ", errors.slice(0, 3));

  await context.setOffline(false);
  await browser.close();
  server.close();
  console.log(failures === 0 ? "\nAll checks passed." : `\n${failures} check(s) FAILED.`);
  process.exit(failures === 0 ? 0 : 1);
})();
