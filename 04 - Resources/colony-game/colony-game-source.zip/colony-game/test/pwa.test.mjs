/* Unit tests for the installable web app pieces (src/pwa.js).
   Run with: node --test test/pwa.test.mjs */
import { test } from "node:test";
import assert from "node:assert/strict";
import { makeManifest, makeServiceWorker, injectPwaTags, shortName, PWA_FILES } from "../src/pwa.js";

const OPTS = { title: "Undermoot: Rise of the Swarm", background: "#0b0e0c", theme: "#7fd858" };

test("short name fits under a home screen icon", () => {
  assert.equal(shortName("Undermoot: Rise of the Swarm"), "Undermoot");
  assert.equal(shortName("Undermoot: Rise of the Swarm (Demo)"), "Undermoot");
  assert.equal(shortName("Chrysalis: Colony Ascendant (fan game, personal use)"), "Chrysalis");
  assert.ok(shortName("Averyveryverylongsinglewordtitle").length <= 12);
});

test("manifest carries what a browser needs to offer an install", () => {
  const m = makeManifest(OPTS);
  assert.equal(m.name, OPTS.title);
  assert.equal(m.start_url, "./index.html");
  assert.equal(m.display, "fullscreen");
  assert.equal(m.background_color, OPTS.background);
  assert.equal(m.theme_color, OPTS.theme);
  const sizes = m.icons.map(i => i.sizes);
  assert.ok(sizes.includes("192x192") && sizes.includes("512x512"));
  assert.ok(m.icons.some(i => i.purpose === "maskable"));
  assert.ok(m.icons.every(i => i.type === "image/png"));
});

test("manifest survives a round trip through JSON", () => {
  assert.deepEqual(JSON.parse(JSON.stringify(makeManifest(OPTS))), makeManifest(OPTS));
});

test("service worker precaches the shell and answers fetches", () => {
  const sw = makeServiceWorker({ version: "abc123" });
  assert.match(sw, /const CACHE = "undermoot-abc123"/);
  assert.match(sw, /addEventListener\("fetch"/);      // required for an install prompt
  assert.match(sw, /addEventListener\("install"/);
  assert.match(sw, /addEventListener\("activate"/);
  for(const f of ["./index.html", PWA_FILES.manifest, PWA_FILES.icon192, PWA_FILES.maskable]){
    assert.ok(sw.includes(f), `shell is missing ${f}`);
  }
});

test("a new build gets a new cache, so the old game is dropped", () => {
  assert.notEqual(makeServiceWorker({ version: "one" }), makeServiceWorker({ version: "two" }));
});

test("injecting adds the manifest and registration once, keeping the game", () => {
  const html = "<html><head><title>x</title></head><body><canvas></canvas></body></html>";
  const out = injectPwaTags(html, OPTS);
  assert.equal(out.match(/rel="manifest"/g).length, 1);
  assert.equal(out.match(/serviceWorker\.register/g).length, 1);
  assert.match(out, /<meta name="theme-color" content="#7fd858">/);
  assert.ok(out.includes("<canvas></canvas>"));
  assert.ok(out.indexOf("rel=\"manifest\"") < out.indexOf("</head>"));
});

test("registration is guarded, so opening the file off disk still plays", () => {
  const out = injectPwaTags("<html><head></head><body></body></html>", OPTS);
  assert.match(out, /"serviceWorker" in navigator/);
  assert.match(out, /\.catch\(/);
});

test("a file with no head or body is refused rather than silently skipped", () => {
  assert.throws(() => injectPwaTags("<p>not a page</p>", OPTS), /no <head> or <body>/);
});
