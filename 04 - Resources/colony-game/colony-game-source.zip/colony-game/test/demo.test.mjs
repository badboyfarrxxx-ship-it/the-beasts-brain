/* Unit tests for the demo content cutter (src/demo.js).
   Run with: node --test test/demo.test.mjs */
import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { makeDemoContent } from "../src/demo.js";

const load = () => JSON.parse(readFileSync(new URL("../src/content.sale.json", import.meta.url), "utf8"));

test("keeps only the first four zones", () => {
  const d = makeDemoContent(load());
  assert.deepEqual(d.zones.map(z => z.name), ["Hollow Roots", "Sunken Warrens", "The Deep Nest", "Bramble Sinks"]);
});

test("keeps only companions a demo player can reach (tiers 1 to 3)", () => {
  const d = makeDemoContent(load());
  assert.deepEqual(d.companions.map(c => c.name), ["Grum", "Lumen", "Husk"]);
});

test("keeps tiers up to Twinmind Ant", () => {
  const d = makeDemoContent(load());
  assert.deepEqual(d.tiers.map(t => t.name), ["Larval Digger", "Bonded Worker", "Cognizant Ant", "Twinmind Ant"]);
});

test("keeps story beats for zones 1 to 4 and tiers up to 3, drops the rest", () => {
  const d = makeDemoContent(load());
  assert.deepEqual(d.events.map(e => e.id), ["wake", "wardens", "colony", "grum", "brood"]);
});

test("renames the build and gives it its own save slot", () => {
  const d = makeDemoContent(load());
  assert.equal(d.meta.title, "Undermoot: Rise of the Swarm (Demo)");
  assert.equal(d.meta.saveSlug, "undermoot_demo");
});

test("adds the demo settings with an empty store link and the end-screen text", () => {
  const d = makeDemoContent(load());
  assert.equal(d.meta.demo.storeUrl, "");
  for (const k of ["title", "text", "codeLabel", "codeHelp", "buyLabel", "keepPlayingLabel", "copyLabel", "copiedLabel"]) {
    assert.equal(typeof d.meta.demo.end[k], "string", k);
    assert.ok(d.meta.demo.end[k].length > 0, k);
  }
});

test("copies everything else unchanged", () => {
  const sale = load();
  const d = makeDemoContent(sale);
  assert.deepEqual(d.progression, sale.progression);
  assert.deepEqual(d.eggChoice, sale.eggChoice);
  assert.deepEqual(d.strings, sale.strings);
  assert.equal(d.meta.heroName, sale.meta.heroName);
});

test("does not modify the sale content it is given", () => {
  const sale = load();
  const before = JSON.stringify(sale);
  makeDemoContent(sale);
  assert.equal(JSON.stringify(sale), before);
});
