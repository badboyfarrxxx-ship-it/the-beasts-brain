/* Unit tests for software-renderer detection (src/gpu.js).
   Run with: node --test test/ */
import { test } from "node:test";
import assert from "node:assert/strict";
import { isSoftwareRenderer, rendererName } from "../src/gpu.js";

/* Node has no WebGL, so these stand in for a WebGL context: just the two
   methods rendererName uses, answering the way a real browser does. */
const UNMASKED = 0x9246, RENDERER = 0x1F01;
const glWith = (unmasked, basic) => ({
  RENDERER,
  getExtension: (n) => (n === "WEBGL_debug_renderer_info" && unmasked !== null ? { UNMASKED_RENDERER_WEBGL: UNMASKED } : null),
  getParameter: (p) => (p === UNMASKED ? unmasked : p === RENDERER ? basic : null),
});

test("rendererName reads the real (unmasked) renderer when the browser allows it", () => {
  assert.equal(rendererName(glWith("ANGLE (Microsoft, Microsoft Basic Render Driver)", "WebKit WebGL")), "ANGLE (Microsoft, Microsoft Basic Render Driver)");
});

test("rendererName falls back to the basic renderer string when the real one is hidden", () => {
  assert.equal(rendererName(glWith(null, "WebKit WebGL")), "WebKit WebGL");
});

test("rendererName returns an empty string instead of throwing", () => {
  assert.equal(rendererName({ getExtension(){ throw new Error("lost context"); } }), "");
  assert.equal(rendererName(null), "");
});

// Real strings reported by the hardware test on 2026-09-22.
const HP_NO_DRIVER = "ANGLE (Microsoft, Microsoft Basic Render Driver (0x0000008C) Direct3D11 vs_5_0 ps_5_0, D3D11)";
const SURFACE_CHROME = "ANGLE (Intel, Intel(R) Iris(R) Xe Graphics (0x00009A49) Direct3D11 vs_5_0 ps_5_0, D3D11)";
const SURFACE_FIREFOX = "ANGLE (Intel, Intel(R) HD Graphics Direct3D11 vs_5_0 ps_5_0), or similar";

test("Windows' Basic Render Driver counts as software rendering", () => {
  assert.equal(isSoftwareRenderer(HP_NO_DRIVER), true);
});

test("Chrome's SwiftShader counts as software rendering", () => {
  assert.equal(isSoftwareRenderer("ANGLE (Google, Vulkan 1.3.0 (SwiftShader Device (Subzero) (0x0000C0DE)), SwiftShader driver)"), true);
});

test("Mesa's llvmpipe counts as software rendering", () => {
  assert.equal(isSoftwareRenderer("llvmpipe (LLVM 15.0.7, 256 bits)"), true);
});

test("a real Intel GPU is not software rendering", () => {
  assert.equal(isSoftwareRenderer(SURFACE_CHROME), false);
  assert.equal(isSoftwareRenderer(SURFACE_FIREFOX), false);
});

test("a real NVIDIA GPU is not software rendering", () => {
  assert.equal(isSoftwareRenderer("ANGLE (NVIDIA, NVIDIA GeForce 710A Direct3D11 vs_5_0 ps_5_0, D3D11)"), false);
});

test("an unknown or missing name is not treated as software rendering", () => {
  // If the browser hides the name, don't warn: a false alarm is worse than no alarm.
  assert.equal(isSoftwareRenderer(""), false);
  assert.equal(isSoftwareRenderer(null), false);
  assert.equal(isSoftwareRenderer(undefined), false);
});
