/* Playthrough check for every content pack: simulates a player hunting each zone
   until strong enough for its boss, and fails if any zone takes an unreasonable
   number of fights. Mirrors the formulas in src/engine.js (xpNeeded, heroPower).
   Run with:  node test/progression.cjs                                        */
const fs = require("fs");
const path = require("path");

const PACKS = ["sale", "personal"];
/* Win odds by hero/enemy power ratio, measured by Monte Carlo against the battle
   code in engine.js. Hunting is modelled as attack-only (mana refills slowly, so
   quick hunts rarely have any); a lost hunt gives no XP. Bosses are modelled
   with a full mana bar, since the player can wait before challenging one. */
const HUNT_ODDS = [[0.55, 0], [0.6, 0.10], [0.7, 0.70], [0.8, 0.97], [0.9, 1]];
const huntWinChance = r => {
  if(r <= HUNT_ODDS[0][0]) return 0;
  for(let i = 1; i < HUNT_ODDS.length; i++){
    const [r1, p1] = HUNT_ODDS[i], [r0, p0] = HUNT_ODDS[i-1];
    if(r <= r1) return p0 + (p1 - p0) * (r - r0) / (r1 - r0);
  }
  return 1;
};
const BOSS_RATIO = 0.5;     // ~97% win with a full mana bar
const MAX_FIGHTS_PER_ZONE = 100;
const MIN_ARRIVAL_WIN = 0.5; // on arrival, the average hunt must be at least a coin-flip

let failures = 0;
const check = (label, cond) => {
  console.log(`  ${cond ? "PASS" : "FAIL"}  ${label}`);
  if(!cond) failures++;
};

for(const pack of PACKS){
  const C = JSON.parse(fs.readFileSync(path.join(__dirname, "..", "src", `content.${pack}.json`), "utf8"));
  const P = Object.assign({ xpBase: 20, xpGrowth: 1.34, powerBase: 8, powerGrowth: 1.25 }, C.progression || {});
  const xpNeeded = l => Math.floor(P.xpBase * Math.pow(P.xpGrowth, l - 1));
  const tierAt = l => { let t = 0; C.tiers.forEach((x, i) => { if(l >= x.reqLevel) t = i; }); return t; };
  // conservative: no egg-choice bonus, companions only as their tiers unlock
  const power = l => {
    const t = tierAt(l);
    let p = P.powerBase * Math.pow(P.powerGrowth, l - 1) * C.tiers[t].powerMult;
    C.companions.forEach(c => { if(c.unlockTier <= t) p *= c.powerMult; });
    return p;
  };

  let level = 1, xp = 0, total = 0;
  const addXp = a => { xp += a; while(xp >= xpNeeded(level)){ xp -= xpNeeded(level); level++; } };

  console.log(`\n=== ${pack} pack`);
  C.zones.forEach((z, i) => {
    // hunting picks a random creature from the roster, so average the odds
    const avgWin = () => z.enemies.reduce((s, e) => s + huntWinChance(power(level) / e.power), 0) / z.enemies.length;
    const arrival = avgWin();
    let fights = 0;
    while(power(level) < BOSS_RATIO * z.bossPower && fights <= MAX_FIGHTS_PER_ZONE){
      const e = z.enemies[fights % z.enemies.length];
      addXp(e.xpReward * huntWinChance(power(level) / e.power)); // expected XP
      fights++;
    }
    check(`zone ${i} ${z.name}: ${Math.round(arrival*100)}% hunt wins on arrival, boss after ${fights} fights`,
      arrival >= MIN_ARRIVAL_WIN && fights <= MAX_FIGHTS_PER_ZONE);
    total += fights;
    addXp(z.bossXp);
  });
  console.log(`  ${total} fights to finish, ending at level ${level}`);
}

console.log(failures === 0 ? "\nAll progression checks passed." : `\n${failures} progression check(s) FAILED.`);
process.exit(failures === 0 ? 0 : 1);
