/* Wraps a built pack as an installable web app (a PWA).

   Usage:  node scripts/make-pwa.mjs <personal|sale|demo>
   Reads:  dist/<pack>/index.html   (build it first)
   Writes: dist/pwa-<pack>/         index.html, manifest, service worker, icons

   The game itself is untouched: the built file is copied with a manifest link
   and a service worker registration added. Icons are drawn from the pack's own
   hero avatar, so there is no separate art to keep in sync.

   A browser only offers to install a page served over https or from localhost,
   and never inside an iframe. Serve the folder to try it:
     npx http-server dist/pwa-demo -p 8080     (then open http://localhost:8080) */
import { readFileSync, writeFileSync, mkdirSync, rmSync } from "node:fs";
import { createHash } from "node:crypto";
import { fileURLToPath } from "node:url";
import { makeDemoContent } from "../src/demo.js";
import { makeManifest, makeServiceWorker, injectPwaTags, PWA_FILES } from "../src/pwa.js";

const PACKS = ["personal", "sale", "demo"];
const pack = process.argv[2];
if(!PACKS.includes(pack)){
  console.error(`usage: node scripts/make-pwa.mjs <${PACKS.join("|")}>`);
  process.exit(1);
}

const root = fileURLToPath(new URL("../", import.meta.url));
const readPack = name => JSON.parse(readFileSync(`${root}src/content.${name}.json`, "utf8"));
const content = pack === "demo" ? makeDemoContent(readPack("sale")) : readPack(pack);
const { title, heroAvatar, colors } = content.meta;

const src = `${root}dist/${pack}/index.html`;
let html;
try { html = readFileSync(src, "utf8"); }
catch { console.error(`no build at dist/${pack}/index.html - build the pack first`); process.exit(1); }

const out = `${root}dist/pwa-${pack}`;
rmSync(out, { recursive: true, force: true });
mkdirSync(out, { recursive: true });

const BACKGROUND = "#0f1512";            // matches --bg in src/style.css
const theme = colors.hero[0];
const version = createHash("sha256").update(html).digest("hex").slice(0, 12);

writeFileSync(`${out}/index.html`, injectPwaTags(html, { theme }));
writeFileSync(`${out}/${PWA_FILES.manifest}`,
  JSON.stringify(makeManifest({ title, background: BACKGROUND, theme }), null, 2));
writeFileSync(`${out}/${PWA_FILES.sw}`, makeServiceWorker({ version }));

/* Icons: the pack's hero avatar on the game's background. Rendered with the
   Playwright browser the tests already use, so there is no image library to
   install. `scale` leaves room around the shape for a maskable icon, which
   Android crops to whatever shape the launcher uses. */
const { svg } = await import("../src/avatars.js");
const { chromium } = await import("playwright");

/* The hero's outline colour is nearly black, which disappears against the
   dark background at icon sizes, taking the legs and antennae with it. Mix it
   part way to the body colour so the shape still reads at 192px. */
const hex = c => [1, 3, 5].map(i => parseInt(c.slice(i, i + 2), 16));
const mix = (a, b, t) => "#" + hex(a).map((v, i) => Math.round(v + (hex(b)[i] - v) * t)
  .toString(16).padStart(2, "0")).join("");
const outline = mix(colors.hero[1], colors.hero[0], 0.45);

const page = await (await chromium.launch()).newPage();
async function icon(file, size, scale){
  const art = svg(heroAvatar, colors.hero[0], outline);
  await page.setViewportSize({ width: size, height: size });
  await page.setContent(`<style>
      html,body{margin:0;width:${size}px;height:${size}px;background:${BACKGROUND};}
      div{position:absolute;inset:${((1 - scale) / 2 * 100).toFixed(2)}%;}
      svg{width:100%;height:100%;}
    </style><div>${art}</div>`);
  await page.screenshot({ path: `${out}/${file}`, omitBackground: false });
  console.log(`  -> dist/pwa-${pack}/${file}  (${size}x${size})`);
}
await icon(PWA_FILES.icon192, 192, 0.86);
await icon(PWA_FILES.icon512, 512, 0.86);
await icon(PWA_FILES.maskable, 512, 0.62);   // 80% safe zone, with room to spare
await page.context().browser().close();

console.log(`  -> dist/pwa-${pack}/  ${title}  (build ${version})`);
console.log(`     serve it over http://localhost to install; a file:// page cannot.`);
