/* Copies a build to a human-readable filename in dist/, so the file you hand
   someone is named after the game rather than index.html. */
import { copyFileSync, readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { makeDemoContent } from "../src/demo.js";

const pack = process.argv[2];
const root = fileURLToPath(new URL("../", import.meta.url));
const NAMES = {
  personal: "chrysalis-fan-game-personal-use.html",
  sale: "undermoot-rise-of-the-swarm.html",
  demo: "undermoot-demo.html"
};
const readPack = name => JSON.parse(readFileSync(`${root}src/content.${name}.json`, "utf8"));
const title = (pack === "demo" ? makeDemoContent(readPack("sale")) : readPack(pack)).meta.title;
copyFileSync(`${root}dist/${pack}/index.html`, `${root}dist/${NAMES[pack]}`);
console.log(`  -> dist/${NAMES[pack]}  (${title})`);
