/* Copies a build to a human-readable filename in dist/, so the file you hand
   someone is named after the game rather than index.html. */
import { copyFileSync, readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";

const pack = process.argv[2];
const root = fileURLToPath(new URL("../", import.meta.url));
const NAMES = {
  personal: "chrysalis-fan-game-personal-use.html",
  sale: "undermoot-rise-of-the-swarm.html"
};
const title = JSON.parse(readFileSync(`${root}src/content.${pack}.json`, "utf8")).meta.title;
copyFileSync(`${root}dist/${pack}/index.html`, `${root}dist/${NAMES[pack]}`);
console.log(`  -> dist/${NAMES[pack]}  (${title})`);
