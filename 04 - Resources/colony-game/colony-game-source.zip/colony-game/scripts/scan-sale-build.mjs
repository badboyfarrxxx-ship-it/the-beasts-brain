/* Check the sale build for names from the Chrysalis books.

   Takes every capitalised word used in the fan build's content that the sale
   build's content does not use (names of characters, places, creatures), and
   fails if any of them appears in the built sale file. Run after a build:
     node scripts/scan-sale-build.mjs [file]   (default dist/undermoot-rise-of-the-swarm.html) */
import { readFileSync } from "node:fs";

const personal = readFileSync("src/content.personal.json", "utf8");
const sale = readFileSync("src/content.sale.json", "utf8");
const file = process.argv[2] || "dist/undermoot-rise-of-the-swarm.html";
const built = readFileSync(file, "utf8");

// Generic game words that the shared UI uses in both builds. Not book names.
// "Mana" is the label on the magic bar (index.html); checked 2026-09-22.
const GENERIC = new Set(["Mana"]);

const words = (text) => new Set(text.match(/\b[A-Z][a-z]{3,}\b/g) || []);
const saleWords = words(sale);
const bookOnly = [...words(personal)].filter((w) => !saleWords.has(w) && !GENERIC.has(w));

const hits = bookOnly.filter((w) => new RegExp("\\b" + w + "\\b").test(built));
console.log(`checked ${bookOnly.length} names that only the fan build uses`);
if (hits.length) {
  console.log("FOUND in " + file + ": " + hits.join(", "));
  process.exit(1);
}
console.log(file + " is clean: none of them appear");
