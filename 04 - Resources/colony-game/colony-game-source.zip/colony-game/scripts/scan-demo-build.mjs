/* Check the demo build contains none of the paid game.

   Collects every name the sale content has and the demo content doesn't
   (zones 5 to 12, their bosses and creatures, the dropped companions and tiers,
   and the titles of the dropped story beats), then fails if any of them
   appears in the built demo file. Run after a build:
     node scripts/scan-demo-build.mjs [file]   (default dist/undermoot-demo.html) */
import { readFileSync } from "node:fs";
import { makeDemoContent } from "../src/demo.js";

const sale = JSON.parse(readFileSync("src/content.sale.json", "utf8"));
const demo = makeDemoContent(sale);
const file = process.argv[2] || "dist/undermoot-demo.html";
const built = readFileSync(file, "utf8");

const names = (c) => new Set([
  ...c.zones.flatMap((z) => [z.name, z.bossName, ...(z.enemies || []).map((e) => e.name)]),
  ...c.companions.map((x) => x.name),
  ...c.tiers.map((t) => t.name),
  ...(c.events || []).map((e) => e.title)
].filter(Boolean));

const kept = names(demo);
const paidOnly = [...names(sale)].filter((n) => !kept.has(n));
const escape = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
const hits = paidOnly.filter((n) => new RegExp("\\b" + escape(n) + "\\b").test(built));

console.log(`checked ${paidOnly.length} names that only the full game has`);
if (hits.length) {
  console.log("FOUND in " + file + ": " + hits.join(", "));
  process.exit(1);
}
console.log(file + " is clean: none of them appear");
