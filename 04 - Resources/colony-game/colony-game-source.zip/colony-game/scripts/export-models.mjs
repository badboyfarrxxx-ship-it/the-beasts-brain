/* Exports every procedural creature to src/models/<kind>.glb.
 *
 *   npm run models
 *
 * These are starting points, not finished art: open one in Blender, sculpt or
 * replace it, export it back as .glb, then register it in src/models.js. Because
 * they come out of the game's own builders they already have the right scale,
 * facing (+Z forward) and feet-on-floor placement, so a model based on one drops
 * straight in without fiddling with TUNING.
 */
import { mkdirSync, writeFileSync } from "node:fs";
import { fileURLToPath } from "node:url";

/* GLTFExporter is written for the browser and reaches for FileReader. Node 22 has
   Blob but not FileReader, so stand in a minimal one before importing it. */
if(typeof globalThis.FileReader === "undefined"){
  globalThis.FileReader = class {
    readAsArrayBuffer(blob){
      blob.arrayBuffer().then(buf => { this.result = buf; this.onloadend?.(); this.onload?.(); });
    }
    readAsDataURL(blob){
      blob.arrayBuffer().then(buf => {
        const type = blob.type || "application/octet-stream";
        this.result = `data:${type};base64,${Buffer.from(buf).toString("base64")}`;
        this.onloadend?.(); this.onload?.();
      });
    }
  };
}

import * as THREE from "three";
import { GLTFExporter } from "three/addons/exporters/GLTFExporter.js";
import { buildProceduralCreature, CREATURE_KINDS } from "../src/creatures.js";

const outDir = fileURLToPath(new URL("../src/models/", import.meta.url));
mkdirSync(outDir, { recursive: true });

const exporter = new GLTFExporter();

const exportOne = (kind) => new Promise((resolve, reject) => {
  const scene = new THREE.Scene();
  const creature = buildProceduralCreature(kind, ["#8a8a8a", "#3a3a3a"], 1);
  creature.name = kind;
  scene.add(creature);
  exporter.parse(
    scene,
    (result) => {
      const buf = Buffer.from(result);
      writeFileSync(outDir + kind + ".glb", buf);
      console.log(`  ${kind}.glb  ${(buf.length/1024).toFixed(1)} KB`);
      resolve();
    },
    (err) => reject(err),
    { binary: true }
  );
});

console.log("Exporting procedural creatures to src/models/");
for(const kind of CREATURE_KINDS){
  await exportOne(kind);
}
console.log(`\nDone — ${CREATURE_KINDS.length} files. Register any you replace in src/models.js.`);
