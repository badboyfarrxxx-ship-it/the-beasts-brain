/* Is the browser drawing 3D without a real graphics chip?

   When a computer has no working graphics driver, browsers fall back to a
   software renderer that runs on the processor: Windows' "Microsoft Basic
   Render Driver", Chrome's SwiftShader, or Mesa's llvmpipe on Linux. The 3D
   world is unplayable there at any quality, so the game says so instead of
   just running badly. Kept free of three.js so it can be unit tested. */

const SOFTWARE_RENDERERS = /basic render driver|swiftshader|llvmpipe/i;

export function isSoftwareRenderer(name){
  return typeof name === "string" && SOFTWARE_RENDERERS.test(name);
}

/* The renderer name the browser reports for a WebGL context, or "" if it
   won't say. Prefers the real name; some browsers hide it for privacy. */
export function rendererName(gl){
  try{
    const ext = gl.getExtension("WEBGL_debug_renderer_info");
    return String(gl.getParameter(ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER) || "");
  }catch(e){
    return "";
  }
}
