/* The free demo: the sale content cut down at build time.

   The demo ends after zone 4 (index 3), straight after "The Choosing of the
   Brood". Everything past that point is removed here, before bundling, so the
   paid part of the game is not inside the demo file at all. Pure function, no
   browser or build-tool dependencies, so it can be unit tested in Node. */

export const DEMO_LAST_ZONE = 3;   // Bramble Sinks
export const DEMO_LAST_TIER = 3;   // Twinmind Ant

const END_SCREEN = {
  title: "The Undermoot goes deeper",
  text: "You've reached the end of the demo. Your colony has made its choice, and there are eight more zones below: new creatures, new companions, and whatever is waiting at the root of the world.",
  codeLabel: "Your save code, to carry on in the full game:",
  codeHelp: "In the full game, paste it into the Save box and click Import. You'll pick up exactly where you stopped.",
  buyLabel: "Get the full game",
  keepPlayingLabel: "Keep playing the demo",
  copyLabel: "Copy",
  copiedLabel: "Copied"
};

function keepEvent(ev){
  const w = ev.when || {};
  if(w.zone !== undefined && w.zone > DEMO_LAST_ZONE) return false;
  if(w.tier !== undefined && w.tier > DEMO_LAST_TIER) return false;
  return true;
}

export function makeDemoContent(sale){
  const c = structuredClone(sale);
  c.zones = c.zones.slice(0, DEMO_LAST_ZONE + 1);
  c.companions = c.companions.filter(x => x.unlockTier <= DEMO_LAST_TIER);
  c.tiers = c.tiers.slice(0, DEMO_LAST_TIER + 1);
  c.events = (c.events || []).filter(keepEvent);
  c.meta.title = sale.meta.title + " (Demo)";
  c.meta.saveSlug = "undermoot_demo";
  c.meta.demo = { storeUrl: "", end: { ...END_SCREEN } };
  return c;
}
