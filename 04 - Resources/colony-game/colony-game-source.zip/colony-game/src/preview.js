/* Dev-only page: lines up every creature shape so you can see them all at once.
   Useful when tweaking the procedural models, or when matching a .glb you're
   building in Blender to the scale and facing the game expects (+Z forward,
   feet at y=0, ~1 unit tall). */
import * as THREE from "three";
import { buildProceduralCreature, animateCreature, CREATURE_KINDS } from "./creatures.js";

const canvas = document.getElementById("c");
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;

const scene = new THREE.Scene();
scene.background = new THREE.Color("#121814");

const camera = new THREE.PerspectiveCamera(45, 1, 0.1, 200);

scene.add(new THREE.HemisphereLight(0xffffff, 0x445533, 1.0));
scene.add(new THREE.AmbientLight(0xffffff, 0.35));
const sun = new THREE.DirectionalLight(0xfff2e0, 1.3);
sun.position.set(6, 12, 8);
sun.castShadow = true;
sun.shadow.mapSize.set(2048, 2048);
sun.shadow.camera.left = -14; sun.shadow.camera.right = 14;
sun.shadow.camera.top = 10; sun.shadow.camera.bottom = -10;
scene.add(sun);

const ground = new THREE.Mesh(
  new THREE.PlaneGeometry(60, 30),
  new THREE.MeshStandardMaterial({ color: "#2e3a33", roughness: 1 })
);
ground.rotation.x = -Math.PI/2;
ground.receiveShadow = true;
scene.add(ground);

const spacing = 2.6;
const creatures = CREATURE_KINDS.map((kind, i) => {
  const g = buildProceduralCreature(kind, ["#7fd858", "#1d3a16"], 1);
  g.position.x = (i - (CREATURE_KINDS.length - 1)/2) * spacing;
  scene.add(g);

  // label each one with a small ring so you can count positions
  const ring = new THREE.Mesh(
    new THREE.RingGeometry(0.5, 0.58, 24),
    new THREE.MeshBasicMaterial({ color: "#e0b84b", side: THREE.DoubleSide, transparent: true, opacity: 0.4 })
  );
  ring.rotation.x = -Math.PI/2;
  ring.position.set(g.position.x, 0.02, 0);
  scene.add(ring);

  return g;
});

console.log("creature order, left to right:", CREATURE_KINDS.join(", "));

function resize(){
  const w = canvas.clientWidth, h = canvas.clientHeight;
  renderer.setSize(w, h, false);
  camera.aspect = w/h;
  camera.updateProjectionMatrix();
}
window.addEventListener("resize", resize);

const clock = new THREE.Clock();
let t = 0;
function loop(){
  requestAnimationFrame(loop);
  t += clock.getDelta();
  creatures.forEach((g, i) => {
    g.rotation.y = t*0.6 + i*0.2;
    animateCreature(g, t, 1);   // walk cycle running, so legs are visibly articulated
  });
  camera.position.set(0, 2.6, 8.5);
  camera.lookAt(0, 0.6, 0);
  renderer.render(scene, camera);
}
resize();
loop();

// handy in the console while modelling
window.CREATURES = { build: buildProceduralCreature, kinds: CREATURE_KINDS };
