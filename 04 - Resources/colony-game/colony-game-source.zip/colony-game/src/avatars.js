/* Original, generic creature-icon generator. Every shape here is built from basic
   primitives (ellipses, polygons, lines) parameterized by color — no specific
   copyrighted character design is referenced or reproduced. */

function wrap(inner, cls){
  return `<svg class="avatar-svg ${cls||''}" viewBox="0 0 96 96" xmlns="http://www.w3.org/2000/svg">${inner}</svg>`;
}

const SHAPES = {
  ant(p, s){
    return `
      <line x1="48" y1="30" x2="30" y2="12" stroke="${s}" stroke-width="2.5" stroke-linecap="round"/>
      <line x1="48" y1="30" x2="66" y2="12" stroke="${s}" stroke-width="2.5" stroke-linecap="round"/>
      <ellipse cx="48" cy="32" rx="12" ry="11" fill="${p}"/>
      <ellipse cx="48" cy="52" rx="15" ry="13" fill="${p}"/>
      <ellipse cx="48" cy="76" rx="18" ry="16" fill="${p}"/>
      ${[ -14,-2,10 ].map(dy=>`
        <line x1="34" y1="${50+dy}" x2="14" y2="${58+dy}" stroke="${s}" stroke-width="3" stroke-linecap="round"/>
        <line x1="62" y1="${50+dy}" x2="82" y2="${58+dy}" stroke="${s}" stroke-width="3" stroke-linecap="round"/>
      `).join("")}
      <circle cx="43" cy="30" r="2.2" fill="${s}"/><circle cx="53" cy="30" r="2.2" fill="${s}"/>
    `;
  },
  beast(p, s){
    return `
      <ellipse cx="48" cy="60" rx="26" ry="18" fill="${p}"/>
      <ellipse cx="26" cy="72" rx="6" ry="10" fill="${p}"/>
      <ellipse cx="70" cy="72" rx="6" ry="10" fill="${p}"/>
      <ellipse cx="34" cy="80" rx="6" ry="9" fill="${p}"/>
      <ellipse cx="62" cy="80" rx="6" ry="9" fill="${p}"/>
      <circle cx="26" cy="38" r="14" fill="${p}"/>
      <polygon points="16,26 22,10 26,28" fill="${p}"/>
      <polygon points="36,26 30,10 26,28" fill="${p}"/>
      <circle cx="22" cy="36" r="2.3" fill="${s}"/><circle cx="31" cy="36" r="2.3" fill="${s}"/>
      <path d="M74 58 Q88 50 84 36" stroke="${p}" stroke-width="7" fill="none" stroke-linecap="round"/>
    `;
  },
  tendril(p, s){
    const arms = [];
    for(let i=0;i<7;i++){
      const ang = (i/7)*Math.PI*2;
      const x2 = 48 + Math.cos(ang)*38, y2 = 54 + Math.sin(ang)*38;
      const mx = 48 + Math.cos(ang)*22, my = 54 + Math.sin(ang)*22 + 6;
      arms.push(`<path d="M48 54 Q${mx} ${my} ${x2} ${y2}" stroke="${p}" stroke-width="5" fill="none" stroke-linecap="round"/>`);
    }
    return `${arms.join("")}<circle cx="48" cy="54" r="20" fill="${p}"/><circle cx="48" cy="54" r="9" fill="${s}"/>`;
  },
  crawler(p, s){
    return `
      <ellipse cx="48" cy="58" rx="22" ry="14" fill="${p}"/>
      <circle cx="48" cy="34" r="11" fill="${p}"/>
      ${[0,1,2,3].map(i=>`<line x1="${30+i*10}" y1="66" x2="${26+i*10}" y2="82" stroke="${s}" stroke-width="3" stroke-linecap="round"/>`).join("")}
      <line x1="40" y1="26" x2="30" y2="14" stroke="${s}" stroke-width="2" stroke-linecap="round"/>
      <line x1="56" y1="26" x2="66" y2="14" stroke="${s}" stroke-width="2" stroke-linecap="round"/>
      <circle cx="44" cy="34" r="2" fill="${s}"/><circle cx="52" cy="34" r="2" fill="${s}"/>
    `;
  },
  vine(p, s){
    const leaves = [];
    for(let i=0;i<6;i++){
      const ang = (i/6)*Math.PI*2;
      const x = 48 + Math.cos(ang)*30, y = 54 + Math.sin(ang)*30;
      leaves.push(`<polygon points="48,54 ${x-6},${y} ${x+6},${y} ${x},${y-6}" fill="${p}"/>`);
    }
    return `${leaves.join("")}<circle cx="48" cy="54" r="14" fill="${s}"/><circle cx="48" cy="54" r="6" fill="${p}"/>`;
  },
  croc(p, s){
    return `
      <polygon points="10,58 50,44 92,50 92,66 50,72 10,64" fill="${p}"/>
      <polygon points="10,58 -2,52 10,64" fill="${p}"/>
      ${[0,1,2,3,4].map(i=>`<polygon points="${18+i*14},50 ${24+i*14},58 ${30+i*14},50" fill="${s}"/>`).join("")}
      <circle cx="60" cy="50" r="2.4" fill="${s}"/>
      <line x1="35" y1="70" x2="30" y2="82" stroke="${p}" stroke-width="6" stroke-linecap="round"/>
      <line x1="65" y1="70" x2="70" y2="82" stroke="${p}" stroke-width="6" stroke-linecap="round"/>
    `;
  },
  marauder(p, s){
    return `
      <polygon points="48,14 74,86 22,86" fill="${p}"/>
      <circle cx="40" cy="46" r="3" fill="${s}"/><circle cx="56" cy="46" r="3" fill="${s}"/>
      <line x1="78" y1="20" x2="86" y2="82" stroke="${s}" stroke-width="3" stroke-linecap="round"/>
      <polygon points="82,16 90,16 86,26" fill="${s}"/>
    `;
  },
  golem(p, s){
    return `
      <polygon points="26,86 22,50 34,30 62,30 74,50 70,86" fill="${p}"/>
      <polygon points="34,30 40,14 56,14 62,30" fill="${p}"/>
      <path d="M34 50 L44 44 L38 62 L52 56" stroke="${s}" stroke-width="3" fill="none" stroke-linecap="round"/>
      <circle cx="42" cy="42" r="2.6" fill="${s}"/><circle cx="54" cy="42" r="2.6" fill="${s}"/>
    `;
  },
  demon(p, s){
    return `
      <polygon points="20,30 8,10 30,20" fill="${p}"/>
      <polygon points="76,30 88,10 66,20" fill="${p}"/>
      <polygon points="48,18 68,50 58,86 38,86 28,50" fill="${p}"/>
      <polygon points="18,44 2,60 22,66" fill="${p}"/>
      <polygon points="78,44 94,60 74,66" fill="${p}"/>
      <circle cx="41" cy="48" r="3" fill="${s}"/><circle cx="55" cy="48" r="3" fill="${s}"/>
      <path d="M48 86 Q58 96 68 92" stroke="${p}" stroke-width="5" fill="none" stroke-linecap="round"/>
    `;
  }
};

export function svg(kind, primary, secondary, cls){
  const fn = SHAPES[kind] || SHAPES.ant;
  return wrap(fn(primary, secondary), cls);
}
