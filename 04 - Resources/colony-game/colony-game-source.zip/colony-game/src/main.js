/* Entry point. Vite bundles this (and three.js, pulled from node_modules as an
   ES module) into a single self-contained HTML file. Which content pack gets
   built is decided by the "@content" alias in vite.config.js. */
import "./style.css";
import { WORLD3D } from "./world3d.js";
import CONTENT from "@content";
import "./engine.js";

// handy for debugging in the console, and used by the automated tests
window.WORLD3D = WORLD3D;
window.GAME_CONTENT = CONTENT;
