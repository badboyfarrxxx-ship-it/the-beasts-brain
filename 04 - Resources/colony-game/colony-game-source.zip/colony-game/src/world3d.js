/* The walk-around 3D layer.
 *
 * Creature shapes live in creatures.js (procedural, built from three.js primitives).
 * If a .glb is registered for a kind in models.js it is used instead, and the
 * procedural version becomes the fallback. Nothing else in the game cares which
 * one is in use. */
import * as THREE from "three";
import { GLTFLoader } from "three/addons/loaders/GLTFLoader.js";
import { buildProceduralCreature, animateCreature, setMaterialQuality } from "./creatures.js";
import { MODELS, TUNING } from "./models.js";
import { mountTouchControls, looksLikeTouchDevice } from "./touch.js";
import { RoomEnvironment } from "three/addons/environments/RoomEnvironment.js";
import { groundTextures, rockTextures, terrainHeight } from "./textures.js";
import { isSoftwareRenderer, rendererName } from "./gpu.js";

let renderer, scene, camera, ground;
let playerGroup;
let enemyMeshes = [], bossMesh = null, companionMeshes = [], sceneryMeshes = [];
let keys = {};
let paused = true;
let mounted = false;
let rafId = null;
let lastTouchedEnemy = null;
let cooldownUntil = 0;
let api = null;
let clock;
let elapsed = 0;
let walking = 0;
let touch = null;                       // thumbstick controller
let touchAxes = { move: 0, turn: 0 };   // -1..1, fed by the thumbstick

/* Adaptive quality: the heavy lifting here is per-pixel (PBR + image-based
   lighting + shadows), which weak GPUs choke on. Sample the frame rate after
   mounting and step the expensive features down until it runs smoothly. Steps
   only ever go down, so it can't oscillate. */
let quality = 0;
let envTexture = null;
let sunLight = null;
let renderScale = 1;
let softwareRendering = false;   // no real graphics chip in use (see gpu.js)

/* Shown once when the browser is drawing on the processor: the 3D world will
   be slow at any quality, and the fix (a graphics driver) is outside the game. */
function showSoftwareNotice(){
  const el = document.getElementById("worldGpuNotice");
  if(!el) return;
  el.hidden = false;
  const close = document.getElementById("worldGpuNoticeClose");
  if(close) close.addEventListener("click", () => { el.hidden = true; }, { once: true });
}

function setQuality(level){
  if(level === quality || !renderer) return;
  quality = level;
  if(level === 0){
    renderScale = 1;
    renderer.shadowMap.enabled = true;
    if(sunLight) sunLight.castShadow = true;
    scene.environment = envTexture;
  } else if(level === 1){
    renderScale = 0.8;
    renderer.shadowMap.enabled = true;
    if(sunLight) sunLight.castShadow = true;
    scene.environment = envTexture;
  } else if(level === 2){
    renderScale = 0.65;
    renderer.shadowMap.enabled = false;
    if(sunLight) sunLight.castShadow = false;
    scene.environment = envTexture;
  } else {
    renderScale = 0.5;
    renderer.shadowMap.enabled = false;
    if(sunLight) sunLight.castShadow = false;
    scene.environment = null;   // last resort: lights only
  }
  // the heaviest per-pixel work is clearcoat and the normal/roughness maps
  setMaterialQuality(level >= 2);
  if(ground && ground.material){
    const low = level >= 2;
    ground.material.normalMap = low ? null : (ground.userData.normalMap || ground.material.normalMap);
    ground.material.roughnessMap = low ? null : (ground.userData.roughnessMap || ground.material.roughnessMap);
    ground.material.needsUpdate = true;
  }
  scene.traverse(o => { if(o.isMesh && o.material) o.material.needsUpdate = true; });
  resize();
}

function watchPerformance(){
  let frames = 0, t0 = 0, strikes = 0;
  const startSample = () => { frames = 0; t0 = performance.now(); requestAnimationFrame(sample); };
  const sample = () => {
    frames++;
    const dtms = performance.now() - t0;
    if(dtms >= 1000){
      const fps = frames/(dtms/1000);
      if(fps < 22){
        // two slow samples in a row before stepping down, so a one-off hitch
        // (shader compile, texture upload) doesn't cost you shadows
        strikes++;
        if(strikes >= 2 && quality < 3){
          setQuality(quality + 1);
          strikes = 0;
        }
        if(quality < 3) return setTimeout(startSample, 250);
      }
      return;   // fast enough, or already at the lowest setting
    }
    requestAnimationFrame(sample);
  };
  // let the scene warm up first: first-frame costs aren't representative
  setTimeout(startSample, 800);
}

/* ---------- optional glb models ---------- */

const loadedModels = {};   // kind -> THREE.Object3D template

function loadRegisteredModels(){
  const entries = Object.entries(MODELS).filter(([, url]) => !!url);
  if(entries.length === 0) return Promise.resolve(false);
  const loader = new GLTFLoader();
  return Promise.all(entries.map(([kind, url]) =>
    loader.loadAsync(url)
      .then(gltf => { loadedModels[kind] = gltf.scene; })
      .catch(err => { console.warn(`model for "${kind}" failed to load, using the built-in shape`, err); })
  )).then(() => Object.keys(loadedModels).length > 0);
}

function buildCreature(kind, colors, scale){
  const template = loadedModels[kind];
  if(template){
    const g = template.clone(true);
    const tune = TUNING[kind] || {};
    g.scale.setScalar((tune.scale ?? 1) * scale);
    g.rotation.y = tune.rotationY ?? 0;
    g.position.y = tune.offsetY ?? 0;
    g.traverse(o => { if(o.isMesh) o.castShadow = true; });
    g.userData.anim = null;   // loaded models bring their own animations, if any
    return g;
  }
  return buildProceduralCreature(kind, colors, scale);
}

/* ---------- scene building ---------- */

function markerRing(color, radius){
  const ring = new THREE.Mesh(
    new THREE.RingGeometry(radius*0.82, radius, 28),
    new THREE.MeshBasicMaterial({ color, side: THREE.DoubleSide, transparent: true, opacity: 0.5 })
  );
  ring.rotation.x = -Math.PI/2;
  ring.position.y = 0.03;
  return ring;
}

function clearGroup(list){
  list.forEach(m => scene.remove(m));
  return [];
}

function rand(min, max){ return min + Math.random()*(max - min); }

let heightAt = () => 0;   // terrain height lookup for the current zone

function applyTerrain(hue){
  heightAt = terrainHeight(hue);
  const pos = ground.geometry.attributes.position;
  for(let i = 0; i < pos.count; i++){
    // plane is built in XY then rotated, so its local y maps to world z
    const x = pos.getX(i), y = pos.getY(i);
    pos.setZ(i, heightAt(x, -y));
  }
  pos.needsUpdate = true;
  ground.geometry.computeVertexNormals();

  const { map, roughnessMap, normalMap } = groundTextures(hue);
  ground.material.map = map;
  ground.material.roughnessMap = roughnessMap;
  ground.material.normalMap = normalMap;
  ground.material.normalScale.set(0.35, 0.35);
  ground.userData.normalMap = normalMap;
  ground.userData.roughnessMap = roughnessMap;
  ground.material.needsUpdate = true;
}

function placeOnGround(obj){
  obj.position.y = heightAt(obj.position.x, obj.position.z);
}

function rebuildZone(){
  const zone = api.getZone();
  enemyMeshes = clearGroup(enemyMeshes);
  sceneryMeshes = clearGroup(sceneryMeshes);
  if(bossMesh){ scene.remove(bossMesh); bossMesh = null; }

  const hue = (api.getZoneIndex()*53 + 15) % 360;
  const bg = new THREE.Color(`hsl(${hue}, 24%, 9%)`);
  scene.background = bg;
  scene.fog = new THREE.FogExp2(bg, 0.026);

  applyTerrain(hue);

  // rocks and spires, textured and scattered
  const rockTex = rockTextures(hue);
  const rockMat = new THREE.MeshStandardMaterial({
    map: rockTex.map, normalMap: rockTex.normalMap,
    normalScale: new THREE.Vector2(0.7, 0.7),
    roughness: 0.95, metalness: 0.02
  });
  // a few prototype shapes, reused and re-scaled: keeps the draw calls cheap
  const protos = [];
  for(let i = 0; i < 3; i++){
    const spire = new THREE.ConeGeometry(0.55, 2.6, 7, 2);
    const boulder = new THREE.DodecahedronGeometry(0.6, 0);
    [spire, boulder].forEach(geo => {
      const pos = geo.attributes.position;
      for(let v = 0; v < pos.count; v++){
        pos.setXYZ(v, pos.getX(v)*rand(0.8, 1.2), pos.getY(v)*rand(0.85, 1.15), pos.getZ(v)*rand(0.8, 1.2));
      }
      geo.computeVertexNormals();
      protos.push({ geo, tall: geo.parameters.height !== undefined });
    });
  }
  for(let i = 0; i < 24; i++){
    const ang = rand(0, Math.PI*2), radius = rand(5, 23);
    const proto = protos[Math.floor(Math.random()*protos.length)];
    const m = new THREE.Mesh(proto.geo, rockMat);
    const size = rand(0.55, 1.35);
    m.scale.set(size*rand(0.85,1.15), size*rand(0.8,1.3), size*rand(0.85,1.15));
    m.position.set(Math.cos(ang)*radius, 0, Math.sin(ang)*radius);
    placeOnGround(m);
    if(proto.tall) m.position.y += 2.6*m.scale.y/2 - 0.25;
    m.rotation.set(rand(-0.12, 0.12), rand(0, Math.PI*2), rand(-0.12, 0.12));
    m.castShadow = true;
    m.receiveShadow = true;
    scene.add(m);
    sceneryMeshes.push(m);
  }

  // a zone can list several enemy types; spawn a mix of them
  const roster = zone.enemies && zone.enemies.length
    ? zone.enemies
    : [{ avatar: zone.enemyAvatar }];
  for(let i = 0; i < 6; i++){
    const pick = roster[i % roster.length];
    const m = buildCreature(pick.avatar, api.content.meta.colors.enemy, pick.scale || 1);
    const ang = rand(0, Math.PI*2), radius = rand(5, 16);
    m.position.set(Math.cos(ang)*radius, 0, Math.sin(ang)*radius);
    placeOnGround(m);
    m.rotation.y = rand(0, Math.PI*2);
    m.userData.type = "enemy";
    m.userData.enemyIndex = i % roster.length;
    m.add(markerRing(api.content.meta.colors.enemy[0], 1.1));
    scene.add(m);
    enemyMeshes.push(m);
  }

  bossMesh = buildCreature(zone.bossAvatar, api.content.meta.colors.boss, 2.4);
  bossMesh.position.set(0, 0, 17);
  placeOnGround(bossMesh);
  bossMesh.rotation.y = Math.PI;
  bossMesh.userData.type = "boss";
  bossMesh.add(markerRing(api.content.meta.colors.boss[0], 1.4));
  scene.add(bossMesh);

  playerGroup.position.set(0, 0, 0);
  placeOnGround(playerGroup);
  playerGroup.rotation.y = 0;
}

function refreshCompanions(){
  companionMeshes = clearGroup(companionMeshes);
  api.getCompanions().forEach((name, i) => {
    const def = api.content.companions.find(c => c.name === name);
    if(!def) return;
    const m = buildCreature(def.avatar, api.content.meta.colors.companion, 0.8);
    // fan them out behind you rather than stacking them on your back
    const n = api.getCompanions().length;
    m.userData.offsetAngle = Math.PI + (i - (n - 1)/2) * 0.62;
    m.userData.offsetDist = 2.2 + (i % 2) * 0.7;
    m.userData.lastPos = new THREE.Vector3();
    scene.add(m);
    companionMeshes.push(m);
  });
}

function rebuildPlayer(){
  const scale = playerGroup ? playerGroup.scale.x : 1;
  const rot = playerGroup ? playerGroup.rotation.y : 0;
  const pos = playerGroup ? playerGroup.position.clone() : new THREE.Vector3();
  if(playerGroup) scene.remove(playerGroup);
  playerGroup = buildCreature(api.content.meta.heroAvatar, api.content.meta.colors.hero, 1);
  playerGroup.scale.setScalar(scale);
  playerGroup.rotation.y = rot;
  playerGroup.position.copy(pos);
  scene.add(playerGroup);
}

function applyTierScale(){
  playerGroup.scale.setScalar(1 + api.getTier()*0.12);
}

/* ---------- input & loop ---------- */

function onKeyDown(e){ keys[e.key.toLowerCase()] = true; }
function onKeyUp(e){ keys[e.key.toLowerCase()] = false; }

let viewBoost = 1;   // pulls the camera back on tall/narrow screens

function resize(){
  const canvas = renderer.domElement;
  const w = canvas.clientWidth || 300, h = canvas.clientHeight || 300;
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5) * renderScale);
  renderer.setSize(w, h, false);
  camera.aspect = w/h;
  // a portrait phone sees far less ahead at the same fov, so widen and back off
  const portrait = camera.aspect < 1;
  camera.fov = portrait ? 74 : 60;
  viewBoost = portrait ? 1.45 : 1;
  camera.updateProjectionMatrix();
}

function animate(){
  rafId = requestAnimationFrame(animate);
  const dt = Math.min(0.12, clock.getDelta());   // generous cap so slow devices still move at a sane speed
  elapsed += dt;

  if(!paused){
    const turnSpeed = 2.0, moveSpeed = 4.2;

    // keyboard and thumbstick feed the same two axes; whichever is active wins
    let turnAxis = 0;
    if(keys["arrowleft"] || keys["a"]) turnAxis += 1;
    if(keys["arrowright"] || keys["d"]) turnAxis -= 1;
    if(turnAxis === 0) turnAxis = touchAxes.turn;

    let moveZ = 0;
    if(keys["arrowup"] || keys["w"]) moveZ = 1;
    if(keys["arrowdown"] || keys["s"]) moveZ = -1;
    if(moveZ === 0) moveZ = touchAxes.move;

    if(turnAxis !== 0) playerGroup.rotation.y += turnSpeed*turnAxis*dt;

    walking += (Math.min(1, Math.abs(moveZ)) - walking) * Math.min(1, dt*8);

    if(moveZ !== 0){
      const dir = new THREE.Vector3(Math.sin(playerGroup.rotation.y), 0, Math.cos(playerGroup.rotation.y));
      playerGroup.position.addScaledVector(dir, moveZ*moveSpeed*dt);
      playerGroup.position.x = Math.max(-20, Math.min(20, playerGroup.position.x));
      playerGroup.position.z = Math.max(-20, Math.min(20, playerGroup.position.z));
    }
    const bob = (playerGroup.userData.anim ? playerGroup.userData.anim.bob : 0.06);
    playerGroup.position.y = heightAt(playerGroup.position.x, playerGroup.position.z)
      + Math.abs(Math.sin(elapsed*11)) * bob * walking;

    companionMeshes.forEach(m => {
      const ang = playerGroup.rotation.y + m.userData.offsetAngle;
      const target = new THREE.Vector3(
        playerGroup.position.x - Math.sin(ang)*m.userData.offsetDist,
        0,
        playerGroup.position.z - Math.cos(ang)*m.userData.offsetDist
      );
      const before = m.position.clone();
      target.y = heightAt(target.x, target.z);
      m.position.lerp(target, 0.07);
      m.rotation.y = playerGroup.rotation.y;
      const moved = before.distanceTo(m.position);
      animateCreature(m, elapsed, Math.min(1, moved*30));
    });

    const now = performance.now();
    if(now > cooldownUntil){
      for(const m of enemyMeshes){
        const dx = m.position.x - playerGroup.position.x, dz = m.position.z - playerGroup.position.z;
        if(Math.hypot(dx, dz) < 1.15){
          lastTouchedEnemy = m;
          cooldownUntil = now + 600;
          api.onEnemyTouch(m.userData.enemyIndex ?? 0);
          break;
        }
      }
      if(bossMesh){
        const dx = bossMesh.position.x - playerGroup.position.x, dz = bossMesh.position.z - playerGroup.position.z;
        if(Math.hypot(dx, dz) < 2.8){
          cooldownUntil = now + 600;
          api.onBossTouch();
        }
      }
    }
  }

  animateCreature(playerGroup, elapsed, walking);
  enemyMeshes.forEach(m => animateCreature(m, elapsed, 0));
  if(bossMesh) animateCreature(bossMesh, elapsed, 0);

  const scale = playerGroup.scale.x;
  const camDist = 6.5*scale*viewBoost, camHeight = 4.2*scale*viewBoost;
  const camOffset = new THREE.Vector3(
    -Math.sin(playerGroup.rotation.y)*camDist,
    camHeight,
    -Math.cos(playerGroup.rotation.y)*camDist
  );
  camera.position.lerp(playerGroup.position.clone().add(camOffset), 0.18);
  const aheadDir = new THREE.Vector3(Math.sin(playerGroup.rotation.y), 0, Math.cos(playerGroup.rotation.y));
  const lookTarget = playerGroup.position.clone().addScaledVector(aheadDir, 2.4);
  camera.lookAt(lookTarget.x, 1.0*scale, lookTarget.z);

  renderer.render(scene, camera);
}

function mount(canvas, apiIn){
  api = apiIn;
  renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  // filmic response + sRGB output, so lighting rolls off instead of clipping flat
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.05;
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));
  scene = new THREE.Scene();
  camera = new THREE.PerspectiveCamera(60, 1, 0.1, 200);
  clock = new THREE.Clock();

  // image-based lighting: a procedurally built room, prefiltered into an env map.
  // gives materials something to reflect, which is most of what sells "not plastic".
  const pmrem = new THREE.PMREMGenerator(renderer);
  envTexture = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
  scene.environment = envTexture;
  scene.environmentIntensity = 0.35;
  pmrem.dispose();

  scene.add(new THREE.HemisphereLight(0xcfe3ff, 0x40361f, 0.55));
  const sun = sunLight = new THREE.DirectionalLight(0xfff2e0, 2.1);
  sun.position.set(7, 14, 6);
  sun.castShadow = true;
  sun.shadow.mapSize.set(1024, 1024);
  sun.shadow.camera.updateProjectionMatrix();
  sun.shadow.camera.near = 1;
  sun.shadow.camera.far = 60;
  sun.shadow.camera.left = -26;
  sun.shadow.camera.right = 26;
  sun.shadow.camera.top = 26;
  sun.shadow.camera.bottom = -26;
  sun.shadow.bias = -0.0008;
  scene.add(sun);
  const rim = new THREE.DirectionalLight(0x88bbff, 0.35);
  rim.position.set(-6, 5, -8);
  scene.add(rim);

  ground = new THREE.Mesh(
    new THREE.PlaneGeometry(52, 52, 72, 72),
    new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 1.0 })
  );
  ground.rotation.x = -Math.PI/2;
  ground.receiveShadow = true;
  scene.add(ground);

  playerGroup = buildCreature(api.content.meta.heroAvatar, api.content.meta.colors.hero, 1);
  scene.add(playerGroup);

  window.addEventListener("keydown", onKeyDown);
  window.addEventListener("keyup", onKeyUp);
  window.addEventListener("resize", resize);

  touch = mountTouchControls(canvas.parentElement, canvas, (move, turn) => {
    touchAxes.move = move;
    touchAxes.turn = turn;
  });
  if(looksLikeTouchDevice()) touch.show();

  rebuildZone();
  refreshCompanions();
  applyTierScale();
  resize();
  // Software rendering: start at the lightest setting instead of stepping down
  // to it one slow sample at a time, and tell the player why it's slow.
  softwareRendering = isSoftwareRenderer(rendererName(renderer.getContext()));
  if(softwareRendering){
    setQuality(3);
    showSoftwareNotice();
  }
  mounted = true;
  animate();
  watchPerformance();

  // if any .glb models are registered, swap them in once they finish loading
  loadRegisteredModels().then(gotAny => {
    if(gotAny && mounted){
      rebuildPlayer();
      applyTierScale();
      rebuildZone();
      refreshCompanions();
    }
  });
}

export const WORLD3D = {
  get mounted(){ return mounted; },
  mount(canvas, apiIn){ if(!mounted) mount(canvas, apiIn); else resize(); },
  rebuildZone(){ if(mounted) rebuildZone(); },
  refreshCompanions(){ if(mounted) refreshCompanions(); },
  applyTierScale(){ if(mounted) applyTierScale(); },
  setPaused(v){
    paused = v;
    // drop any held input so a battle opening mid-drag doesn't keep you walking
    if(v){
      keys = {};
      touchAxes.move = 0;
      touchAxes.turn = 0;
      if(touch) touch.reset();
    }
  },
  resize(){ if(mounted) resize(); },

  /* on-screen thumbstick; defaults on for touch devices, toggled from the HUD */
  setTouchControls(on){
    if(!touch) return;
    if(on) touch.show(); else touch.hide();
  },
  touchDefaultsOn(){ return looksLikeTouchDevice(); },

  /* used by the automated tests, and handy from the console */
  debug(){
    if(!mounted) return null;
    return {
      player: { x: playerGroup.position.x, z: playerGroup.position.z, rot: playerGroup.rotation.y },
      enemies: enemyMeshes.map(m => ({ x: m.position.x, z: m.position.z })),
      boss: bossMesh ? { x: bossMesh.position.x, z: bossMesh.position.z } : null,
      companions: companionMeshes.length,
      usingModels: Object.keys(loadedModels),
      quality,
      softwareRendering,
      paused
    };
  },
  teleport(x, z){ if(mounted){ playerGroup.position.set(x, 0, z); placeOnGround(playerGroup); } },

  /* pin the quality level (0 = everything on, 3 = lightest). Normally the
     watchdog picks this; useful for screenshots and for testing. */
  setQuality(level){ if(mounted) setQuality(level); },

  onBattleResolved(){
    if(!mounted) return;
    paused = false;
    cooldownUntil = performance.now() + 700;
    if(lastTouchedEnemy){
      const ang = rand(0, Math.PI*2), radius = rand(5, 16);
      lastTouchedEnemy.position.set(Math.cos(ang)*radius, 0, Math.sin(ang)*radius);
      placeOnGround(lastTouchedEnemy);
      lastTouchedEnemy = null;
    }
  }
};
