/* Generic colony-evolution role-playing engine.
   All flavor text, names, colors and numbers come from the imported content pack.
   This file stays free of any world-specific names so it can drive either content pack. */
import C from "@content";
import * as AVATARS from "./avatars.js";
import { WORLD3D } from "./world3d.js";

const SAVE_KEY = "colonygame_save_" + C.meta.saveSlug;
const TOUCH_KEY = "colonygame_touch_" + C.meta.saveSlug;
let touchControlsOn = false;

function clamp(v,a,b){ return Math.max(a, Math.min(b, v)); }

function fmt(n){
  if(n < 1000) return Math.floor(n).toString();
  const units = ["K","M","B","T","Qa","Qi"];
  let u = -1;
  while(n >= 1000 && u < units.length-1){ n/=1000; u++; }
  return n.toFixed(2).replace(/\.00$/,"") + units[u];
}

/* Progression curve. Hero power and XP-per-level both grow geometrically, with XP
   growing slightly faster, so each zone takes a steady 20-50 fights. Content
   packs can override these under "progression"; the defaults were tuned by
   simulating a full playthrough against the zone powers (enemy power rises
   about 3.3x per zone). If power grows linearly while XP grows geometrically,
   the game stalls around zone 5. */
const PROG = Object.assign(
  { xpBase: 20, xpGrowth: 1.34, powerBase: 8, powerGrowth: 1.25 },
  C.progression || {}
);

function xpNeeded(level){ return Math.floor(PROG.xpBase * Math.pow(PROG.xpGrowth, level-1)); }

const defaultState = () => ({
  level: 1,
  xp: 0,
  biomass: 0,
  mana: 30,
  cores: { normal: 0, special: 0, rare: 0 },
  tierIndex: 0,
  zoneIndex: 0,
  workers: 0,
  queenUnlocked: false,
  eggChoice: null,
  companions: [],
  flags: {},
  bossesDown: [],
  log: [],
  battle: null
});

let state = load() || defaultState();
if(state.mana === undefined) state.mana = 30;

function save(){ localStorage.setItem(SAVE_KEY, JSON.stringify(state)); }
function load(){
  try{
    const raw = localStorage.getItem(SAVE_KEY);
    if(!raw) return null;
    return Object.assign(defaultState(), JSON.parse(raw));
  }catch(e){ return null; }
}
function resetGame(){
  if(!confirm(C.strings.confirmReset)) return;
  state = defaultState();
  save();
  logMsg(C.strings.resetDone);
  render();
}

function logMsg(text){
  state.log.unshift(text);
  if(state.log.length > 60) state.log.length = 60;
}

function currentTier(){ return C.tiers[state.tierIndex]; }
function currentZone(){ return C.zones[state.zoneIndex]; }

/* A zone lists several creatures; pick one, or fall back to the single-enemy
   shape older content packs used. */
function zoneRoster(zone){
  if(zone.enemies && zone.enemies.length) return zone.enemies;
  return [{
    name: zone.enemyName, avatar: zone.enemyAvatar, power: zone.enemyPower,
    xpReward: zone.xpReward, biomassReward: zone.biomassReward, coreChance: zone.coreChance
  }];
}
function pickEnemy(zone, index){
  const roster = zoneRoster(zone);
  // anything that isn't a real index (including a click event) means "pick one"
  if(typeof index !== "number" || !Number.isFinite(index)){
    index = Math.floor(Math.random()*roster.length);
  }
  return roster[Math.max(0, Math.min(roster.length - 1, Math.floor(index)))];
}

function heroPower(){
  const tier = currentTier();
  let p = PROG.powerBase * Math.pow(PROG.powerGrowth, state.level - 1) * tier.powerMult;
  if(state.eggChoice === "might") p *= 1.12;
  state.companions.forEach(name=>{
    const comp = C.companions.find(c=>c.name===name);
    if(comp) p *= comp.powerMult;
  });
  return p;
}

function workerOutput(){
  let base = state.workers * 0.6;
  if(state.eggChoice === "growth") base *= 1.35;
  return base;
}

function gainXp(amount){
  state.xp += amount;
  let needed = xpNeeded(state.level);
  while(state.xp >= needed){
    state.xp -= needed;
    state.level++;
    onLevelUp();
    needed = xpNeeded(state.level);
  }
}

function onLevelUp(){
  logMsg(C.strings.levelUp.replace("{level}", state.level));
  const nextTier = C.tiers[state.tierIndex+1];
  if(nextTier && state.level >= nextTier.reqLevel){
    state.tierIndex++;
    logMsg(C.strings.tierUp.replace("{tier}", nextTier.name));
    pushEvent(nextTier.flavor);
    if(nextTier.unlocksQueen) state.queenUnlocked = true;
    if(nextTier.unlocksEggChoice && !state.eggChoice) openEggChoiceModal();
    const comp = C.companions.find(c=>c.unlockTier === state.tierIndex);
    if(comp && !state.companions.includes(comp.name)){
      state.companions.push(comp.name);
      logMsg(C.strings.companionJoined.replace("{name}", comp.name));
      pushEvent(comp.flavor);
      if(WORLD3D && WORLD3D.mounted) WORLD3D.refreshCompanions();
    }
    if(WORLD3D && WORLD3D.mounted) WORLD3D.applyTierScale();
  }
  checkStoryEvents();
}

/* Story beats. Each fires once, the first time its condition is met, and is
   remembered in the save so it doesn't repeat. */
function checkStoryEvents(){
  if(!C.events || !C.events.length) return;
  state.flags.seenEvents = state.flags.seenEvents || [];
  for(const ev of C.events){
    if(state.flags.seenEvents.includes(ev.id)) continue;
    const w = ev.when || {};
    if(w.level !== undefined && state.level < w.level) continue;
    if(w.zone !== undefined && state.zoneIndex < w.zone) continue;
    if(w.tier !== undefined && state.tierIndex < w.tier) continue;
    if(w.bossesDown !== undefined && state.bossesDown.length < w.bossesDown) continue;
    state.flags.seenEvents.push(ev.id);
    queueStory(ev);
    return;   // one at a time, so beats don't pile up
  }
}

let storyQueue = [];
function queueStory(ev){
  storyQueue.push(ev);
  logMsg(ev.logLine || ev.title);
  if(!document.getElementById("storyModal").classList.contains("open")) showNextStory();
}
function showNextStory(){
  const ev = storyQueue.shift();
  if(!ev){ closeModal("storyModal"); return; }
  document.getElementById("storyTitle").textContent = ev.title;
  document.getElementById("storyText").textContent = ev.text;
  openModal("storyModal");
}

function pushEvent(text){
  if(!text) return;
  const box = document.getElementById("eventFlavor");
  if(box){ box.textContent = text; box.classList.add("flash"); setTimeout(()=>box.classList.remove("flash"), 900); }
}

/* ---------- Battle system ---------- */

function startBattle(isBoss, enemyIndex){
  if(state.battle && state.battle.active) return;
  const zone = currentZone();
  const foe = isBoss ? null : pickEnemy(zone, enemyIndex);
  state.battle = {
    active: true,
    isBoss,
    zoneName: zone.name,
    enemyName: isBoss ? zone.bossName : foe.name,
    enemyAvatar: isBoss ? zone.bossAvatar : foe.avatar,
    enemyPower: isBoss ? zone.bossPower : foe.power,
    reward: isBoss ? null : {
      xp: foe.xpReward, biomass: foe.biomassReward, coreChance: foe.coreChance
    },
    enemyHP: 100,
    playerHP: 100
  };
  logMsg(C.strings.battleStart.replace("{enemy}", state.battle.enemyName));
  openModal("battleModal");
  if(WORLD3D) WORLD3D.setPaused(true);
  render();
}

function battleAction(action){
  const b = state.battle;
  if(!b || !b.active) return;
  const ratio = heroPower() / b.enemyPower;
  let playerDmg = 0, selfHeal = 0, defendingNow = false;

  if(action === "attack"){
    playerDmg = clamp(16 + ratio*14, 8, 42) * (0.85 + Math.random()*0.3);
  } else if(action === "skill"){
    if(state.mana < 25){ logMsg(C.strings.notEnoughMana); render(); return; }
    state.mana -= 25;
    playerDmg = clamp(16 + ratio*14, 8, 42) * 1.6 * (0.85 + Math.random()*0.3);
  } else if(action === "defend"){
    defendingNow = true;
    selfHeal = 6;
    logMsg(C.strings.defendFlavor);
  } else if(action === "usecore"){
    if(state.cores.normal >= 3){ state.cores.normal -= 3; selfHeal = 22; }
    else if(state.cores.special >= 1){ state.cores.special -= 1; selfHeal = 30; }
    else if(state.cores.rare >= 1){ state.cores.rare -= 1; selfHeal = 45; }
    else { logMsg(C.strings.noCoresToUse); render(); return; }
    logMsg(C.strings.healFromCore);
  } else if(action === "flee"){
    logMsg(C.strings.battleFlee);
    state.battle = null;
    closeModal("battleModal");
    if(WORLD3D) WORLD3D.onBattleResolved();
    render();
    return;
  }

  if(playerDmg > 0){
    b.enemyHP = Math.max(0, b.enemyHP - playerDmg);
    logMsg(C.strings.playerHit.replace("{enemy}", b.enemyName).replace("{dmg}", Math.round(playerDmg)));
  }
  if(selfHeal > 0){
    b.playerHP = Math.min(100, b.playerHP + selfHeal);
  }
  if(b.enemyHP <= 0){ winBattle(); return; }

  const invRatio = b.enemyPower / heroPower();
  let enemyDmg = clamp(14 + invRatio*12, 8, 38) * (0.85 + Math.random()*0.3);
  if(defendingNow) enemyDmg *= 0.45;
  b.playerHP = Math.max(0, b.playerHP - enemyDmg);
  logMsg(C.strings.enemyTurnHit.replace("{enemy}", b.enemyName).replace("{dmg}", Math.round(enemyDmg)));
  if(b.playerHP <= 0){ loseBattle(); return; }
  render();
}

function winBattle(){
  const b = state.battle;
  const zone = C.zones.find(z => z.name === b.zoneName);
  logMsg(C.strings.battleWin.replace("{enemy}", b.enemyName));
  if(b.isBoss){
    if(!state.bossesDown.includes(zone.name)) state.bossesDown.push(zone.name);
    gainXp(zone.bossXp);
    state.cores.rare += 1;
    pushEvent(zone.bossFlavor);
  } else {
    const r = b.reward || { xp: zone.xpReward, biomass: zone.biomassReward, coreChance: zone.coreChance };
    gainXp(r.xp * (0.85 + Math.random()*0.3));
    state.biomass += r.biomass * (0.85 + Math.random()*0.3);
    rollCoreDrop(r.coreChance);
  }
  state.battle = null;
  closeModal("battleModal");
  if(WORLD3D) WORLD3D.onBattleResolved();
  render();
}

function loseBattle(){
  const b = state.battle;
  const zone = C.zones.find(z => z.name === b.zoneName);
  logMsg(C.strings.battleLoss.replace("{enemy}", b.enemyName));
  if(!b.isBoss){
    const loss = (b.reward ? b.reward.biomass : zone.biomassReward) * 0.2;
    state.biomass = Math.max(0, state.biomass - loss);
  }
  state.battle = null;
  closeModal("battleModal");
  if(WORLD3D) WORLD3D.onBattleResolved();
  render();
}

function rollCoreDrop(chance){
  if(Math.random() < chance){
    const roll = Math.random();
    if(roll < 0.05){ state.cores.rare++; logMsg(C.strings.coreDrop.replace("{grade}", C.strings.coreRare)); }
    else if(roll < 0.30){ state.cores.special++; logMsg(C.strings.coreDrop.replace("{grade}", C.strings.coreSpecial)); }
    else { state.cores.normal++; logMsg(C.strings.coreDrop.replace("{grade}", C.strings.coreNormal)); }
  }
}

/* ---------- Colony actions ---------- */

function hunt(enemyIndex){ startBattle(false, enemyIndex); }

function dig(){
  const cost = 15 + state.workers*4;
  if(state.biomass < cost){ logMsg(C.strings.notEnoughBiomass); render(); return; }
  state.biomass -= cost;
  state.workers++;
  logMsg(C.strings.newWorker);
  render();
}

function fuseCores(){
  if(state.cores.normal < 5){ logMsg(C.strings.needMoreCores); render(); return; }
  state.cores.normal -= 5;
  state.cores.special++;
  logMsg(C.strings.fuseSuccess);
  render();
}

function attemptBoss(){
  const zone = currentZone();
  if(state.bossesDown.includes(zone.name)){ advanceZone(); return; }
  startBattle(true);
}

function advanceZone(){
  const next = C.zones[state.zoneIndex+1];
  if(!next){ logMsg(C.strings.allZonesCleared); render(); return; }
  if(!state.bossesDown.includes(currentZone().name)){ logMsg(C.strings.mustDefeatBossFirst); render(); return; }
  state.zoneIndex++;
  logMsg(C.strings.zoneAdvance.replace("{zone}", next.name));
  pushEvent(next.flavor);
  if(WORLD3D && WORLD3D.mounted) WORLD3D.rebuildZone();
  checkStoryEvents();
  render();
}

/* ---------- 3D world ---------- */

function worldApi(){
  return {
    content: C,
    getZone: currentZone,
    getZoneIndex: () => state.zoneIndex,
    getCompanions: () => state.companions,
    getTier: () => state.tierIndex,
    onEnemyTouch: (index) => hunt(index),
    onBossTouch: () => attemptBoss()
  };
}

function openWorld(){
  openModal("worldModal");
  document.getElementById("worldZoneLabel").textContent = currentZone().name;
  setTimeout(()=>{
    const canvas = document.getElementById("world3dCanvas");
    if(!WORLD3D.mounted){
      WORLD3D.mount(canvas, worldApi());
      // first open: honour the saved choice, else default on for touch devices
      let saved = null;
      try{ saved = localStorage.getItem(TOUCH_KEY); }catch(e){}
      touchControlsOn = saved === null ? WORLD3D.touchDefaultsOn() : saved === "1";
      WORLD3D.setTouchControls(touchControlsOn);
      syncTouchButton();
    } else {
      WORLD3D.rebuildZone();
      WORLD3D.refreshCompanions();
      WORLD3D.applyTierScale();
      WORLD3D.resize();
    }
    WORLD3D.setPaused(false);
  }, 60);
}

function closeWorld(){
  if(WORLD3D) WORLD3D.setPaused(true);
  closeModal("worldModal");
  render();
}

function syncTouchButton(){
  const btn = document.getElementById("touchToggleBtn");
  btn.classList.toggle("on", touchControlsOn);
  btn.textContent = touchControlsOn ? "Touch controls: on" : "Touch controls: off";
}

function toggleTouchControls(){
  touchControlsOn = !touchControlsOn;
  if(WORLD3D) WORLD3D.setTouchControls(touchControlsOn);
  try{ localStorage.setItem(TOUCH_KEY, touchControlsOn ? "1" : "0"); }catch(e){}
  syncTouchButton();
}

function openEggChoiceModal(){ openModal("eggModal"); }
function chooseEgg(which){
  state.eggChoice = which;
  closeModal("eggModal");
  const label = which === C.eggChoice.optionA.key ? C.eggChoice.optionA.name : C.eggChoice.optionB.name;
  logMsg(C.strings.eggChosen.replace("{choice}", label));
  render();
}

function openModal(id){ const m = document.getElementById(id); if(m) m.classList.add("open"); }
function closeModal(id){ const m = document.getElementById(id); if(m) m.classList.remove("open"); }

function exportSave(){
  const data = btoa(unescape(encodeURIComponent(JSON.stringify(state))));
  const ta = document.getElementById("saveText");
  ta.value = data;
  ta.select();
}
function importSave(){
  const ta = document.getElementById("saveText");
  try{
    const parsed = JSON.parse(decodeURIComponent(escape(atob(ta.value.trim()))));
    state = Object.assign(defaultState(), parsed);
    save();
    render();
    logMsg(C.strings.importSuccess);
  }catch(e){ alert(C.strings.importFail); }
}

/* ---------- Rendering ---------- */

function avatar(kind, palette){
  return AVATARS.svg(kind, palette[0], palette[1]);
}

function render(){
  const tier = currentTier();
  const zone = currentZone();

  document.getElementById("heroName").textContent = C.meta.heroName;
  document.getElementById("heroAvatarBox").innerHTML = avatar(C.meta.heroAvatar, C.meta.colors.hero);
  document.getElementById("tierName").textContent = tier.name;
  document.getElementById("levelVal").textContent = state.level;
  const needed = xpNeeded(state.level);
  document.getElementById("xpBar").style.width = Math.min(100, (state.xp/needed)*100) + "%";
  document.getElementById("xpLabel").textContent = `${fmt(state.xp)} / ${fmt(needed)} XP`;
  document.getElementById("biomassVal").textContent = fmt(state.biomass);
  document.getElementById("workersVal").textContent = state.workers;
  document.getElementById("coreNormal").textContent = state.cores.normal;
  document.getElementById("coreSpecial").textContent = state.cores.special;
  document.getElementById("coreRare").textContent = state.cores.rare;
  document.getElementById("manaVal").textContent = Math.round(state.mana);
  document.getElementById("zoneName").textContent = zone.name;
  document.getElementById("zoneDesc").textContent = zone.desc;
  const roster = zoneRoster(zone);
  document.getElementById("enemyName").textContent = roster.map(e => e.name).join(", ");
  document.getElementById("enemyAvatarBox").innerHTML = avatar(roster[0].avatar, C.meta.colors.enemy);
  document.getElementById("bossName").textContent = zone.bossName;
  document.getElementById("bossAvatarBox").innerHTML = avatar(zone.bossAvatar, C.meta.colors.boss);
  document.getElementById("bossBtn").textContent = state.bossesDown.includes(zone.name)
    ? C.strings.advanceButton : C.strings.challengeButton.replace("{boss}", zone.bossName);
  document.getElementById("powerVal").textContent = fmt(heroPower());
  document.getElementById("companionsList").innerHTML = state.companions.map(n=>{
    const c = C.companions.find(cc=>cc.name===n);
    return `<div class="companion"><div class="companionRow">
      <div class="avatarBox small">${avatar(c.avatar, C.meta.colors.companion)}</div>
      <div><strong>${c.name}</strong><br><span>${c.desc}</span></div>
    </div></div>`;
  }).join("") || `<div class="muted">${C.strings.noCompanions}</div>`;
  document.getElementById("logFeed").innerHTML = state.log.map(l=>`<div>${l}</div>`).join("");
  document.getElementById("eggStatus").textContent = state.eggChoice
    ? (state.eggChoice===C.eggChoice.optionA.key ? C.eggChoice.optionA.name : C.eggChoice.optionB.name)
    : C.strings.eggNotChosen;
  document.getElementById("queenRow").style.display = state.queenUnlocked ? "flex" : "none";
  document.title = C.meta.title;

  renderBattle();
}

function renderBattle(){
  const b = state.battle;
  if(!b || !b.active) return;
  document.getElementById("battleHeroAvatar").innerHTML = avatar(C.meta.heroAvatar, C.meta.colors.hero);
  document.getElementById("battleEnemyAvatar").innerHTML = avatar(b.enemyAvatar, b.isBoss ? C.meta.colors.boss : C.meta.colors.enemy);
  document.getElementById("battleHeroHP").style.width = b.playerHP + "%";
  document.getElementById("battleEnemyHP").style.width = b.enemyHP + "%";
  document.getElementById("battleHeroLabel").textContent = `${C.meta.heroName} — ${Math.round(b.playerHP)}%`;
  document.getElementById("battleEnemyLabel").textContent = `${b.enemyName} — ${Math.round(b.enemyHP)}%`;
  document.getElementById("battleManaBar").style.width = state.mana + "%";
  document.getElementById("battleManaLabel").textContent = `Mana: ${Math.round(state.mana)}/100`;
  document.getElementById("battleSkillBtn").disabled = state.mana < 25;
  document.getElementById("battleCoreBtn").disabled = state.cores.normal < 3 && state.cores.special < 1 && state.cores.rare < 1;
}

function tick(){
  if(state.queenUnlocked && !(state.battle && state.battle.active)){
    state.biomass += workerOutput() * 0.5;
  }
  state.mana = Math.min(100, state.mana + 3);
  save();
  render();
}

function init(){
  document.getElementById("gameTitle").textContent = C.meta.title;
  document.getElementById("gameTagline").textContent = C.meta.tagline;
  document.getElementById("huntBtn").addEventListener("click", () => hunt());
  document.getElementById("digBtn").addEventListener("click", dig);
  document.getElementById("fuseBtn").addEventListener("click", fuseCores);
  document.getElementById("bossBtn").addEventListener("click", attemptBoss);
  document.getElementById("resetBtn").addEventListener("click", resetGame);
  document.getElementById("exportBtn").addEventListener("click", exportSave);
  document.getElementById("importBtn").addEventListener("click", importSave);
  document.getElementById("eggOptionA").addEventListener("click", ()=>chooseEgg(C.eggChoice.optionA.key));
  document.getElementById("eggOptionB").addEventListener("click", ()=>chooseEgg(C.eggChoice.optionB.key));
  document.getElementById("eggOptionA").querySelector(".t").textContent = C.eggChoice.optionA.name;
  document.getElementById("eggOptionA").querySelector(".d").textContent = C.eggChoice.optionA.desc;
  document.getElementById("eggOptionB").querySelector(".t").textContent = C.eggChoice.optionB.name;
  document.getElementById("eggOptionB").querySelector(".d").textContent = C.eggChoice.optionB.desc;
  document.getElementById("eggModalTitle").textContent = C.eggChoice.title;
  document.getElementById("eggModalDesc").textContent = C.eggChoice.desc;

  document.getElementById("battleAttackBtn").textContent = C.strings.actionAttack;
  document.getElementById("battleSkillBtn").textContent = C.strings.actionSkill + " (25 mana)";
  document.getElementById("battleDefendBtn").textContent = C.strings.actionDefend;
  document.getElementById("battleCoreBtn").textContent = C.strings.actionUseCore;
  document.getElementById("battleFleeBtn").textContent = C.strings.actionFlee;
  document.getElementById("battleAttackBtn").addEventListener("click", ()=>battleAction("attack"));
  document.getElementById("battleSkillBtn").addEventListener("click", ()=>battleAction("skill"));
  document.getElementById("battleDefendBtn").addEventListener("click", ()=>battleAction("defend"));
  document.getElementById("battleCoreBtn").addEventListener("click", ()=>battleAction("usecore"));
  document.getElementById("battleFleeBtn").addEventListener("click", ()=>battleAction("flee"));
  document.getElementById("worldBtn").addEventListener("click", openWorld);
  document.getElementById("worldCloseBtn").addEventListener("click", closeWorld);
  document.getElementById("touchToggleBtn").addEventListener("click", toggleTouchControls);
  syncTouchButton();

  document.getElementById("storyContinueBtn").addEventListener("click", showNextStory);
  if(state.log.length === 0) logMsg(C.strings.introLog);
  checkStoryEvents();
  if(state.battle && state.battle.active) openModal("battleModal");
  render();
  setInterval(tick, 2000);
}

if(document.readyState === "loading"){
  document.addEventListener("DOMContentLoaded", init);
} else {
  init();
}
