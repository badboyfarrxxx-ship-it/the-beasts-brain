/* Procedural creature models.
 *
 * Every creature is assembled from plain three.js primitives (spheres, boxes, cones,
 * cylinders) parameterized by two colors — no specific copyrighted character design
 * is referenced or reproduced.
 *
 * Each builder returns a THREE.Group carrying userData.anim:
 *   { legs: [pivot groups], feelers: [meshes], phase: number, bob: number }
 * so world3d.js can drive a walk cycle without knowing what shape it is.
 */
import * as THREE from "three";
import { carapaceTextures } from "./textures.js";

/* Carapace: a glossy shell with a clearcoat, pitted by a procedural normal map.
   Materials are cached per colour so a swarm of the same creature shares one. */
const matCache = new Map();
function cachedMat(key, make){
  if(!matCache.has(key)) matCache.set(key, make());
  return matCache.get(key);
}

function bodyMat(color){
  return cachedMat("body" + color, () => {
    const { roughnessMap, normalMap } = carapaceTextures();
    return new THREE.MeshPhysicalMaterial({
      color,
      roughness: 0.42,
      metalness: 0.08,
      clearcoat: 0.5,
      clearcoatRoughness: 0.28,
      roughnessMap,
      normalMap,
      normalScale: new THREE.Vector2(0.14, 0.14)
    });
  });
}
function limbMat(color){
  return cachedMat("limb" + color, () =>
    new THREE.MeshStandardMaterial({ color, roughness: 0.66, metalness: 0.04 }));
}
function softMat(color){
  return cachedMat("soft" + color, () =>
    new THREE.MeshStandardMaterial({ color, roughness: 0.55, metalness: 0.0 }));
}

function newGroup(){
  const g = new THREE.Group();
  g.userData.anim = { legs: [], feelers: [], phase: Math.random()*Math.PI*2, bob: 0.06 };
  return g;
}

/* A two-segment leg on a pivot, so it can swing fore/aft from the hip. */
function makeLeg(color, side, hipY, upperLen, lowerLen, spread){
  const pivot = new THREE.Group();
  pivot.position.y = hipY;

  const upper = new THREE.Mesh(new THREE.CylinderGeometry(0.038, 0.03, upperLen, 6), limbMat(color));
  upper.position.set(side*upperLen*0.45, -0.02, 0);
  upper.rotation.z = side * -(Math.PI/2 - spread);
  pivot.add(upper);

  const knee = new THREE.Group();
  knee.position.set(side*upperLen*0.88, -0.06, 0);
  const lower = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.018, lowerLen, 6), limbMat(color));
  lower.position.set(side*0.05, -lowerLen/2, 0);
  lower.rotation.z = side * 0.22;
  knee.add(lower);
  const foot = new THREE.Mesh(new THREE.SphereGeometry(0.032, 6, 6), limbMat(color));
  foot.position.set(side*0.10, -lowerLen, 0);
  knee.add(foot);
  pivot.add(knee);

  return pivot;
}

const BUILDERS = {
  ant(p, s){
    const g = newGroup();
    const body = bodyMat(p);

    const gaster = new THREE.Mesh(new THREE.SphereGeometry(0.4, 20, 14), body);
    gaster.scale.set(0.96, 0.92, 1.42);
    gaster.position.set(0, 0.52, -0.62);
    g.add(gaster);

    const petiole = new THREE.Mesh(new THREE.SphereGeometry(0.13, 12, 8), body);
    petiole.position.set(0, 0.47, -0.18);
    g.add(petiole);

    const thorax = new THREE.Mesh(new THREE.SphereGeometry(0.27, 18, 12), body);
    thorax.scale.set(0.95, 0.92, 1.3);
    thorax.position.set(0, 0.52, 0.2);
    g.add(thorax);

    const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.12, 0.14, 8), body);
    neck.rotation.x = Math.PI/2;
    neck.position.set(0, 0.54, 0.5);
    g.add(neck);

    const head = new THREE.Mesh(new THREE.SphereGeometry(0.25, 18, 12), body);
    head.scale.set(1.08, 0.94, 0.86);
    head.position.set(0, 0.57, 0.68);
    g.add(head);

    [-1, 1].forEach(side => {
      const mand = new THREE.Mesh(new THREE.ConeGeometry(0.052, 0.3, 6), limbMat(s));
      mand.position.set(side*0.1, 0.5, 0.92);
      mand.rotation.x = Math.PI/2;
      mand.rotation.z = side*0.3;
      g.add(mand);

      const eye = new THREE.Mesh(new THREE.SphereGeometry(0.062, 10, 8), softMat(s));
      eye.position.set(side*0.17, 0.64, 0.78);
      g.add(eye);

      const feeler = new THREE.Group();
      feeler.position.set(side*0.11, 0.7, 0.76);
      const seg = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.011, 0.5, 5), limbMat(s));
      seg.position.set(side*0.1, 0.2, 0.1);
      seg.rotation.x = -0.55;
      seg.rotation.z = side*0.42;
      feeler.add(seg);
      g.add(feeler);
      g.userData.anim.feelers.push(feeler);
    });

    // three legs a side, hips spaced along the thorax
    [-0.1, 0.16, 0.42].forEach((z, i) => {
      [-1, 1].forEach(side => {
        const leg = makeLeg(s, side, 0.5, 0.36, 0.34, 0.55 + i*0.06);
        leg.position.z = z;
        leg.position.x = side*0.2;
        g.add(leg);
        g.userData.anim.legs.push(leg);
      });
    });

    return g;
  },

  crawler(p, s){
    const g = BUILDERS.ant(p, s);
    g.scale.setScalar(0.66);
    // a few dorsal spikes so it reads as something else at a glance
    [-0.5, -0.3, -0.1].forEach(z => {
      const spike = new THREE.Mesh(new THREE.ConeGeometry(0.05, 0.18, 5), limbMat(s));
      spike.position.set(0, 0.82, z);
      g.add(spike);
    });
    return g;
  },

  beast(p, s){
    const g = newGroup();
    const body = bodyMat(p);

    const torso = new THREE.Mesh(new THREE.SphereGeometry(0.42, 20, 14), body);
    torso.scale.set(1.0, 0.86, 1.32);
    torso.position.y = 0.55;
    g.add(torso);

    const rump = new THREE.Mesh(new THREE.SphereGeometry(0.3, 16, 12), body);
    rump.position.set(0, 0.55, -0.42);
    g.add(rump);

    const head = new THREE.Mesh(new THREE.SphereGeometry(0.26, 16, 12), body);
    head.position.set(0, 0.66, 0.52);
    g.add(head);
    const muzzle = new THREE.Mesh(new THREE.ConeGeometry(0.14, 0.26, 8), body);
    muzzle.rotation.x = Math.PI/2;
    muzzle.position.set(0, 0.6, 0.72);
    g.add(muzzle);

    [-1, 1].forEach(side => {
      const ear = new THREE.Mesh(new THREE.ConeGeometry(0.09, 0.2, 6), body);
      ear.position.set(side*0.14, 0.86, 0.48);
      ear.rotation.z = side*0.25;
      g.add(ear);
      const eye = new THREE.Mesh(new THREE.SphereGeometry(0.04, 8, 8), softMat(s));
      eye.position.set(side*0.11, 0.7, 0.68);
      g.add(eye);
    });

    [[-0.3], [0.34]].forEach(([z], i) => {
      [-1, 1].forEach(side => {
        const leg = makeLeg(s, side, 0.5, 0.2, 0.34, 1.15);
        leg.position.set(side*0.22, 0.5, z);
        g.add(leg);
        g.userData.anim.legs.push(leg);
      });
    });

    const tail = new THREE.Group();
    tail.position.set(0, 0.66, -0.62);
    const tailMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.02, 0.5, 6), body);
    tailMesh.position.set(0, 0.16, -0.12);
    tailMesh.rotation.x = 0.9;
    tail.add(tailMesh);
    g.add(tail);
    g.userData.anim.feelers.push(tail);

    return g;
  },

  tendril(p, s){
    const g = newGroup();
    const core = new THREE.Mesh(new THREE.SphereGeometry(0.42, 20, 14), bodyMat(p));
    core.position.y = 0.62;
    g.add(core);
    const maw = new THREE.Mesh(new THREE.SphereGeometry(0.19, 14, 10), softMat(s));
    maw.position.set(0, 0.62, 0.3);
    g.add(maw);

    for(let i = 0; i < 8; i++){
      const ang = (i/8)*Math.PI*2;
      const arm = new THREE.Group();
      arm.position.set(Math.cos(ang)*0.3, 0.55, Math.sin(ang)*0.3);
      const seg1 = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.035, 0.36, 6), bodyMat(p));
      seg1.position.set(Math.cos(ang)*0.16, -0.12, Math.sin(ang)*0.16);
      seg1.rotation.z = -Math.cos(ang)*1.0;
      seg1.rotation.x = Math.sin(ang)*1.0;
      arm.add(seg1);
      const seg2 = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.012, 0.32, 5), bodyMat(p));
      seg2.position.set(Math.cos(ang)*0.36, -0.3, Math.sin(ang)*0.36);
      seg2.rotation.z = -Math.cos(ang)*0.5;
      seg2.rotation.x = Math.sin(ang)*0.5;
      arm.add(seg2);
      g.add(arm);
      g.userData.anim.feelers.push(arm);
    }
    g.userData.anim.bob = 0.12;
    return g;
  },

  vine(p, s){
    const g = newGroup();
    const stem = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.13, 0.66, 8), softMat(p));
    stem.position.y = 0.33;
    g.add(stem);
    const bulb = new THREE.Mesh(new THREE.SphereGeometry(0.22, 14, 10), bodyMat(p));
    bulb.position.y = 0.72;
    g.add(bulb);
    const bud = new THREE.Mesh(new THREE.SphereGeometry(0.12, 10, 8), softMat(s));
    bud.position.set(0, 0.76, 0.14);
    g.add(bud);
    for(let i = 0; i < 7; i++){
      const ang = (i/7)*Math.PI*2;
      const petal = new THREE.Group();
      petal.position.set(0, 0.74, 0);
      const blade = new THREE.Mesh(new THREE.ConeGeometry(0.1, 0.44, 5), bodyMat(p));
      blade.position.set(Math.cos(ang)*0.26, 0.1, Math.sin(ang)*0.26);
      blade.rotation.z = -Math.cos(ang)*1.15;
      blade.rotation.x = Math.sin(ang)*1.15;
      petal.add(blade);
      g.add(petal);
      g.userData.anim.feelers.push(petal);
    }
    for(let i = 0; i < 4; i++){
      const ang = (i/4)*Math.PI*2 + 0.4;
      const root = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.02, 0.4, 5), softMat(p));
      root.position.set(Math.cos(ang)*0.22, 0.1, Math.sin(ang)*0.22);
      root.rotation.z = -Math.cos(ang)*0.9;
      root.rotation.x = Math.sin(ang)*0.9;
      g.add(root);
    }
    g.userData.anim.bob = 0.02;
    return g;
  },

  croc(p, s){
    const g = newGroup();
    const body = bodyMat(p);

    const trunk = new THREE.Mesh(new THREE.SphereGeometry(0.34, 20, 14), body);
    trunk.scale.set(1.05, 0.72, 1.9);
    trunk.position.y = 0.34;
    g.add(trunk);

    const skull = new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.2, 0.36), body);
    skull.position.set(0, 0.34, 0.72);
    g.add(skull);
    const snout = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.14, 0.5), body);
    snout.position.set(0, 0.31, 1.06);
    g.add(snout);

    for(let i = 0; i < 6; i++){
      [-1, 1].forEach(side => {
        const tooth = new THREE.Mesh(new THREE.ConeGeometry(0.022, 0.09, 4), softMat(s));
        tooth.position.set(side*0.1, 0.27, 0.9 + i*0.08);
        tooth.rotation.x = Math.PI;
        g.add(tooth);
      });
    }
    [-1, 1].forEach(side => {
      const eye = new THREE.Mesh(new THREE.SphereGeometry(0.05, 8, 8), softMat(s));
      eye.position.set(side*0.13, 0.45, 0.66);
      g.add(eye);
    });
    // dorsal scutes
    for(let i = 0; i < 5; i++){
      const scute = new THREE.Mesh(new THREE.ConeGeometry(0.07, 0.14, 4), limbMat(s));
      scute.position.set(0, 0.56, 0.3 - i*0.26);
      g.add(scute);
    }

    const tail = new THREE.Group();
    tail.position.set(0, 0.34, -0.6);
    const t1 = new THREE.Mesh(new THREE.ConeGeometry(0.2, 0.7, 7), body);
    t1.rotation.x = -Math.PI/2;
    t1.position.z = -0.32;
    tail.add(t1);
    g.add(tail);
    g.userData.anim.feelers.push(tail);

    [[-0.38], [0.36]].forEach(([z]) => {
      [-1, 1].forEach(side => {
        const leg = makeLeg(s, side, 0.3, 0.2, 0.2, 1.0);
        leg.position.set(side*0.24, 0.3, z);
        g.add(leg);
        g.userData.anim.legs.push(leg);
      });
    });

    g.userData.anim.bob = 0.03;
    return g;
  },

  marauder(p, s){
    const g = newGroup();
    const body = bodyMat(p);
    const robe = new THREE.Mesh(new THREE.ConeGeometry(0.42, 1.15, 10), body);
    robe.position.y = 0.58;
    g.add(robe);
    const shoulders = new THREE.Mesh(new THREE.SphereGeometry(0.26, 12, 10), body);
    shoulders.scale.set(1.3, 0.6, 0.9);
    shoulders.position.y = 1.08;
    g.add(shoulders);
    const hood = new THREE.Mesh(new THREE.ConeGeometry(0.22, 0.34, 8), body);
    hood.position.y = 1.3;
    g.add(hood);
    const face = new THREE.Mesh(new THREE.SphereGeometry(0.15, 12, 10), softMat("#111111"));
    face.position.set(0, 1.22, 0.1);
    g.add(face);
    [-1, 1].forEach(side => {
      const eye = new THREE.Mesh(new THREE.SphereGeometry(0.035, 8, 8), softMat(s));
      eye.position.set(side*0.07, 1.23, 0.2);
      g.add(eye);
    });
    const arm = new THREE.Group();
    arm.position.set(0.34, 1.02, 0);
    const staff = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.025, 1.5, 6), limbMat(s));
    staff.position.set(0.02, -0.18, 0.06);
    staff.rotation.x = 0.12;
    arm.add(staff);
    const head = new THREE.Mesh(new THREE.OctahedronGeometry(0.1), softMat(s));
    head.position.set(0.02, 0.58, 0.14);
    arm.add(head);
    g.add(arm);
    g.userData.anim.feelers.push(arm);
    g.userData.anim.bob = 0.09;
    return g;
  },

  golem(p, s){
    const g = newGroup();
    const rock = new THREE.MeshStandardMaterial({ color: p, roughness: 0.96, metalness: 0.02, flatShading: true });
    const chunks = [
      [0, 0.46, 0, 0.74, 0.62, 0.52],
      [0.06, 0.94, 0.02, 0.56, 0.42, 0.42],
      [-0.06, 1.26, -0.02, 0.36, 0.3, 0.32]
    ];
    chunks.forEach(([x, y, z, w, h, d]) => {
      const c = new THREE.Mesh(new THREE.DodecahedronGeometry(Math.max(w, h)*0.62, 0), rock);
      c.position.set(x, y, z);
      c.scale.set(w/h*0.9, 1, d/h*0.95);
      c.rotation.set(Math.random()*0.4, Math.random()*Math.PI, Math.random()*0.3);
      g.add(c);
    });
    [-1, 1].forEach(side => {
      const eye = new THREE.Mesh(new THREE.SphereGeometry(0.05, 8, 8), softMat(s));
      eye.position.set(side*0.1, 1.3, 0.22);
      g.add(eye);
      const armPivot = new THREE.Group();
      armPivot.position.set(side*0.4, 1.0, 0);
      const arm = new THREE.Mesh(new THREE.DodecahedronGeometry(0.18, 0), rock);
      arm.scale.set(0.7, 1.5, 0.7);
      arm.position.y = -0.24;
      armPivot.add(arm);
      g.add(armPivot);
      g.userData.anim.feelers.push(armPivot);
    });
    for(let i = 0; i < 5; i++){
      const crack = new THREE.Mesh(new THREE.SphereGeometry(0.04, 6, 6), softMat(s));
      crack.position.set((Math.random()-0.5)*0.5, 0.4 + Math.random()*0.7, 0.26);
      g.add(crack);
    }
    [[-1], [1]].forEach(([side]) => {
      const leg = makeLeg(s, side, 0.42, 0.14, 0.3, 1.35);
      leg.position.set(side*0.2, 0.42, 0);
      g.add(leg);
      g.userData.anim.legs.push(leg);
    });
    g.userData.anim.bob = 0.05;
    return g;
  },

  beetle(p, s){
    const g = newGroup();
    const body = bodyMat(p);
    const shell = new THREE.Mesh(new THREE.SphereGeometry(0.5, 20, 14), body);
    shell.scale.set(1.0, 0.62, 1.35);
    shell.position.set(0, 0.46, -0.08);
    g.add(shell);
    // wing-case seam
    const seam = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.02, 1.2), limbMat(s));
    seam.position.set(0, 0.76, -0.08);
    g.add(seam);
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.22, 16, 12), body);
    head.scale.set(1.1, 0.8, 0.8);
    head.position.set(0, 0.42, 0.56);
    g.add(head);
    const horn = new THREE.Mesh(new THREE.ConeGeometry(0.07, 0.45, 6), limbMat(s));
    horn.position.set(0, 0.56, 0.78);
    horn.rotation.x = -0.75;
    g.add(horn);
    [-1, 1].forEach(side => {
      const eye = new THREE.Mesh(new THREE.SphereGeometry(0.045, 8, 8), softMat(s));
      eye.position.set(side*0.14, 0.48, 0.7);
      g.add(eye);
    });
    [-0.28, 0.02, 0.32].forEach((z, i) => {
      [-1, 1].forEach(side => {
        const leg = makeLeg(s, side, 0.36, 0.3, 0.26, 0.75 + i*0.05);
        leg.position.set(side*0.3, 0.36, z);
        g.add(leg);
        g.userData.anim.legs.push(leg);
      });
    });
    g.userData.anim.bob = 0.04;
    return g;
  },

  worm(p, s){
    const g = newGroup();
    const body = bodyMat(p);
    const segs = 9;
    for(let i = 0; i < segs; i++){
      const t = i/(segs - 1);
      const seg = new THREE.Mesh(new THREE.SphereGeometry(0.3 - t*0.14, 14, 10), body);
      const wrap = new THREE.Group();
      wrap.position.set(0, 0.3 - t*0.06, 0.7 - i*0.28);
      wrap.add(seg);
      g.add(wrap);
      if(i > 0) g.userData.anim.feelers.push(wrap);   // ripples down the body
      if(i % 2 === 1){
        const band = new THREE.Mesh(new THREE.TorusGeometry(0.3 - t*0.14, 0.022, 6, 14), limbMat(s));
        band.rotation.y = Math.PI/2;
        wrap.add(band);
      }
    }
    const maw = new THREE.Mesh(new THREE.SphereGeometry(0.17, 14, 10), softMat(s));
    maw.position.set(0, 0.3, 0.88);
    g.add(maw);
    g.userData.anim.bob = 0.1;
    return g;
  },

  spider(p, s){
    const g = newGroup();
    const body = bodyMat(p);
    const abdomen = new THREE.Mesh(new THREE.SphereGeometry(0.4, 20, 14), body);
    abdomen.scale.set(1, 0.9, 1.15);
    abdomen.position.set(0, 0.62, -0.4);
    g.add(abdomen);
    const cephalo = new THREE.Mesh(new THREE.SphereGeometry(0.26, 16, 12), body);
    cephalo.scale.set(1.1, 0.8, 1);
    cephalo.position.set(0, 0.6, 0.12);
    g.add(cephalo);
    // eye cluster
    [[-0.1, 0.68, 0.32], [0.1, 0.68, 0.32], [-0.05, 0.62, 0.36], [0.05, 0.62, 0.36]].forEach(([x, y, z]) => {
      const eye = new THREE.Mesh(new THREE.SphereGeometry(0.035, 8, 8), softMat(s));
      eye.position.set(x, y, z);
      g.add(eye);
    });
    [-0.16, 0.04, 0.2, 0.34].forEach((z, i) => {
      [-1, 1].forEach(side => {
        const leg = makeLeg(s, side, 0.62, 0.42, 0.5, 0.35 + i*0.08);
        leg.position.set(side*0.2, 0.62, z);
        g.add(leg);
        g.userData.anim.legs.push(leg);
      });
    });
    g.userData.anim.bob = 0.05;
    return g;
  },

  wisp(p, s){
    const g = newGroup();
    const glow = new THREE.MeshStandardMaterial({
      color: p, emissive: new THREE.Color(p), emissiveIntensity: 0.9,
      roughness: 0.3, transparent: true, opacity: 0.85
    });
    const core = new THREE.Mesh(new THREE.IcosahedronGeometry(0.3, 1), glow);
    core.position.y = 0.95;
    g.add(core);
    const halo = new THREE.Mesh(new THREE.TorusGeometry(0.46, 0.035, 8, 20),
      new THREE.MeshStandardMaterial({ color: s, emissive: new THREE.Color(s), emissiveIntensity: 0.5, roughness: 0.4 }));
    halo.position.y = 0.95;
    halo.rotation.x = 1.2;
    g.add(halo);
    g.userData.anim.feelers.push(halo);
    for(let i = 0; i < 5; i++){
      const ang = (i/5)*Math.PI*2;
      const mote = new THREE.Mesh(new THREE.SphereGeometry(0.06, 8, 8), glow);
      const orbit = new THREE.Group();
      orbit.position.y = 0.95;
      mote.position.set(Math.cos(ang)*0.55, Math.sin(ang)*0.2, Math.sin(ang)*0.55);
      orbit.add(mote);
      g.add(orbit);
      g.userData.anim.feelers.push(orbit);
    }
    g.userData.anim.bob = 0.16;
    return g;
  },

  serpent(p, s){
    const g = newGroup();
    const body = bodyMat(p);
    const segs = 7;
    for(let i = 0; i < segs; i++){
      const t = i/(segs - 1);
      const wrap = new THREE.Group();
      wrap.position.set(0, 0.36 + Math.sin(t*3)*0.12, 0.6 - i*0.3);
      const seg = new THREE.Mesh(new THREE.SphereGeometry(0.26 - t*0.1, 14, 10), body);
      seg.scale.set(1, 0.85, 1.2);
      wrap.add(seg);
      g.add(wrap);
      if(i > 0) g.userData.anim.feelers.push(wrap);
    }
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.24, 16, 12), body);
    head.scale.set(1.05, 0.72, 1.3);
    head.position.set(0, 0.42, 0.86);
    g.add(head);
    const jaw = new THREE.Mesh(new THREE.ConeGeometry(0.16, 0.3, 7), body);
    jaw.rotation.x = Math.PI/2;
    jaw.position.set(0, 0.38, 1.08);
    g.add(jaw);
    [-1, 1].forEach(side => {
      const eye = new THREE.Mesh(new THREE.SphereGeometry(0.045, 8, 8), softMat(s));
      eye.position.set(side*0.13, 0.5, 0.94);
      g.add(eye);
      const frill = new THREE.Mesh(new THREE.ConeGeometry(0.07, 0.3, 5), limbMat(s));
      frill.position.set(side*0.18, 0.5, 0.72);
      frill.rotation.z = side*0.9;
      g.add(frill);
    });
    g.userData.anim.bob = 0.08;
    return g;
  },

  demon(p, s){
    const g = newGroup();
    const body = bodyMat(p);
    const torso = new THREE.Mesh(new THREE.ConeGeometry(0.34, 0.95, 8), body);
    torso.position.y = 0.6;
    g.add(torso);
    const chest = new THREE.Mesh(new THREE.SphereGeometry(0.26, 12, 10), body);
    chest.scale.set(1.2, 0.8, 0.8);
    chest.position.y = 0.95;
    g.add(chest);
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.21, 14, 10), body);
    head.position.y = 1.24;
    g.add(head);
    [-1, 1].forEach(side => {
      const horn = new THREE.Mesh(new THREE.ConeGeometry(0.055, 0.34, 6), limbMat(s));
      horn.position.set(side*0.14, 1.42, -0.02);
      horn.rotation.z = side*0.42;
      horn.rotation.x = -0.25;
      g.add(horn);
      const eye = new THREE.Mesh(new THREE.SphereGeometry(0.04, 8, 8), softMat(s));
      eye.position.set(side*0.09, 1.26, 0.18);
      g.add(eye);

      const wing = new THREE.Group();
      wing.position.set(side*0.2, 1.0, -0.14);
      const membrane = new THREE.Mesh(
        new THREE.PlaneGeometry(0.72, 0.5),
        new THREE.MeshStandardMaterial({ color: p, side: THREE.DoubleSide, roughness: 0.7, metalness: 0.1 })
      );
      membrane.position.set(side*0.36, 0.06, -0.06);
      membrane.rotation.y = side*0.7;
      wing.add(membrane);
      const strut = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.015, 0.7, 5), limbMat(s));
      strut.position.set(side*0.34, 0.16, -0.05);
      strut.rotation.z = side*1.2;
      wing.add(strut);
      g.add(wing);
      g.userData.anim.feelers.push(wing);
    });
    const tail = new THREE.Group();
    tail.position.set(0, 0.42, -0.24);
    const tailMesh = new THREE.Mesh(new THREE.ConeGeometry(0.07, 0.72, 6), body);
    tailMesh.rotation.x = -1.1;
    tailMesh.position.set(0, -0.02, -0.28);
    tail.add(tailMesh);
    g.add(tail);
    g.userData.anim.feelers.push(tail);

    [[-1], [1]].forEach(([side]) => {
      const leg = makeLeg(s, side, 0.5, 0.16, 0.36, 1.3);
      leg.position.set(side*0.16, 0.5, 0);
      g.add(leg);
      g.userData.anim.legs.push(leg);
    });
    g.userData.anim.bob = 0.07;
    return g;
  }
};

/* Strips the expensive shader features off every creature material. Used by the
   quality watchdog when the device can't keep up: clearcoat and normal mapping
   are per-pixel costs, and dropping them is far better than dropping frames. */
export function setMaterialQuality(low){
  matCache.forEach(m => {
    if(low){
      if(m.clearcoat !== undefined){ m.userData.clearcoat = m.userData.clearcoat ?? m.clearcoat; m.clearcoat = 0; }
      if(m.normalMap){ m.userData.normalMap = m.userData.normalMap || m.normalMap; m.normalMap = null; }
      if(m.roughnessMap){ m.userData.roughnessMap = m.userData.roughnessMap || m.roughnessMap; m.roughnessMap = null; }
    } else {
      if(m.userData.clearcoat !== undefined) m.clearcoat = m.userData.clearcoat;
      if(m.userData.normalMap) m.normalMap = m.userData.normalMap;
      if(m.userData.roughnessMap) m.roughnessMap = m.userData.roughnessMap;
    }
    m.needsUpdate = true;
  });
}

export function buildProceduralCreature(kind, colors, scale){
  const fn = BUILDERS[kind] || BUILDERS.ant;
  const g = fn(colors[0], colors[1]);
  g.scale.multiplyScalar(scale);
  g.traverse(o => { if(o.isMesh){ o.castShadow = true; o.receiveShadow = false; } });
  return g;
}

export const CREATURE_KINDS = Object.keys(BUILDERS);

/* Drives the walk cycle. `speed` is 0 when standing still, 1 when moving. */
export function animateCreature(group, time, speed){
  const a = group.userData.anim;
  if(!a) return;
  const swing = 0.12 + speed*0.55;
  const rate = 2.2 + speed*9;
  const t = time*rate + a.phase;
  a.legs.forEach((leg, i) => {
    // alternating tripod: every other leg is half a cycle out of phase
    const offset = (i % 2 === 0 ? 0 : Math.PI) + Math.floor(i/2)*0.35;
    leg.rotation.x = Math.sin(t + offset) * swing;
  });
  a.feelers.forEach((f, i) => {
    f.rotation.x = Math.sin(t*0.55 + i) * (0.09 + speed*0.1);
    f.rotation.z = Math.cos(t*0.4 + i) * 0.06;
  });
}
