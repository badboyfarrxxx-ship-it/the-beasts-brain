/* Touch controls for the 3D world.
 *
 * A thumbstick that appears wherever you put your finger down on the view:
 * push up/down to walk forward and back, left/right to turn — the same two axes
 * the keyboard drives, so nothing downstream has to know which one is in use.
 *
 * Uses Pointer Events, so it works for touch, pen and mouse alike. */

const RADIUS = 58;      // px the knob can travel from the origin
const DEADZONE = 0.16;  // ignore tiny wobbles so standing still is easy

export function mountTouchControls(host, surface, onInput){
  const stick = document.createElement("div");
  stick.className = "stick";
  stick.innerHTML = '<div class="stickKnob"></div>';
  host.appendChild(stick);
  const knob = stick.querySelector(".stickKnob");

  let activeId = null;
  let originX = 0, originY = 0;

  const send = (move, turn) => onInput(move, turn);

  // the stick is positioned inside `host`, but coordinates come from `surface`,
  // which sits below the HUD — so shift by the difference
  const place = (x, y) => {
    const s = surface.getBoundingClientRect();
    const h = host.getBoundingClientRect();
    stick.style.left = (x + s.left - h.left) + "px";
    stick.style.top = (y + s.top - h.top) + "px";
  };

  const reset = () => {
    activeId = null;
    stick.classList.remove("active");
    knob.style.transform = "translate(-50%, -50%)";
    send(0, 0);
  };

  surface.addEventListener("pointerdown", e => {
    if(activeId !== null) return;
    activeId = e.pointerId;
    surface.setPointerCapture(e.pointerId);
    const rect = surface.getBoundingClientRect();
    originX = e.clientX - rect.left;
    originY = e.clientY - rect.top;
    place(originX, originY);
    knob.style.transform = "translate(-50%, -50%)";
    stick.classList.add("active");
    e.preventDefault();
  });

  surface.addEventListener("pointermove", e => {
    if(e.pointerId !== activeId) return;
    const rect = surface.getBoundingClientRect();
    let dx = (e.clientX - rect.left) - originX;
    let dy = (e.clientY - rect.top) - originY;

    const dist = Math.hypot(dx, dy);
    if(dist > RADIUS){
      dx = dx/dist*RADIUS;
      dy = dy/dist*RADIUS;
    }
    knob.style.transform = `translate(calc(-50% + ${dx}px), calc(-50% + ${dy}px))`;

    const nx = dx/RADIUS, ny = dy/RADIUS;
    const move = Math.abs(ny) < DEADZONE ? 0 : -ny;  // up on screen = forward
    const turn = Math.abs(nx) < DEADZONE ? 0 : -nx;  // right on screen = turn right
    send(move, turn);
    e.preventDefault();
  });

  const end = e => { if(e.pointerId === activeId) reset(); };
  surface.addEventListener("pointerup", end);
  surface.addEventListener("pointercancel", end);
  surface.addEventListener("lostpointercapture", end);

  return {
    show(){ host.classList.add("touchOn"); },
    hide(){ host.classList.remove("touchOn"); reset(); },
    reset
  };
}

/* Coarse pointer means a finger, so default the controls on. */
export function looksLikeTouchDevice(){
  return (window.matchMedia && window.matchMedia("(pointer: coarse)").matches)
    || "ontouchstart" in window
    || navigator.maxTouchPoints > 0;
}
