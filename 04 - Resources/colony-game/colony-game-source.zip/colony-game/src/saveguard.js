/* Make a save fit the build that loads it.

   A save code can come from a different build: most often a full-game save
   pasted into the demo, which points at zones, tiers and companions the demo
   doesn't contain, and the colony screen would crash looking them up. Clamp the
   indexes and drop unknown companions. Pure, so it can be unit tested. */

export function clampToContent(state, content){
  const clamp = (v, max) => Math.min(Math.max(0, Number.isInteger(v) ? v : 0), max);
  const known = new Set(content.companions.map(c => c.name));
  return {
    ...state,
    zoneIndex: clamp(state.zoneIndex, content.zones.length - 1),
    tierIndex: clamp(state.tierIndex, content.tiers.length - 1),
    companions: (state.companions || []).filter(n => known.has(n))
  };
}
