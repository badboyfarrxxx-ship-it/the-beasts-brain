/* Optional real 3D models.
 *
 * Every creature in the game is drawn procedurally by world3d.js out of three.js
 * primitives. That's the fallback, and it works with no asset files at all.
 *
 * To use a real modelled character instead, drop a .glb into src/models/ and point
 * the matching kind at it:
 *
 *     import antUrl from "./models/ant.glb?url";
 *     export const MODELS = { ...blank, ant: antUrl };
 *
 * Vite inlines it into the single-file build automatically (assetsInlineLimit is
 * set high in vite.config.js), so the game still runs offline from one file.
 *
 * `npm run models` writes the current procedural creatures out as .glb files into
 * src/models/, so you have correctly-scaled starting points to open in Blender
 * rather than modelling against nothing.
 *
 * Model expectations: +Z is forward, feet at y = 0, roughly 1 unit tall for a
 * normal creature. Use TUNING below to correct anything that comes in wrong
 * instead of re-exporting.
 *
 * Note: a loaded model keeps its own materials, so it ignores the per-pack colour
 * palette in content.*.json. That's usually what you want (the model carries its
 * own look), but it does mean a model used for an enemy won't be auto-tinted the
 * enemy colour the way the procedural shapes are.
 *
 * Verified working: exporting ant.glb/croc.glb with `npm run models`, registering
 * them here and rebuilding loads them into the scene in place of the procedural
 * shapes, with movement, collisions and battles all still working.
 */

const blank = {
  ant: null,
  crawler: null,
  beast: null,
  tendril: null,
  vine: null,
  croc: null,
  marauder: null,
  golem: null,
  demon: null
};

export const MODELS = { ...blank };

/* Per-kind corrections applied after a model loads. */
export const TUNING = {
  // ant: { scale: 0.01, rotationY: Math.PI, offsetY: 0 }
};
