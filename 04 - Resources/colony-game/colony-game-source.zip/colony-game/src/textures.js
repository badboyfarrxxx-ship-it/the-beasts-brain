/* Procedural textures, drawn to a canvas at runtime.
 *
 * Everything here is generated from noise — no image files — so the game stays a
 * single self-contained page that works offline, while still getting surface
 * detail, roughness variation and normal-mapped relief instead of flat plastic.
 */
import * as THREE from "three";

/* Cheap value noise with smooth interpolation. Deterministic per seed so a given
   zone always looks the same. */
function makeNoise(seed){
  const rand = (x, y) => {
    const n = Math.sin(x*127.1 + y*311.7 + seed*74.7) * 43758.5453;
    return n - Math.floor(n);
  };
  const smooth = t => t*t*(3 - 2*t);
  return (x, y) => {
    const xi = Math.floor(x), yi = Math.floor(y);
    const xf = x - xi, yf = y - yi;
    const a = rand(xi, yi), b = rand(xi+1, yi);
    const c = rand(xi, yi+1), d = rand(xi+1, yi+1);
    const u = smooth(xf), v = smooth(yf);
    return a*(1-u)*(1-v) + b*u*(1-v) + c*(1-u)*v + d*u*v;
  };
}

function fbm(noise, x, y, octaves = 4){
  let value = 0, amp = 0.5, freq = 1;
  for(let i = 0; i < octaves; i++){
    value += noise(x*freq, y*freq) * amp;
    freq *= 2;
    amp *= 0.5;
  }
  return value;
}

function canvasTexture(size, draw, { repeat = 1, srgb = false } = {}){
  const canvas = document.createElement("canvas");
  canvas.width = canvas.height = size;
  const ctx = canvas.getContext("2d");
  draw(ctx, size);
  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(repeat, repeat);
  tex.anisotropy = 8;
  if(srgb) tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

/* Turns a height field into a normal map, so surfaces catch light with real relief. */
function normalFromHeight(size, heightAt){
  return canvasTexture(size, (ctx, s) => {
    const img = ctx.createImageData(s, s);
    for(let y = 0; y < s; y++){
      for(let x = 0; x < s; x++){
        const hL = heightAt((x-1+s)%s, y), hR = heightAt((x+1)%s, y);
        const hD = heightAt(x, (y-1+s)%s), hU = heightAt(x, (y+1)%s);
        // gradient -> normal
        let nx = (hL - hR)*2, ny = (hD - hU)*2, nz = 1;
        const len = Math.hypot(nx, ny, nz);
        nx /= len; ny /= len; nz /= len;
        const i = (y*s + x)*4;
        img.data[i]   = (nx*0.5 + 0.5)*255;
        img.data[i+1] = (ny*0.5 + 0.5)*255;
        img.data[i+2] = (nz*0.5 + 0.5)*255;
        img.data[i+3] = 255;
      }
    }
    ctx.putImageData(img, 0, 0);
  });
}

const cache = new Map();
const cached = (key, make) => {
  if(!cache.has(key)) cache.set(key, make());
  return cache.get(key);
};

/* --- ground: mottled dirt with grain and pebbles --- */
export function groundTextures(hue){
  return cached("ground" + Math.round(hue), () => {
    const noise = makeNoise(hue);
    const S = 512;
    const height = (x, y) => fbm(noise, x/28, y/28, 5);

    const map = canvasTexture(S, (ctx, s) => {
      const img = ctx.createImageData(s, s);
      for(let y = 0; y < s; y++){
        for(let x = 0; x < s; x++){
          const n = height(x, y);
          const grain = (Math.sin(x*12.9898 + y*78.233)*43758.5453 % 1 + 1) % 1;
          const light = 28 + n*12 + grain*3;          // % lightness
          const sat = 14 + n*8;
          const col = new THREE.Color(`hsl(${hue + n*18 - 9}, ${sat}%, ${light}%)`);
          const i = (y*s + x)*4;
          img.data[i] = col.r*255; img.data[i+1] = col.g*255; img.data[i+2] = col.b*255; img.data[i+3] = 255;
        }
      }
      ctx.putImageData(img, 0, 0);
    }, { repeat: 5, srgb: true });

    const roughnessMap = canvasTexture(S, (ctx, s) => {
      const img = ctx.createImageData(s, s);
      for(let y = 0; y < s; y++){
        for(let x = 0; x < s; x++){
          const n = height(x, y);
          const v = (0.72 + n*0.28)*255;
          const i = (y*s + x)*4;
          img.data[i] = img.data[i+1] = img.data[i+2] = v; img.data[i+3] = 255;
        }
      }
      ctx.putImageData(img, 0, 0);
    }, { repeat: 5 });

    const normalMap = normalFromHeight(256, (x, y) => height(x*2, y*2)*5);
    normalMap.repeat.set(5, 5);

    return { map, roughnessMap, normalMap };
  });
}

/* --- carapace: subtle mottling + fine pitting, for creature bodies --- */
export function carapaceTextures(){
  return cached("carapace", () => {
    const noise = makeNoise(7);
    const S = 256;
    const height = (x, y) => fbm(noise, x/16, y/16, 4);

    const roughnessMap = canvasTexture(S, (ctx, s) => {
      const img = ctx.createImageData(s, s);
      for(let y = 0; y < s; y++){
        for(let x = 0; x < s; x++){
          const n = height(x, y);
          const v = (0.3 + n*0.28)*255;   // mostly glossy, with duller patches
          const i = (y*s + x)*4;
          img.data[i] = img.data[i+1] = img.data[i+2] = v; img.data[i+3] = 255;
        }
      }
      ctx.putImageData(img, 0, 0);
    }, { repeat: 2 });

    const normalMap = normalFromHeight(256, (x, y) => height(x, y)*2.2);
    normalMap.repeat.set(2, 2);

    return { roughnessMap, normalMap };
  });
}

/* --- rock: chunky, matte, high relief --- */
export function rockTextures(hue){
  return cached("rock" + Math.round(hue), () => {
    const noise = makeNoise(hue + 31);
    const S = 256;
    const height = (x, y) => fbm(noise, x/14, y/14, 5);

    const map = canvasTexture(S, (ctx, s) => {
      const img = ctx.createImageData(s, s);
      for(let y = 0; y < s; y++){
        for(let x = 0; x < s; x++){
          const n = height(x, y);
          const col = new THREE.Color(`hsl(${hue + n*10 - 5}, ${12 + n*10}%, ${28 + n*26}%)`);
          const i = (y*s + x)*4;
          img.data[i] = col.r*255; img.data[i+1] = col.g*255; img.data[i+2] = col.b*255; img.data[i+3] = 255;
        }
      }
      ctx.putImageData(img, 0, 0);
    }, { repeat: 2, srgb: true });

    const normalMap = normalFromHeight(256, (x, y) => height(x, y)*10);
    normalMap.repeat.set(2, 2);

    return { map, normalMap };
  });
}

/* Height field used to displace the terrain mesh, so the floor isn't a flat plane. */
export function terrainHeight(hue){
  const noise = makeNoise(hue + 3);
  return (x, z) => {
    const broad = fbm(noise, x/26, z/26, 3) - 0.5;   // gentle rolling
    const fine  = fbm(noise, x/7, z/7, 3) - 0.5;     // small bumps
    const edge  = Math.min(1, Math.max(0, (Math.hypot(x, z) - 19)/9)); // rim rises
    return broad*1.3 + fine*0.22 + edge*edge*3.2;
  };
}
