import { defineConfig } from "vite";
import { viteSingleFile } from "vite-plugin-singlefile";
import { fileURLToPath } from "node:url";

// Which content pack to build: "personal" (book-flavoured, private use)
// or "sale" (fully original world). Set with GAME_PACK=... npm run build:*
const pack = process.env.GAME_PACK === "personal" ? "personal" : "sale";

// Drops the chosen pack's title into <title> at build time, so the tab is
// right before any JavaScript runs.
import { readFileSync } from "node:fs";
const packTitle = JSON.parse(
  readFileSync(new URL(`./src/content.${pack}.json`, import.meta.url), "utf8")
).meta.title;

const titlePlugin = {
  name: "inject-title",
  transformIndexHtml(html){ return html.replace("<!--APP_TITLE-->", packTitle); }
};

export default defineConfig({
  plugins: [titlePlugin, viteSingleFile()],
  resolve: {
    alias: {
      // main.js imports "@content" — this points it at the chosen pack
      "@content": fileURLToPath(new URL(`./src/content.${pack}.json`, import.meta.url))
    }
  },
  build: {
    target: "es2020",
    assetsInlineLimit: 100000000,
    chunkSizeWarningLimit: 100000,
    cssCodeSplit: false,
    rollupOptions: { output: { inlineDynamicImports: true } }
  }
});
