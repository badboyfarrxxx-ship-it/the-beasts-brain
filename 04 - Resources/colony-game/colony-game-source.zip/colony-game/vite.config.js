import { defineConfig } from "vite";
import { viteSingleFile } from "vite-plugin-singlefile";
import { fileURLToPath } from "node:url";

// Which content pack to build: "personal" (book-flavoured, private use),
// "sale" (fully original world) or "demo" (the sale game cut to zones 1 to 4
// by src/demo.js). Set with GAME_PACK=... npm run build:*
const PACKS = ["personal", "sale", "demo"];
const pack = PACKS.includes(process.env.GAME_PACK) ? process.env.GAME_PACK : "sale";

// Drops the chosen pack's title into <title> at build time, so the tab is
// right before any JavaScript runs.
import { readFileSync } from "node:fs";
import { makeDemoContent } from "./src/demo.js";
const readPack = name => JSON.parse(
  readFileSync(new URL(`./src/content.${name}.json`, import.meta.url), "utf8")
);
const content = pack === "demo" ? makeDemoContent(readPack("sale")) : readPack(pack);
const packTitle = content.meta.title;

// The demo has no JSON file: serve the cut content as the "@content" module,
// so only the demo's own zones end up in the bundle.
const DEMO_ID = "\0demo-content";
const demoContentPlugin = {
  name: "demo-content",
  enforce: "pre",
  resolveId(id){ return pack === "demo" && id === "@content" ? DEMO_ID : null; },
  load(id){ return id === DEMO_ID ? `export default ${JSON.stringify(content)};` : null; }
};

const titlePlugin = {
  name: "inject-title",
  transformIndexHtml(html){ return html.replace("<!--APP_TITLE-->", packTitle); }
};

export default defineConfig({
  plugins: [demoContentPlugin, titlePlugin, viteSingleFile()],
  resolve: {
    // main.js imports "@content": this points it at the chosen pack's JSON
    // (the demo is served by demoContentPlugin instead)
    alias: pack === "demo" ? {} : {
      "@content": fileURLToPath(new URL(`./src/content.${pack}.json`, import.meta.url))
    }
  },
  build: {
    target: "es2020",
    assetsInlineLimit: 100000000,
    chunkSizeWarningLimit: 100000,
    cssCodeSplit: false,
    rollupOptions: { output: { inlineDynamicImports: true } }
  }
});
